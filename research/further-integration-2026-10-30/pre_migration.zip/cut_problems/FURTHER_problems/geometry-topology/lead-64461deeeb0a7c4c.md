# Can a nonparallel cylinder packing have bounded holes?

## Problem statement

Does there exist a countably infinite family \(\mathcal C=\{C_i\}\) of solid infinite circular cylinders of radius 1 in \(\mathbb R^3\), with mutually disjoint interiors and pairwise nonparallel axes, for which there is a finite constant \(H\) satisfying
\[
 B_r(x)\cap\bigcup_i C_i=\varnothing
 \quad\Longrightarrow\quad r\le H
 \qquad(x\in\mathbb R^3,\ r>0)?
\]
Here \(B_r(x)\) is an open Euclidean ball. Thus every empty ball, wherever its center lies, has bounded radius.

## Application

The question asks whether separated tubes in distinct directions can cover space uniformly enough to prevent arbitrarily large empty regions.

## References

- D. Ismailescu and P. Laskawiec, *Dense packings with nonparallel cylinders*, **Elemente der Mathematik** 74(3) (2019), 89–103. [Published article](https://doi.org/10.4171/EM/387); [author preprint](https://arxiv.org/html/1809.10721v1), §4, preprint pp. 12–13.
- O. Eliyahu, *On non-parallel cylinder packings*, [arXiv:2310.06943v1](https://arxiv.org/html/2310.06943v1), introduction, Theorem 2.2, Corollary 3.9 and §4.

## Status review

Checked **30 October 2026**. Ismailescu–Laskawiec ask this explicitly at the end of §4; their construction has arbitrarily large holes. Eliyahu's later work retains a related translation-uniform density question. Fixed-origin density estimates, including the solved upper-density optimum, do not give the displayed uniform hole bound.

Current searches found no complete resolution or announcement of this exact question. Comparisons with all-status AIM/OpenAI records and developing findings distinguished finite covering-area problems, finite-field cylinder sets and finite touching-cylinder configurations. No equivalent entry was located. This is a dated, bounded check.

The [near-optimal lower-density question](../../../FURTHER_problems/geometry-topology/lead-3138cdf543b2c1a5.md) is recorded separately.
