# Further-problem collection

**ID backfill, 30 October 2026:** Of 731 historical further admissions, 521 originally met I >= 6. Following the explicit reverse Faber–Krahn exclusion, **111 are AIM entries, 409 remain staged here and 211 are archived** (210 original score-based cuts plus one user-requested exception). All scores are unchanged. Resolve historical paths with the [cut manifest](../cut_problems/move_manifest.json), [backfill register](../research/catalogue-backfill-2026-10-30/manifest.json) or [path resolver](../cut_problems/verify_cut.py). Historical research ledgers and paused cursors remain unchanged. No research jobs were resumed.

The keep rule is **I = max(M, A) >= 6**, applied to the frozen [score snapshot](../cut_problems/_audit/score_snapshot.json).

See [the replacement register](../research/catalogue-backfill-2026-10-30/README.md), [resume handoff](RESUME.md), [workflow](WORKFLOW.md) and [source log](SOURCE_LOG.md).
