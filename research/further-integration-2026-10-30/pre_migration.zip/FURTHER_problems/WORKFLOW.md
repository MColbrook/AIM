# Systematic source review workflow

**ID backfill, 30 October 2026:** Of 731 historical further admissions, 521 originally met I >= 6. Following the explicit reverse Faber–Krahn exclusion, **111 are AIM entries, 409 remain staged here and 211 are archived** (210 original score-based cuts plus one user-requested exception). All scores are unchanged. Resolve historical paths with the [cut manifest](../cut_problems/move_manifest.json), [backfill register](../research/catalogue-backfill-2026-10-30/manifest.json) or [path resolver](../cut_problems/verify_cut.py). Historical research ledgers and paused cursors remain unchanged. No research jobs were resumed.

The active research goal covers the sources in [SOURCE_LOG.md](SOURCE_LOG.md). The source list remains the single manual source inventory. The authoritative operational ledger is `_tracking/coverage.sqlite3`; [PROGRESS.md](PROGRESS.md) and `_tracking/progress.json` are generated views. The SQLite database is a coverage record, not a substitute for the individual mathematical reviews.

Only files inside `FURTHER_problems` may be changed. Reading the existing AIM collection and current public repository metadata is necessary for duplicate checks. No commit, push, pull or fetch is authorized. No numerical-linear-algebra problem is admitted.

## Current throughput policy (28 October 2026)

The compatibility correction is complete. Freeze the pipeline and use the standard batch manifest and completion record in `_tracking/STANDARD_PIPELINE`. Validate each new batch once; reuse its verified manifest. Recheck unchanged files only after concrete evidence of a problem. Quarantine an isolated malformed record as an explicit gap while unrelated records and batches continue. Retained-context omissions remain gaps, not completed reading.

Keep at most one agent on pipeline maintenance and cleanup; the other agents find and check problems. Routine batches use the existing runner and data updates without new case-specific scripts, aliases or approval records. Preserve completion, exclusion and keeper records so cleanup cannot cause replay. All admission requirements below remain: primary formulation, current resolutions and announcements, latest versions, and semantic duplicate checks.

Report machine papers/hour separately from finite retained-passage papers/hour, precise candidates checked and problems admitted. Name the measurement window and distinguish holds, partial source coverage and whole-source completion. Current figures are in [the research status](_tracking/RESEARCH_STATUS.json) and [throughput record](_tracking/THROUGHPUT.json); older generated views are historical unless explicitly reconciled to those records. This policy supersedes older routine validation or approval cycles.

## Current execution priority (26 October 2026)

Follow the [parallel search execution protocol](_pipeline/FAST_SEARCH_PROTOCOL.md): reuse checked scan code with queued bounded batches, keep scanning and candidate checks independent, and park access or formulation blockers with exact resume records. Search usable body text for **open problem**, **conjecture** or **question** before detailed review; titles and abstracts alone cannot clear a body-text negative. This instruction supersedes any older discovery-depth wording below.

## Fast first pass across the entire log

The user's instruction of 19 October 2026 changes the default discovery depth for **all** sources, including journals, books, proceedings, arXiv and websites. Work in parallel batches. Skim abstracts, contents, conclusions, explicit open-question lists and candidate passages first. Escalate to careful mathematical reading and resolution/duplicate checks only when a plausible open problem appears. Do not routinely read complete proofs, every figure or every cited body before deciding whether a source is promising.

Keep separate states for `machine_screened`, `skim_no_candidate_in_checked_extent`, `skim_promising_question`, `skim_unclear`, `skim_access_gap`, and detailed candidate reviews. Preserve the exact version, sections or metadata fields inspected and cache hashes. An unflagged machine scan is not a human skim or an assertion that a paper has no open problem. A completed first-pass source/issue checklist is reported as screened; it is distinct from the older full-text completion count. Existing full reviews remain valid and must be reused rather than repeated.

The earlier recursive full-body tasks are background obligations for relevant candidates, not prerequisites for screening negative sources. Admission standards below remain unchanged.

The user's 20 October clarification makes a **bounded full-text passage screen part of the fast search**. Title, abstract, catalogue and TOC passes identify where to look but never suffice as the final scientific screen of an accessible item. Search the actual article/chapter/paper text for explicit question, conjecture, open-problem, unresolved-case, limitation and future-work language; read the surrounding definitions and passage, with special attention to introductions, discussion, conclusions, remarks, exercises and problem sections. Record source version, page/section, passage extent, query terms and any inaccessible or unsearchable text. Parallel text extraction is useful for triage, but a machine hit without contextual reading is only a locator. Preserve separate counts for metadata, abstract/TOC, human-read body passage and complete version; do not turn a failed or negative keyword search into a whole-text absence claim.

**Current narrow first-pass gate (22 October):** For each accessible exact full text, search case-insensitively for “open problem”, “conjecture”, or “question”, including plural forms and line-break whitespace in “open problem”. If none occurs, record a negative first-pass result limited to that text and set it aside. If one occurs, read its surrounding mathematical passage before any detailed status or duplicate review. Unreadable or missing text is an explicit gap. This three-term gate supersedes the broader cue list in the preceding paragraph for new first-pass screening; earlier valid candidate reviews remain intact.

Backfill every previously title/abstract/TOC-only item, including first-pass negatives and unclear records. The imported-review identity export in `_tracking/second-pass-2026-10-20/` provides stable preliminary and prior body-evidence pointers for reconciliation. Only an actual matching-version and matching-scope body receipt removes an item from that second-pass backlog; a selected chapter does not clear a book or a selected paper an entire issue. Keep aggregate archive entries without stable article identities as explicit enumeration gaps. Do not spend the backfill effort on additional title-only waves while a known text backlog remains.

**Extraction-quality requirement (23 October):** A successful extractor and 200 characters across a PDF do not establish that its scientific body was scanned. Reconcile independently reported PDF pages with extracted pages; record per-page characters/words, blank and short-page diagnostics, and a bounded nonabstract scientific-body witness. Missing, mismatched, short, blank or frontmatter-only extraction remains a coverage gap requiring another route or OCR; preserve any positive cues. A negative is limited to its extracted text, with image/OCR limitations explicit. All historical negatives made under the old global-character gate remain unverified-body outcomes pending reconciliation, including records with no obvious metadata warning. See [_tracking/arxiv-native-extraction-scope-correction-2026-10-23.json](_tracking/arxiv-native-extraction-scope-correction-2026-10-23.json).

## Remote work

Use SSH host `VT_ampere`. The dedicated remote directory is `/home/mjc249/FURTHER_problems`, with a task ownership marker. It contains worker code, immutable input bundles, result receipts and temporary primary-source caches. It is not a second Git checkout. Do not run repository setup scripts or use credentials from unrelated services.

The machine reports 64 cores. Following the user's request for faster parallel work, CPU batches use up to 48 workers for extraction, normalization and duplicate retrieval. Three parallel mathematical reviewers return precise reading receipts to the coordinator. Network retrieval uses a smaller pool and per-host limits; arXiv OAI continuation requests remain sequential. More CPU cores do not change public-service rate limits. arXiv explicitly requests bulk access mechanisms for a complete corpus; its search endpoint is not used to crawl every PDF. No paid bulk download or subscription is initiated without approval.

Remote workers propose metadata and passage locations only. They cannot label a source fully reviewed, determine whether a conjecture remains open, or admit candidates. The coordinating review owns the admission transaction.

## Coverage accounting

1. Preserve the imported source IDs and the source-log hash. Resolve each provisional bibliographic record, including aliases and historical publishers.
2. Enumerate every issue, article, book edition, volume, chapter, archive date range and public website snapshot. Assign stable item keys using DOI, base arXiv ID, ISBN plus chapter, or a stable source URL and locator. Many sources can point to one item.
3. Use transactional task leases with expiry and idempotent result imports. A crashed task can be resumed; the same receipt cannot be counted twice. A retrieval task completing does not mean its source is complete.
4. Record metadata-only retrieval, machine text extraction, keyword hints and a completed content review as distinct states. Keyword hits are navigation aids, not an exhaustive substitute for reading. Missing OCR, inaccessible text and incomplete pagination remain coverage gaps.
5. A source is complete only after its enumeration totals reconcile and every required item has a documented content disposition. The initial 645-source inventory and later discovered sources are reported separately. Journal and website snapshots have dates; no growing live corpus is silently treated as finished.

The arXiv discovery range is the previously recorded literal cutoff: first submission through 31 January 2022 inclusive. OAI update timestamps are not first-submission dates. Harvest the correct version metadata and filter by the actual original submission date; do not omit old papers simply because they were revised after the cutoff. Later status searches extend through the actual check date.

## Reusing book reviews

Before fetching or rereading a book, check its canonical book:B### work IDs, known DOI and edition aliases, and the covering work/version index. A source_items lookup alone can miss an existing canonical review. Compare the exact native PDF hash and the recorded reading extent before awarding new credit. Reuse matching evidence without counting it again; inspect a different edition only for its uncovered scope. Query the covering index instead of repeatedly loading the large coverage-review-index.json export.

## Admission review

A possible problem must pass all of the following before a page is written in a category folder:

- Read its primary statement and surrounding definitions. Record the exact source revision and page, conjecture, problem or question number. Preserve every material assumption and quantifier.
- Give a self-contained formulation and an application supported by sources, or explain its mathematical significance without inventing an application.
- Search for later proofs, counterexamples, equivalent formulations, restricted results and announced complete solutions. Check the latest source revision, author updates, arXiv, journals, public proof repositories and Prove2Me as relevant. A matching announced complete proof excludes the item from the new open list even if its proof has not been independently certified.
- Compare with every status in the existing AIM collection, including solved, partial, claimed and retained entries; do not search only titles or only open problems. Use the current read-only public metadata snapshot and its freshness evidence; refresh when a new source change or other concrete concern requires it. Record semantic comparisons with the closest matches.
- Compare with all pending, rejected and admitted findings in this project. Different titles, parameter normalizations or source citations can represent the same target. Do not add a restatement or an immediate already-covered special case as a new problem.
- Keep genuinely unresolved extensions separate from a resolved base statement. State the known cases and remaining target explicitly. Hold inaccessible statements and uncertain solution matches rather than admitting them.

The ledger keeps rejected and held leads as well as admitted ones. A rejection caused by an announced solution says exactly that; it does not assert the announcement has been independently proved correct. Status searches are dated and bounded; a negative search is not a proof that no solution exists.

## Candidate files

Admitted pages live in the relevant category folder with stable `lead-<fingerprint>.md` filenames. These are research IDs, not AIM problem IDs. Each page has Problem statement, Application, References and Status review sections, with source attribution, current search receipts, closest duplicate comparisons and explicit review limits. A finding can be cross-tagged while having only one canonical page.

The coordinator records admission evidence in the ledger and exports `_tracking/findings.json`. Pending or excluded leads stay in that ledger and its generated views; they do not appear as accepted open-problem pages. The active goal is marked complete only when the coverage requirements have actually been met.

## Parallel checkpoints

All four available mathematical review slots are used: three source streams and coordinating admission review. VT_ampere batches normalize and compare cached data with up to 48 CPU workers. Archive walks checkpoint each page and now permit up to 100 pages per continuation; source request limits remain in force. Multi-manifest deployment and compressed receipt transfer reduce connection overhead.

`_pipeline/issue_inventory.py` derives pending issue groups from reconciled Crossref walks. It preserves missing volume/issue fields, container-title distinctions, membership hashes and dated tasks. Reconcile each group with actual publisher tables of contents before reviewing its member articles. Never treat metadata cursor exhaustion as journal completion. Crossref cursor requests must omit incompatible publication-date sorting; retain failed receipts and corrected replacement links.

`_pipeline/import_followups.py` imports the explicitly inventoried reading receipts in `_tracking/followup-content-import-manifest.json` and each review stream's own `content-import-manifest.json`; exact preprint, published-version, visual and access limits remain part of every record. Each reviewer owns its manifest, while the coordinator owns shared ledger imports and admission.

Remote transfer summaries carry full normalized metadata once per item and item-ID references for source associations; complete per-job receipts remain in the owned remote directory. Continued journal walks reconcile the union of old and new DOI identifiers, including overlaps. Shared per-host pacing files coordinate separate batches as well as threads. These changes reduce transfer and coordination overhead without changing the mathematical admission gates.

Independent candidate audits rotate between the three mathematical streams while other source reading continues. The coordinator reads both audits and owns the admission transaction. A selected primary-statement audit is recorded with its actual extent and does not count as another full article reading. Shared task preparation uses one bulk transaction; `_pipeline/collect_completed.py` imports only confirmed finished batches and skips already imported receipts. Neither operation silently restarts remote jobs.

`_pipeline/collect_partial.py` also imports completed individual jobs without waiting for a batch barrier. Its bounded transfers retain deferred work explicitly. Repeated imports skip completed task IDs. The work/source and work/version indexes prevent a per-candidate full database scan when constructing the reading queue. `_pipeline/discovery_queue.py` creates one work-scoped reading task per title hint; unflagged papers remain in the exhaustive coverage obligation.

Journal inventory records already contain selected bibliographic fields. Original API responses, including references when supplied, remain in the owned remote `_cache/<page-id>.raw` files. Per-job receipts retain the page IDs, request URLs and exact response hashes. Metadata is transferred once per work with per-job membership references; it is not a reference or paper-content review. Retrieve the raw page when full API metadata is needed. A misleading intermediate provenance note is corrected in `_tracking/inventory-provenance-correction-2026-10-17.json`; no metadata was deleted by that unused reduction branch.

Refresh website membership separately from mathematical status. Reconcile pages and distinct mission IDs before using a new listing snapshot. Scan the cached rendered text, since embedded description fields can be unresolved references. A previously reviewed context may be reused only after exact term/context equality; newly matching or changed contexts need semantic review. Listing comparisons do not certify individual mission proofs.

`_pipeline/book_inventory.py` preserves every returned book candidate, DOI, edition field, author/editor record and ISBN checksum. Its title comparison is a navigation aid. Even an exact title and valid ISBN require primary identity verification; an absent edition number is an unresolved field, not evidence that only one edition exists.

`_pipeline/mersenne_inventory.py` records article memberships from observed AIF/JEP publisher TOC links and creates pending article-review tasks. It preserves previous dated TOC snapshots and flags unclassified item links; it does not infer article reading or archive completeness. Canonical metadata enrichment preserves reading/disposition fields and allows a later Crossref record to enrich an already observed publisher DOI without losing provenance. Partial arXiv retrieval failures retain successfully harvested items and the uncompleted cursor for continuation.

The bounded `_pipeline/arxiv_supervisor.py` removes idle gaps between verified arXiv continuation segments. The completed first plan reserved batches0083–0090. Its continuation reserved0101–0108 exclusively, starting from batch0090's exact confirmed next cursor. The producer exited normally after0107 at an observed terminal cursor on17October2026;0108 remains unused/reserved. Reconcile IDs, initial page, eligibility and mutable-catalogue drift before any global metadata-coverage claim. It holds an ownership-checked Linux lock, keeps immutable manifests, checks each finished segment before advancing and stops on a gap or exhausted cursor. Each segment remains bounded to 100 sequential pages. Do not restart the producer or reuse these batch numbers on an uncertain outcome; inspect the saved status and process first. The current producer identity and plan are in `_tracking/arxiv-supervisor-plan-0101-0108.json` and the active checkpoint; the earlier plan is historical. This does not certify archive exhaustion or content coverage.

Collect supervisor manifests with `_pipeline/collect_supervised.py batch-0101 ... batch-0108`. It registers only observed, validated manifests and imports only confirmed completed receipts, skipping prior imports. The separate network stages retain shared host pacing. Continue independent primary reading and selected audits while archive enumeration runs. Mathematical reviewers may request rotating audits directly from one another; owner packets and independent audit packets remain separate, and only the coordinator admits.

Use `_pipeline/validate_research.py` after an admission wave to check page structure, local references, source IDs, evidence paths, admission gates and Python syntax. Its receipt is structural validation, not proof certification. Update `RESUME.md` and `_tracking/ACTIVE_CHECKPOINT.json` from the actual imported state; the older pause checkpoint remains historical.

Primary PDF bytes and full extracted page-text caches are private research material, kept in the owned remote cache or ignored local `_tracking` paths. Preserve these caches for resumption; retain public source URLs, exact version hashes, reading extents and review receipts separately. They are not repository solution uploads.

## Local ledger concurrency

The local coverage ledger uses SQLite WAL with FULL synchronization, checked with the bundled SQLite3.53.1 runtime. One coordinator remains the only writer. Short same-host read-only transactions can run alongside imports; avoid unindexed full-ledger scans and prefer immutable source manifests for remote cached work. Close/materialize read cursors promptly. A live SQLite database must be backed up with SQLite backup facilities or after all connections close; do not copy its database file separately from pending WAL state. Remote workers use immutable input packets, never this live local database. See `_tracking/ledger-concurrency-2026-10-19.json` and `_tracking/ledger-wal-concurrency-verification-2026-10-19.json`.
