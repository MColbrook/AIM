# AIM problem scoring

Provisional editorial assessment of **all 665 existing AIM entries and all 731 admitted further problems: 1,396 entries**, dated 30 October 2026. The existing total includes 651 current problem pages and 14 retained resolved entries.

Read the [existing AIM assessments](EXISTING.md) or [further-problem assessments](FURTHER.md). The [CSV](scores.csv) is a flat, filterable export. [scores.json](scores.json) is the authoritative scoring snapshot, including problem statements, application notes, source paths, source hashes and recorded reference links.

**Cut applied on 30 October 2026:** the selected rule keeps I >= 6: 1,075 retained and 321 archived. See [the cut archive](../cut_problems/README.md). The original descriptions below are the pre-cut methodological record. Current locations and keep/cut decisions are in JSON and the [selection CSV](../cut_problems/selection.csv); the original CSV remains a pre-cut score snapshot.

**ID backfill, 30 October 2026:** 111 retained further problems now occupy the vacated AIM IDs, after fresh bounded online status checks. After the later explicit exclusion of reverse Faber–Krahn, current locations are 665 AIM entries and 409 staged further problems: 1,074 retained. The original threshold selected 1,075; this single editorial override is recorded separately, with every score unchanged. See the [replacement register](../research/catalogue-backfill-2026-10-30/README.md).

## Scores and classification

Each dimension uses integer scores from **0 to 10**. Odd values interpolate the anchors below. The precision is approximately one or two points; this is an editorial judgment, not a statistical confidence interval. Unknown would be recorded as null, rather than zero.

| Score | M: mathematical significance | A: scientific or computational impact | C: conceptual interest | E: explanatory value |
| ---: | --- | --- | --- | --- |
| 0 | No distinct mathematical advance after substantive assessment, such as a pure restatement. | No concrete scientific/computational consequence substantiated for this exact target in the reviewed material; not a claim that none could exist. | No distinct conceptual question, such as an unchanged duplicate. | No clear explanatory contribution identified after review. |
| 2 | Isolated technical refinement with little established wider role. | Remote or mainly generic modeling connection. | Largely routine technical refinement. | Very specialized technical payoff with a weak explanatory route. |
| 4 | Meaningful but narrow specialist result. | Specific consequence within a limited model or method. | Nontrivial local extension or parameter boundary. | Useful specialist explanation requiring extensive setup. |
| 6 | Substantial problem or barrier within a subfield. | Significant guarantee for a useful class of models, experiments or algorithms. | A meaningful mechanism, obstruction or structural phenomenon. | Engaging graduate-level account with a recognizable payoff. |
| 8 | Major structural problem with substantial connections. | Major scientific/computational limitation addressed by the exact target. | A strong organizing principle, rigidity phenomenon or connection. | Strong cross-field narrative or visual/mechanistic explanation. |
| 10 | Exceptional foundational or field-defining importance. | Transformative consequence across major applications, supported by concrete evidence. | Exceptional paradigm-level conceptual significance. | Exceptionally clear and illuminating central question. |

**Importance indicator: I = max(M, A).** C and E remain separate. There is no four-score total. A low application score reflects the concrete consequence supported for the exact target in the supplied material. It is not evidence against theoretical significance.

The first matching rule determines the classification:

| Classification | Rule |
| --- | --- |
| High priority | I ≥ 8 and C ≥ 8 |
| Core | I ≥ 7, or I ≥ 5 and C ≥ 8 |
| Specialist review | I ≥ 5 or C ≥ 6 |
| Archive review | Remaining cases: I ≤ 4 and C ≤ 5 |

A score of 6 represents a substantial specialist contribution. The bands assess questions and editorial priorities. They do not rate researchers or contributors. Archive review is a queue for discussion; the later user-authorized I >= 6 selection is documented in the cut archive. A high E can identify a strong explanation opportunity even when the mathematical target is narrow.

## Coverage

| Collection | High priority | Core | Specialist review | Archive review | Total |
| --- | ---: | ---: | ---: | ---: | ---: |
| Existing AIM | 244 | 189 | 205 | 27 | 665 |
| Admitted further problems | 122 | 262 | 290 | 57 | 731 |
| All entries | 366 | 451 | 495 | 84 | 1396 |

## Assessment basis and limits

The [40-problem calibration](../FURTHER_problems/_curation_calibration/2026-10-30/REPORT.md) supplied the anchors. Its scores, classifications and dimension-by-dimension rationales are preserved unchanged. The other 1,356 profiles are an **initial editorial screen**, using bounded readings of local problem-statement and application excerpts and a target-specific summary judgment for every entry. This is not a full reading of every mathematical formulation, an independent proof or literature-status audit, an expert-panel assessment, or a validation of claimed downstream impact. The complete locally extracted statements are retained in the JSON for closer review.

The two entries with differently named application sections were inspected in full and their application text included. The recorded references locate the mathematical source material; new reference-completeness checks were outside this exercise. Confidence labels describe confidence in the provisional editorial profile, not correctness or proof certainty. All entries remain marked as awaiting human editorial review.

The exact target is scored, rather than the reputation of its field, journal or proposer. Solution status, the existence of a write-up, AI involvement, difficulty and effort already spent earn no automatic points. A known solution can still have substantial mathematical or explanatory value. Scope fit, validity, duplication, current resolution status and tractability require separate judgments.

Borderline entries can move bands under a one-point revision. Treat differences of one or two points as prompts for discussion, especially across disciplines. No removal follows mechanically from these scores.

## Reviewing the results

Filter the CSV by collection, category, classification or any dimension. Consult the linked problem and the assessment note before revising a score. To explore the earlier alternative policies, the broad filter is I ≥ 6 or C ≥ 8; the selective filter is I ≥ 7 or (I ≥ 5 and C ≥ 8). Those filters are comparisons only, with no collection changes applied.

The JSON owns the score values and classifications. The Markdown tables and CSV are snapshots of the same records. After an approved score revision, regenerate the views and verify that I and the classification still follow the stated rules.

## Validation

All 1,396 records have unique keys, existing source files, matching source SHA-256 hashes, four integer scores in range, an assessment note, and classifications matching the rules. All 40 calibration profiles and rationales match the calibration file. The main README, catalogues, resolution list, paused research checkpoints and calibration JSON match the hashes recorded before this task. The scoring outputs remain in this folder; the later cut is documented in cut_problems.

## Further-problem coverage by category

Only admitted records are included; candidate leads and research-tracking records are excluded. Category names follow the existing research folders.

| Category | Entries |
| --- | ---: |
| bayesian-inverse-uncertainty-quantification | 5 |
| complex-analysis-potential-theory | 78 |
| continuous-optimization | 18 |
| continuum2 | 2 |
| diffusion-materials | 20 |
| electrochemistry-energy-storage | 6 |
| fluid-structure-interaction | 11 |
| fracture-damage-plasticity-contact | 9 |
| geometry-topology | 199 |
| inverse | 15 |
| mathematical-relativity | 13 |
| nonlinear-filtering-data-assimilation | 4 |
| numerical-analysis | 24 |
| operators | 66 |
| optimization-information | 6 |
| pdes-materials | 54 |
| probability-statistics | 68 |
| rough-paths-singular-stochastic-equations | 21 |
| spectral | 55 |
| spectral3 | 8 |
| stochastic3 | 1 |
| waves-fluids-kinetics | 48 |
