# Integrating retained further problems

In progress: 409 retained, currently staged problems are being rechecked. No new ID is allocated before its status gate passes. The manifest is the current per-problem ledger; original pages and hashes are preserved. This work does not resume the paused discovery jobs or modify their coverage records. No Git operation is authorized.
