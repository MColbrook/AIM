# Bi-invariant subspaces for invertible operators on reflexive Banach spaces

**Area:** Operator theory and Banach spaces

**Status:** Open question in the cited source; no complete resolution located in a bounded current search

**Last checked:** 2026-10-21

## Problem statement

Let \(X\) be any infinite-dimensional complex reflexive Banach space and let \(A:X\to X\) be a bounded invertible complex-linear operator. Must there be a norm-closed linear subspace \(M\) such that
\[
 \{0\}\subsetneq M\subsetneq X,
 \qquad A(M)=M?
\]
The equality means that the **same** nontrivial subspace is invariant under both \(A\) and \(A^{-1}\). Equivalently, must every bounded-operator representation of the discrete group \(\mathbb Z\) on such an \(X\) be reducible? This is Atzmon's question for \(\mathbb Z\) [1, Introduction and Section 4].

## Application

A common invariant subspace gives a proper closed component preserved by every forward and backward iterate of a reversible linear evolution. The question tests how much reflexivity alone constrains such decompositions, beyond special spectral, symmetry or growth hypotheses.

## Known results and scope

Atzmon proves a sufficient criterion [1, Theorem 6] when an additional conjugate-linear involution intertwines \(A\) with \(A^{-1}\) and suitable matrix coefficients are positive definite. Weighted translation examples satisfying further symmetry are covered by that criterion. These assumptions are absent from the universal question. A subspace with only \(A(M)\subseteq M\) does not suffice. Results for nonreflexive spaces do not decide this reflexive-space formulation.

## References

1. A. Atzmon, [*Reducible representations of abelian groups*](https://www.numdam.org/item/10.5802/aif.1859.pdf), *Annales de l'Institut Fourier* **51** (2001), no. 5, 1407–1418, [doi:10.5802/aif.1859](https://doi.org/10.5802/aif.1859). The introduction, printed p. 1407, and Section 4, printed p. 1415, state the universal reflexive bi-invariance question; Theorem 6 gives an additional-hypothesis result.
2. C. Cheng, X. Fang and J. Jiang, [*On the third problem of Halmos on Banach spaces*](https://arxiv.org/abs/2203.14670), arXiv:2203.14670. This treats related but distinct inverse-intransitivity questions and conditional operator classes.

## Status review

No matching complete proof, counterexample or announced resolution of the exact universal statement was located in bounded searches through 21 October 2026. Enflo's [2023 announced Hilbert-space result](https://arxiv.org/abs/2305.15442) concerns ordinary one-sided invariant subspaces, so it does not resolve the common-subspace question for all reflexive Banach spaces. The related Halmos results in [2] have different hypotheses. Searches of AIM and admitted FURTHER pages found no duplicate. These checks do not certify exhaustive absence of a solution.

The [primary-source audit](../_tracking/atzmon-reflexive-biinvariant-primary-2026-10-21.json), [current-status audit](../_tracking/atzmon-reflexive-biinvariant-status-2026-10-21.json), and [duplicate/scope audit](../_tracking/atzmon-reflexive-biinvariant-duplicates-2026-10-21.json) record the evidence and limits.
