# Even trace coefficients for arbitrary Hermitian matrix pairs

**Area:** Matrix analysis and noncommutative polynomial positivity

**Status:** Open in general; partial results known

**Last checked:** 2026-10-27

## Problem statement

For every integer $n\geq1$, every even integer $m\geq2$, every even integer $k$ with $0\leq k\leq m$, and every pair of Hermitian matrices $A,B\in\mathbb C^{n\times n}$, is
```math
c_{m,k}(A,B):=[t^k]\operatorname{Tr}\bigl((A+tB)^m\bigr)\geq0?
```
Here $t$ is a scalar indeterminate, $\operatorname{Tr}$ is the ordinary, unnormalized trace, and $[t^k]$ denotes coefficient extraction. Equivalently, define
```math
S_{m,k}(A,B)
=\sum_{\substack{w\text{ a word of length }m\text{ in }A,B\\
                 w\text{ contains exactly }k\text{ copies of }B}}w(A,B).
```
Each ordered word is counted once, so
```math
c_{m,k}(A,B)=\operatorname{Tr}S_{m,k}(A,B).
```
Word reversal shows that $S_{m,k}(A,B)$ is Hermitian and its trace is real. The matrices $A$ and $B$ may have negative eigenvalues and need not commute. The desired assertion concerns the sum's trace, rather than the sign of each individual word or positivity of the whole matrix $S_{m,k}$.

This is Question 1.1 of Collins, Dykema, and Torres-Ayala [1]. It is one problem family over all matrix sizes and even exponents. The cases $k=0,m$ are immediate, as is the commuting case by simultaneous diagonalization.

## Application

The question asks how far trace-coefficient positivity extends beyond positive-semidefinite inputs. It connects trace inequalities from quantum statistical mechanics with certificates for matrix-polynomial optimization. The noncommuting variables and unrestricted matrix dimension motivate analytic trace inequalities and algebraic positivity certificates.

## References

1. B. Collins, K. J. Dykema, and F. Torres-Ayala, *Sum-of-squares results for polynomials related to the Bessis–Moussa–Villani conjecture*, Journal of Statistical Physics **139** (2010), 779–799, [DOI: 10.1007/s10955-010-9959-y](https://doi.org/10.1007/s10955-010-9959-y). [arXiv:0905.0420v3](https://arxiv.org/pdf/0905.0420v3), definition on p. 1, Question 1.1 on p. 3, Lemmas 3.1–3.2 and Proposition 3.3 on p. 10, and Proposition 3.8.
2. E. D. Kim, J. Miller, and L. Zinnel, *On a polynomial positivity question of Collins, Dykema, and Torres-Ayala related to the Bessis–Moussa–Villani Conjecture*, [arXiv:2110.12528v1](https://arxiv.org/pdf/2110.12528v1) (2021), Conjecture 1.4 and Theorems 2.1–2.2.
3. N. K. Green and E. D. Kim, *Further techniques on a polynomial positivity question of Collins, Dykema, and Torres-Ayala*, Algebra and Discrete Mathematics **37** (2024), no. 2, 215–235, [DOI: 10.12958/adm2125](https://doi.org/10.12958/adm2125). [Published paper](https://admjournal.luguniv.edu.ua/index.php/adm/article/download/2125/pdf), Conjecture 1 and Theorem 1.
4. E. H. Lieb and R. Seiringer, *Equivalent forms of the Bessis–Moussa–Villani conjecture*, Journal of Statistical Physics **115** (2004), 185–190, [DOI: 10.1023/B:JOSS.0000019811.15510.27](https://doi.org/10.1023/B:JOSS.0000019811.15510.27).
5. H. R. Stahl, *Proof of the BMV conjecture*, Acta Mathematica **211** (2013), 255–290, [DOI: 10.1007/s11511-013-0104-z](https://doi.org/10.1007/s11511-013-0104-z). [arXiv:1107.4875](https://arxiv.org/abs/1107.4875).

## Status review

The positive-semidefinite polynomial formulation of BMV [4] is settled by Stahl's theorem [5], with all exponents allowed. The present question permits indefinite Hermitian matrices while requiring both $m$ and $k$ to be even.

Known partial results include $k=2$ for every even $m$ [1, Lemmas 3.1–3.2], and $k=4$ when $m\equiv2\pmod4$ [1, Proposition 3.3], together with cases obtained by exchanging $A$ and $B$. Kim–Miller–Zinnel prove the real-symmetric case $(m,k)=(8,4)$ for $n\leq5$ [2, Theorem 2.2]. Green–Kim retain the general assertion as Conjecture 1 and give a certificate as a sum of squares in the commuting matrix-entry variables for $(m,k)=(6,2)$, uniformly in real-symmetric matrix size [3, Theorem 1]; that case's nonnegativity was already covered by the earlier $k=2$ results. Commutativity of the entry variables does not assume that the matrices commute.

The universal real-symmetric and complex-Hermitian assertions are equivalent by realification into dimension $2n$. This does not transfer a result for real matrices of size at most five to complex matrices of the same size.

Failure of a cyclic sum-of-Hermitian-squares certificate is a different assertion from a negative trace. In particular, [1, Proposition 3.8] proves that $S_{8,4}(A,B)$ has no such certificate in $\mathbb R\langle A,B\rangle$, while leaving the trace-positivity question open there.

[AIM 559](https://github.com/MColbrook/AIM/blob/8729eab98bafe409b66c5e39253bf56569a62327/problems/559-univariate-trace-decidability.md) concerns algorithmic decidability for arbitrary pure trace polynomials in one matrix. Its undecidability result does not answer the sign of this particular family in two noncommuting matrix variables. No matching complete proof, counterexample, or announced resolution was located in the checked current literature and AIM, FURTHER, and OpenAI records. The review compares formulations and known result scopes; it is not a new certification of all cited proofs.
