# The sharp curvature Schrödinger inequality for closed loops

**Area:** Spectral geometry and elastic loops

**Status:** Open conjecture; no complete resolution located

**Last checked:** 2026-10-19

## Problem statement

Let \(\gamma:\mathbb R/(2\pi\mathbb Z)\to\mathbb R^3\) be any smooth unit-speed closed curve, so \(|\gamma'(s)|=1\), and define its curvature by \(\kappa(s)=|\gamma''(s)|\). Self-intersections are allowed; planarity and convexity are not assumed.

Prove or disprove that every \(f\in H^1_{\mathrm{per}}(0,2\pi)\) satisfies
\[
\int_0^{2\pi}\bigl(|f'(s)|^2+\kappa(s)^2|f(s)|^2\bigr)\,ds
\geq \int_0^{2\pi}|f(s)|^2\,ds.
\]
Equivalently, the least eigenvalue of
\[
H_\gamma=-\frac{d^2}{ds^2}+\kappa(s)^2
\]
with periodic boundary conditions should be at least \(1\). The unit circle and a known family of noncircular ovals attain \(1\). The question asks for the universal bound, without adding an equality-classification requirement.

## Application

This operator arises when determining the tension in a dynamical elastic loop. The inequality would provide a sharp uniform coercivity estimate for that operator over closed curves of fixed length. The curvature potential here has a positive sign.

## References

1. Almut Burchard and Lawrence E. Thomas, *On an isoperimetric inequality for a Schrödinger operator depending on the curvature of a loop*, Journal of Geometric Analysis **15** (2005),543–563, [published article](https://doi.org/10.1007/BF02922244); [author versionmath/0505123v1](https://arxiv.org/abs/math/0505123v1), Introduction, equation1.1 and Theorem1.1, physical pp.1–4.
2. Helmut Linde, *An improved bound for the ground state of a Schrödinger operator on a loop*, [arXiv:2504.20229v2](https://arxiv.org/abs/2504.20229v2),24May2025, Introduction and Theorems2.1–2.2.
3. Durvudkhan Suragan, *An Improved Bound for the Ovals Problem*, [arXiv:2609.10775v1](https://arxiv.org/abs/2609.10775v1),9September2026, Introduction, Theorem1.1, Corollary1.2 and the endpoint-condition discussion in §5/AppendixA.
4. OpenAI, *Sharp one-dimensional Lieb–Thirring constants*, [announced preprint](https://github.com/openai/math/blob/main/preprints/Sharp-One-Dimensional-Lieb-Thirring-Constants-September-23-2026/paper.pdf),23September2026, Theorem1.1.

## Status review

Burchard–Thomas prove local minimality of the oval family rather than the full global assertion. Linde improves the analytic lower bound to \(0.81\). Suragan announces the stronger bound
\[
\lambda_1(H_\gamma)\geq\frac{\sqrt\pi}{2}
\left(\frac{\Gamma(7/6)}{\Gamma(5/3)}\right)^3<1,
\]
which still leaves a gap to the conjectured value.

The announced sharp Lieb–Thirring theorem concerns a related real-line spectral inequality. The inspected cumulative-density reduction imposes zero endpoint values, whereas a smooth loop has a positive periodic ground-state amplitude. Thus that theorem does not automatically establish the present periodic inequality. This distinction was independently checked; neither announcement's complete proof was certified here.

No matching complete resolution or equivalent AIM/FURTHER entry was located in the bounded searches and comparisons. The [coordinator review](../_tracking/benguria-loss-coordinator-review-2026-10-19.json), [current checks](../_tracking/benguria-loss-current-review-2026-10-19.json), [duplicate review](../_tracking/benguria-loss-duplicates-review-2026-10-19.json) and [independent scope audit](../_tracking/parallel/continuum/benguria-loss-loop-independent-scope-audit-2026-10-19.json) record exact reading extents and limitations.
