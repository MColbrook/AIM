# Sharp-degree hyperbolicity of generic projective hypersurfaces

## Problem statement

For integers \(n\ge3\) and \(d\ge2n-1\), let
\[
 \mathcal P_{n,d}=\mathbb P\!\left(H^0(\mathbb P^n_{\mathbb C},\mathcal O(d))\right)
\]
be the parameter space of degree-\(d\) complex projective hypersurfaces.

Is there a nonempty Zariski-open subset \(U_{n,d}\subset\mathcal P_{n,d}\) such that every hypersurface \(X\) parametrized by \(U_{n,d}\) is smooth and Kobayashi hyperbolic?

Kobayashi hyperbolicity means that the Kobayashi pseudodistance separates distinct points. Since \(X\) is compact, this is equivalent to every holomorphic map \(\mathbb C\to X\) being constant. Here **generic** means a Zariski-open condition; **very general** allows removing countably many proper algebraic subsets.

## Application

This asks whether a linear degree threshold forces generic complex projective hypersurfaces to exclude entire holomorphic curves. It connects algebraic degree bounds with invariant complex metrics.

## References

- O. Debarre, G. Pacienza and M. Păun, *Non-deformability of entire curves in projective hypersurfaces of high degree*, **Annales de l'Institut Fourier** 56(1) (2006), 247–253. [Published article](https://doi.org/10.5802/aif.2178), introduction, p. 247.
- L. Hou, D. T. Huynh, J. Merker and S.-Y. Xie, *Vanishing of Invariant 2-Jet Differentials and Improved Hyperbolicity Degree Bounds in Dimension Two*, [arXiv:2603.14881v4](https://arxiv.org/html/2603.14881v4), §1.1 and §7.2.
- S.-Y. Xie and S. Zhao, *Kobayashi Hyperbolicity of General Surfaces via the Poincaré Problem*, [arXiv:2609.06644](https://arxiv.org/abs/2609.06644).

## Status review

Checked **30 October 2026**. The sharp conjecture remains explicitly stated in the current primary source. Its Remark 7.5 records hyperbolicity for generic surfaces in \(\mathbb P^3\) of degree at least 17. That still leaves the predicted threshold 5 in this dimension and the full statement above.

High-degree theorems and algebraic hyperbolicity do not settle this sharp question. OpenAI's canonical-ampleness announcement assumes hyperbolicity, so it does not provide the missing implication. Current searches and semantic comparisons with all-status AIM/OpenAI records and the developing collection found no equivalent entry or complete resolution announcement. This is a dated, bounded check.

The [hypersurface-complement question](lead-742d989dae42da00.md) has a different degree threshold and is recorded separately.
