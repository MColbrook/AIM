# Boundary-pole decay of the pluricomplex Green function

**Research status:** Open problem; reviewed 16 October 2026.

## Problem statement

Let $`\Omega\subset\mathbb C^n`$, $`n\ge2`$, be a bounded hyperconvex domain: there exists a negative plurisubharmonic exhaustion $`\rho`$, with $`\{\rho<c\}\Subset\Omega`$ for every $`c<0`$. Define

```math
g_\Omega(z,w)=\sup\{u(z):u\in\operatorname{PSH}(\Omega),\ u\le0,\ \limsup_{s\to w}(u(s)-\log\|s-w\|)<\infty\}.
```

For every nonempty compact $`K\Subset\Omega`$ and every sequence $`w_j\in\Omega`$ with $`\operatorname{dist}(w_j,\partial\Omega)\to0`$, must

```math
\sup_{z\in K}|g_\Omega(z,w_j)|\longrightarrow0?
```

## Application

This asks how a singular complex Monge–Ampère potential changes as its source approaches the boundary. Such estimates also control boundary behavior of the Bergman metric. The Green function need not be symmetric in its two arguments.

## References

1. S. Dinew, V. Guedj and A. Zeriahi, *Open problems in pluripotential theory*, Complex Variables and Elliptic Equations 61(7) (2016), 902–930, Question27, preprint p14. [Primary preprint](https://arxiv.org/abs/1511.00705).
2. Z. Błocki, *Cauchy–Riemann meet Monge–Ampère*, Bulletin of Mathematical Sciences 4 (2014), 433–480, §5 and Proposition5.1. [Publisher](https://doi.org/10.1007/s13373-014-0058-2).

## Status review

Reviewed 16 October 2026. The assertion holds for pseudoconvex domains with Lipschitz boundary. On arbitrary bounded hyperconvex domains, convergence in every finite $`L^p`$ norm is known; this does not establish the displayed locally uniform convergence. Searches located no complete resolution of the rough-boundary target. The [review packet](../_tracking/parallel/complex-bayesian/green-boundary-pole-review.json) records current primary comparisons and bounded catalogue checks. No equivalent question was found in the all-status AIM and FURTHER collections or the indexed OpenAI announcements. The six matching Prove2Me listing contexts concern other Green functions or meromorphic poles; their proof contents were not certified.

Only compact subsets of the interior are involved. Uniformity up to distinct boundary points is a stronger assertion and is not part of this question.
