# Positive-area images of non-removable Jordan curves

**Area:** Complex analysis, conformal welding and geometric measure theory

**Status:** Open general question; proved for flexible curves

**Last checked:** 2026-10-20

## Problem statement

Let $\Gamma$ be a closed Jordan curve in the Riemann sphere. Write $CH(\Gamma)$ for the sphere homeomorphisms that are conformal away from $\Gamma$. The curve is *conformally removable* if every map in $CH(\Gamma)$ is Möbius.

**Question.** If $\Gamma$ is not conformally removable, must there exist $f\in CH(\Gamma)$ such that $f(\Gamma)$ has positive planar area (after choosing a sphere chart avoiding one point of the image)?

The quantifier ranges over **every** non-removable Jordan curve. The known flexible-curve case alone does not answer it. This is Bishop's Question 7 and the curve case of Younsi's Question 5.27.

## Application

A positive answer would turn abstract non-removability into a concrete geometric deformation with an area-bearing image. Bishop explains that it would also help distinguish curves with the same conformal welding beyond Möbius equivalence.

## References

1. Malik Younsi, [*On removable sets for holomorphic functions*](https://arxiv.org/html/1503.02582v1), EMS Surveys in Mathematical Sciences **2** (2015), 219–254, §5.5, Question 5.27 (the general compact-set form).
2. Christopher J. Bishop, [*Conformal removability is hard*](https://www.math.stonybrook.edu/~bishop/papers/notborel.pdf), author preprint revised 26 December 2025, physical pp. 3 and 46, Question 7 (the Jordan-curve form).
3. Alex Rodriguez, [*Flexible curves and Hausdorff dimension*](https://arxiv.org/abs/2601.14125v1), arXiv v1, 20 January 2026, abstract. The announced result supplies positive-area images for flexible curves, a residual but restricted class.

## Status review

Bishop's revised question asks about every non-removable curve. Rodriguez's 2026 preprint expressly presents the flexible-curve theorem as a particular case of the general conjecture; no all-curve result is inferred. Bounded current and announcement searches through 2026-10-20 located no matching complete resolution. The broader all-compact-set version is not asserted here as separately checked.

A local semantic search found no equivalent AIM or FURTHER page. The nearby [union-closure question](lead-ac40b0e5c81f4c56.md) concerns a different property. [Primary-source](../_tracking/nonremovable-curve-positive-area-primary-2026-10-20.json), [current-status](../_tracking/nonremovable-curve-positive-area-current-2026-10-20.json), [duplicate](../_tracking/nonremovable-curve-positive-area-duplicates-2026-10-20.json) and [coordinator](../_tracking/nonremovable-curve-positive-area-coordinator-2026-10-20.json) receipts document the bounded checks. They do not certify the full later proof.
