# Is maximality local for arbitrary plurisubharmonic functions?

**Research status:** Open problem; reviewed 16 October 2026.

## Problem statement

Let $`\Omega\subset\mathbb C^n`$, $`n\ge2`$, be a domain and let $`u\in\operatorname{PSH}(\Omega)`$ satisfy $`u\not\equiv-\infty`$. Call $`u`$ **maximal** if, for every $`v\in\operatorname{PSH}(\Omega)`$ satisfying $`v\le u`$ outside a compact subset of $`\Omega`$, one has $`v\le u`$ throughout $`\Omega`$.

Suppose every point has an open neighborhood on which the restriction of $`u`$ is maximal. Must $`u`$ be maximal on $`\Omega`$? No boundedness, analytic-singularity or Monge–Ampère domain-of-definition assumption is imposed.

## Application

Maximal functions extend solutions of the homogeneous complex Monge–Ampère equation to singular plurisubharmonic functions for which that equation may not be defined. Locality would permit local comparisons to establish global extremality in this setting.

## References

1. Z. Błocki, *A note on maximal plurisubharmonic functions*, Uzbek Mathematical Journal (2009), no.1, 28–32; question on p29. [Author PDF](https://gamma.im.uj.edu.pl/~blocki/publ/max.pdf).
2. S. Dinew, V. Guedj and A. Zeriahi, *Open problems in pluripotential theory*, Complex Variables and Elliptic Equations 61(7) (2016), 902–930, Question3, preprint p4. [Primary preprint](https://arxiv.org/abs/1511.00705).
3. T. D. Do and P. H. Hiep, *Local-to-global maximality for plurisubharmonic functions with locally analytic singularities*, arXiv:2610.05937v2 (15 October2026), Theorem1.1. [Preprint](https://arxiv.org/abs/2610.05937).
4. T. D. Do and P. H. Hiep, *Comparison principles for local plurisubharmonic potentials on complex manifolds and applications*, arXiv:2610.05948v2 (6 October2026), assumption(8) and Theorem1.5. [Preprint](https://arxiv.org/abs/2610.05948).

## Status review

Reviewed 16 October 2026. Locality is known for locally bounded functions and appropriate Monge–Ampère domains of definition. Recent preprints cover locally analytic singularities with a bounded remainder, and a restricted analytic/Cegrell class in dimension two. These assumptions do not give arbitrary singularities. Błocki’s 2009 counterexample concerns a different truncation-convergence statement.

No equivalent question was found in all-status AIM, retained entries, the developing FURTHER list or the indexed OpenAI announcement families. Prove2Me’s matching plurisubharmonic contexts concern classical pseudoconvexity and smoothing, rather than this maximality question. The [review packet](../_tracking/parallel/complex-bayesian/psh-local-maximality-review.json) records exact partial-result assumptions, current searches and the limits of the catalogue comparison.
