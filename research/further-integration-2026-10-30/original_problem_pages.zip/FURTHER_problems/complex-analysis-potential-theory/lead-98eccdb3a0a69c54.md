# The critical opening for asymptotic Borel surjectivity

**Area:** Complex analysis and asymptotic analysis

**Status:** Open in the cited literature in general; no matching complete resolution or announcement located.

**Last checked:** 2026-10-28

## Problem statement

Let $M=(M_p)_{p\ge0}$, $M_0=1$, be strongly regular: positive and logarithmically convex, with constants $A,B>0$ such that
$$
M_{p+q}\le A^{p+q}M_pM_q,\qquad
\sum_{q\ge p}\frac{M_q}{(q+1)M_{q+1}}\le B\frac{M_p}{M_{p+1}}.
$$
Set $m_p=M_{p+1}/M_p$ and
$$
\gamma(M)=\sup\{a>0:(m_p/(p+1)^a)_p\text{ is almost increasing}\}.
$$
Almost increasing means $c_p\le Kc_q$ whenever $p\le q$, for a fixed $K$.

On the logarithm's Riemann surface put $S_\alpha=\{z:|\arg z|<\pi\alpha/2\}$, with $0<|z|<\infty$. Prescribe $\widehat f=\sum a_pz^p$ satisfying $|a_p|\le CA^pM_p$. Define three holomorphic classes:

- $\widetilde{\mathcal A}_M$: for each bounded proper subsector $T$ of $S_\alpha$, some $C_T,A_T>0$ satisfy
  $$|f(z)-\sum_{p<N}a_pz^p|\le C_TA_T^NM_N|z|^N\quad(z\in T,\ N\ge0).$$
- $\widetilde{\mathcal A}^{u}_M$: that estimate holds throughout $S_\alpha$ with one pair of constants.
- $\mathcal A_M$: some $C,A>0$ satisfy $|f^{(p)}(z)|\le CA^p p!M_p$ throughout $S_\alpha$.

Let $\mathcal S$ denote the openings $\alpha>0$ for which the coefficient map onto all prescribed series is surjective. Is
$$
\mathcal S(\widetilde{\mathcal A}_M)=(0,\gamma(M)],\qquad
\mathcal S(\widetilde{\mathcal A}^{u}_M)=\mathcal S(\mathcal A_M)=(0,\gamma(M))
$$
always true? At the critical opening this asks for nonuniform surjectivity and uniform non-surjectivity.

## Application

The endpoint controls how far a divergent formal expansion can be realized by an analytic solution in a sector.

## References

1. J. JimÃ©nez-Garrido, J. Sanz and G. Schindl, [*Injectivity and surjectivity of the asymptotic Borel map in Carleman ultraholomorphic classes*](https://arxiv.org/pdf/1805.01153), Definitions 2.1â€“2.2 and 4.1, Section 2.3, Remark 4.20 and Table 4, p.30. *Journal of Mathematical Analysis and Applications* **469** (2019), 136â€“168; [DOI](https://doi.org/10.1016/j.jmaa.2018.09.011).
2. The same authors, [*Surjectivity of the asymptotic Borel map in Carlemanâ€“Roumieu ultraholomorphic classes defined by regular sequences*](https://doi.org/10.1007/s13398-021-01119-y), *RACSAM* **115** (2021), 181, end of Section 3.
3. J. JimÃ©nez-Garrido, I. Miguel-Cantero, J. Sanz and G. Schindl, [*Surjectivity of the asymptotic Borel map in Carleman ultraholomorphic classes defined by sequences with shifted moments*](https://doi.org/10.1186/s13660-026-03485-w), *Journal of Inequalities and Applications* **2026**, 85, Theorem 2.10 and Section 4.

## Status review

Interior/exterior bounds are known. The uniform and derivative endpoints are excluded for rational $\gamma(M)$; important subclasses admit nonuniform realizations at the endpoint. The 2021 article repeats the general conjecture, while the 2026 theorem retains the endpoint bracket. Its Beurling results use different quantifiers and do not settle this Roumieu question.

The [coordinating review](../_tracking/focused-Borel-map-critical-opening-C191-A-20261028/ROOT-FINAL-SCIENTIFIC-REVIEW.json) records primary, current-resolution, announcement and semantic duplicate checks, with independent normalization review. Bounded checks do not prove continued openness.
