# Does absence of a rational first integral force a foliation's tangent sheaf to split?

**Area:** Holomorphic foliations and algebraic geometry

**Status:** Problem 3 remains unresolved in the bounded 21 October 2026 search; several lower-degree and structured cases are known.

**Last checked:** 2026-10-21

## Problem statement

Let \(\mathcal F\) be a codimension-one holomorphic foliation on complex projective three-space \(\mathbb P^3\). Suppose its rank-two tangent sheaf \(T_{\mathcal F}\) is locally free. If \(\mathcal F\) has no invariant hypersurface, must \(T_{\mathcal F}\) split as a direct sum of line bundles? The source also asks the stronger question with the weaker assumption that \(\mathcal F\) has no rational first integral.

Both clauses are Problem 3 of da Costa's published article. They concern holomorphic *foliations*, not arbitrary nonintegrable distributions, and the ambient space is \(\mathbb P^3\).

## Application

Splitting makes the tangent sheaf's geometry explicit and helps organize families of foliations on projective space. The added hypotheses test whether known nonsplit examples depend on their rational first integrals.

## References

1. Raphael Constant da Costa, [*Splitting aspects of holomorphic distributions with locally free tangent sheaf*](https://doi.org/10.4171/RMI/1650), *Revista Matemática Iberoamericana* **42** (2026), no. 6, 1997–2048, Problem 3 on p. 2046 and Corollary 6.23 on p. 2045. The [publisher PDF](https://ems.press/content/serial-article-files/54233?nt=1) gives the exact hypotheses.
2. D. Faenzi, M. Jardim, J. Vallès and A. Muniz, *Logarithmic sheaves of complete intersections*, *Annali della Scuola Normale Superiore di Pisa — Classe di Scienze* **26** (2025), no. 3, 1703–1763, Theorem E as cited in reference [15] of da Costa. Its known nonsplit foliations have rational first integrals.
3. Pedro Pfarrius Barbassa, [*Distributions with Unstable Tangent Sheaf on* \(\mathbb P^3\)](https://doi.org/10.1007/s00009-026-03120-4), *Mediterranean Journal of Mathematics* **23** (2026), article 120, §3, treats specified subfoliation cases rather than the unrestricted condition in Problem 3.

## Status review

Da Costa proves splitting when there is a nonzero tangent holomorphic vector field and, under the no-invariant-hypersurface hypothesis, for degree at most three. The known nonsplit rational foliations do not refute either clause. The later 2026 subfoliation result covers additional structured cases, but its stated theorems do not settle arbitrary degree. Its locally free nonsplit example is described as a *distribution*; integrability and the absence of invariant hypersurfaces or rational first integrals are not established. A bounded search on 21 October 2026 found no matching full resolution or AIM/FURTHER duplicate; absence from search results is not proof of openness. The [independent primary audit](../_tracking/parallel/complex-bayesian/journal0265-rmi1650-problem3-independent-owner-audit.json) and [coordinator scope and duplicate check](../_tracking/rmi1650-foliation-splitting-coordinator-check-2026-10-21.json) record the evidence.
