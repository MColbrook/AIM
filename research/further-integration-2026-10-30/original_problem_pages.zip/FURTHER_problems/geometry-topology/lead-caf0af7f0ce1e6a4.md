# Unknotting number and genus of positive fibered knots

**Area:** Geometric topology and knot theory  
**Status:** Open; no matching resolution located in the checks below  
**Last checked:** 2026-10-25  
**Source:** B307, *K3: A New Problem List in Low-Dimensional Topology*, Problem 1.5(a); the precise statement is Conjecture 1.1 of [1].

## Problem statement

Let \(K\subset S^3\) be a smooth knot. Suppose that \(K\) admits an oriented diagram with every crossing positive and that its exterior fibers over \(S^1\), with a Seifert surface as fiber. Must
\[
u(K)=g(K)?
\]

Here \(g(K)\) is the minimum genus of a connected compact orientable surface embedded in \(S^3\) with boundary \(K\). The unknotting number \(u(K)\) is minimized over **all diagrams** and crossing-change sequences, allowing isotopy between changes. Positivity is a property of the knot, rather than a prescribed diagram.

## Application

This asks whether a geometric surface invariant determines the minimum crossing-change complexity throughout the class of positive fibered knots. It extends a known equality for closures of positive braids.

## Known progress

The lower bound \(u(K)\ge g(K)\) is known in this class. Kegel and collaborators obstruct three approaches to proving the opposite bound. Their Theorem 1.5 concerns the crossings of a particular genus-seven knot diagram: that diagram needs nine changes. The unrestricted value nine is separately proposed in Conjecture 1.6, rather than proved. Thus their diagram theorem does not settle the question above.

## References

1. M. Kegel, L. Lewark, N. Manikandan, F. Misev, L. Mousseau and M. Silvero, *On unknotting fibered positive knots and braids*, [accepted arXiv version 2312.07339v2](https://arxiv.org/html/2312.07339v2), Conjectures 1.1 and 1.6 and Theorem 1.5. *Annali della Scuola Normale Superiore di Pisa, Classe di Scienze* **27**(3) (2026), 1499–1517, [doi:10.2422/2036-2145.202401_001](https://doi.org/10.2422/2036-2145.202401_001).
2. R. İ. Baykur, R. C. Kirby and D. Ruberman (eds.), *K3: A New Problem List in Low-Dimensional Topology*, Mathematical Surveys and Monographs **295**, AMS, 2026, Problem 1.5(a), [author copy](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), physical p. 14.

## Status review

Checked on 25 October 2026 against the primary statements, current version records, bounded resolution and announcement searches, all-status AIM/OpenAI statements, and all local findings and admitted pages. No matching resolution was located. AIM 237 concerns trefoil ropelength; the local Montesinos–Morton target concerns branched coverings of fibered links. Neither asks this unknotting-number question.

A secondary site's description of [1] as a disproof conflicts with the actual accepted text and is not used. The publisher metadata was checked; its subscription PDF was inaccessible, so parity with the published full body is not claimed. These are dated, bounded checks, with precise evidence retained in the research ledger.
