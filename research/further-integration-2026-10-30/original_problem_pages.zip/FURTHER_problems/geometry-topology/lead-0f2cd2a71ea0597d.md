# Must every blow-down of a perimeter minimizer be a cone in an RCD space?

## Problem statement

Let \((X,d,\mathcal H^N)\) be a noncollapsed \(\operatorname{RCD}(0,N)\) metric-measure space with positive Euclidean volume growth,
\[
\lim_{r\to\infty}\frac{\mathcal H^N(B_r(x))}{r^N}>0.
\]
Let \(E\subset X\) be a global perimeter-minimizing set and fix \(x\in\partial E\). Take any sequence of scales \(r_j\to\infty\) along which the rescaled pointed space and set converge to an asymptotic metric-measure cone \((C(Z),o)\) and a limiting perimeter minimizer \(F\subset C(Z)\). Must **every** such \(F\) itself be a cone, invariant under radial dilation about \(o\)?

The authors prove that every ambient asymptotic cone contains *some* globally perimeter-minimizing conical set. Their proof first obtains a blow-down \(F\) of the given \(E\) and may then blow down \(F\) again to produce a cone. The open question asks whether that extra step is unnecessary for **all** blow-downs of \(E\).

## Application

A positive answer would give a sharper description of the large-scale shape of individual perimeter minimizers under synthetic nonnegative Ricci curvature, not just existence of a conical minimizer in the limiting space.

## References

1. Francesco Fiorani, Andrea Mondino and Daniele Semola, [*Monotonicity formula and stratification of the singular set of perimeter minimizers in RCD spaces*](https://doi.org/10.4171/CMH/598), *Commentarii Mathematici Helvetici* **101** (2026), 193–238, Theorem 1.7 and following open question on pp. 197–198, with proof on p. 230. The [published PDF](https://ems.press/content/serial-article-files/52484?nt=1) supplies the exact hypotheses.
2. Alessandro Cucinotta and Mattia Magnabosco, [*On perimeter minimizing sets in manifolds with quadratic volume growth*](https://doi.org/10.1515/crelle-2026-0017), *Journal für die reine und angewandte Mathematik* **834** (2026), 1–26. Its product-and-slice theorem has stronger smooth curvature and quadratic growth hypotheses.

## Status review

Theorem 1.7 concerns existence of at least one conical minimizer in each ambient asymptotic cone; it does not show that the particular limit of \(E\) along every scale sequence is conical. The later product-and-slice result covers a restricted smooth setting with quadratic volume growth, outside the general Euclidean \(N\)-volume-growth hypothesis. Bounded searches and an independent source-and-scope audit on 21 October 2026 found no complete resolution of the general RCD question or a duplicate in AIM/FURTHER. This is a live-status assessment, not a proof of unsolvedness.
