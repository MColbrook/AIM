# Are compact convex sets in arbitrary linear metric spaces absolute retracts?

## Problem statement

Let $E$ be a metrizable topological vector space, without assuming local convexity, and let $C\subset E$ be compact and convex. Must $C$ be an **absolute retract**? That means that whenever $C$ is embedded as a closed subset of a metrizable space $Y$, there is a continuous retraction $Y\to C$.

The question asks for the absolute-retract property of every such $C$. It does not ask only whether continuous self-maps of $C$ have fixed points.

## Application

The absolute-retract property lets continuous maps into $C$ extend from closed subsets of metrizable spaces. A positive answer would bring this extension theory to compact convex sets even when the surrounding vector space has no locally convex topology.

## References

1. T. Banakh, R. Cauty and M. Zarichnyi, *Open problems in infinite-dimensional topology*, in [*Open Problems in Topology II*](https://www.sciencedirect.com/book/9780444522085/open-problems-in-topology-ii), Elsevier (2007), Chapter 56, Question 5.1, printed p. 605. The [contributor-hosted book PDF](https://carmamaths.org/resources/jon/Preprints/Books/Open%20Probs%20in%20Top/open2.pdf) contains the checked passage; full published-text parity remains unverified.
2. Lê Hoàng Trí and Nguyễn Hoàng Thanh, [*Some remarks on the AR-problem*](https://math.ac.vn/public/uploads/files/0903389.pdf), *Acta Mathematica Vietnamica* **34** (2009), 389–400, pp. 389–390, Problems 1.1–1.2 and Theorems 1.3–1.4.
3. Lê Hoàng Trí and Trần Lê Thương, [*The AR-property of compact convex sets in metric linear spaces with a basis*](https://jst-ud.vn/jst-ud/article/download/8125/5698), *The University of Danang Journal of Science and Technology* **20** (11.1) (2022), 39–42.

## Status review

The 2022 article explicitly treats the unrestricted problem as unresolved and proves the absolute-retract property when the linear metric space has a Schauder basis, including some spaces that are not locally convex. Dugundji's classical theorem handles locally convex spaces, while Cauty's noncompact counterexample does not apply to compact $C$. Searches through 22 October 2026 found no announced unrestricted resolution or exact AIM/FURTHER duplicate. These are bounded checks, recorded in the [status](../_tracking/compact-convex-AR-2026-10-22-status.json) and [duplicate](../_tracking/compact-convex-AR-2026-10-22-duplicates.json) audits; the contributor-hosted chapter's full published-text parity remains unverified.
