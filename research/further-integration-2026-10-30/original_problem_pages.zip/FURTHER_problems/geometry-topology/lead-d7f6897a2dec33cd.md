# Must every Reeb flow on a closed non-lens-space 3-manifold have infinitely many simple periodic orbits?

**Area:** Contact dynamics and low-dimensional topology

**Status:** Open in the 2026 K3 problem list; no later unrestricted resolution found in a bounded search

**Last checked:** 2026-10-21

## Problem statement

Let $\lambda$ be any contact form on a closed three-manifold $Y$ that is not a lens space. Must its Reeb flow have **infinitely many geometrically distinct simple periodic orbits**?

The word *any* matters: the form may be degenerate, and the first Chern class of its contact structure need not be torsion.

## Application

This would rule out a Reeb flow with a finite number greater than two of simple periodic orbits on any non-lens-space three-manifold. It extends existing two-or-infinity results beyond their separate nondegeneracy and torsion-Chern-class settings.

## References

1. [*K3: A New Problem List in Low-Dimensional Topology*](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), author-approved preliminary version (2026), Chapter 3, Problem 3.46, p. 164.
2. D. Cristofaro-Gardiner, U. Hryniewicz, M. Hutchings and H. Liu, [*Contact three-manifolds with exactly two simple Reeb orbits*](https://arxiv.org/abs/2102.04970), Geometry & Topology 27 (2023), 3801–3831.
3. D. Cristofaro-Gardiner, U. Hryniewicz, M. Hutchings and H. Liu, [*Proof of Hofer–Wysocki–Zehnder's two or infinity conjecture*](https://arxiv.org/abs/2310.07636), proving the torsion-first-Chern-class case without nondegeneracy.
4. D. Cristofaro-Gardiner, M. Hutchings and D. Pomerleano, [*Torsion contact forms in three dimensions have two or infinitely many Reeb orbits*](https://arxiv.org/abs/1701.02262), proving the nondegenerate torsion-Chern case.
5. M. Asaoka and T. Shibata, [*Positive hyperbolic periodic orbits for area-preserving maps and Reeb flows*](https://arxiv.org/abs/2608.26508), arXiv:2608.26508 (August 2026), assuming strong nondegeneracy for its Reeb-flow result.

## Status review

K3 explicitly says removing both the nondegeneracy and first-Chern-class assumptions simultaneously remains open. The exactly-two-orbit theorem excludes a non-lens space with *exactly two* orbits, but does not exclude three or more finite orbits. The later August 2026 theorem still assumes strong nondegeneracy. An [August 2026 seminar](https://www.math.snu.ac.kr/bbs/board.php?bo_table=Math_Seminar&day=07&month=8&wr_id=46526&year=2026) likewise presents the two-or-infinity conjecture and the torsion-Chern special case. No later unrestricted proof, counterexample, or announcement surfaced in the bounded search recorded in the [status and duplicate receipt](../_tracking/nonlens-reeb-orbits-status-2026-10-21.json).
