# Is the separation modulus of every sufficiently symmetric normed space set by its dual volume ratio?

**Area:** Metric geometry and Banach spaces

**Status:** Explicit conjecture in the source; no general resolution located in a bounded current search

**Last checked:** 2026-10-21

## Problem statement

For a metric space $X$, let $\operatorname{SEP}(X)$ be the least $\sigma$ such that, at every scale $\Delta>0$, a random partition of $X$ into sets of diameter at most $\Delta$ can be chosen with

$$\Pr[x\text{ and }y\text{ lie in different cells}]\leq \sigma\,\frac{d_X(x,y)}{\Delta}\qquad(x,y\in X).$$

Let $X$ be a finite-dimensional real normed space with **enough symmetries**: every linear operator commuting with every surjective linear isometry of $X$ is a scalar multiple of the identity. Write $n=\dim X$, and let $\operatorname{vr}(X^*)$ be the volume ratio of the unit ball of its dual: the $n$th root of its volume divided by that of a maximum-volume ellipsoid inside it.

**Naor's Conjecture 6:** Are there universal positive constants $c,C$ such that every such $X$ satisfies

$$c\,\operatorname{vr}(X^*)\sqrt n\leq\operatorname{SEP}(X)\leq C\,\operatorname{vr}(X^*)\sqrt n?$$

The constants must be independent of the space and its dimension. The memoir states a relation up to lower-order dimension factors and gives a constant-factor argument for spaces with a coordinate $1$-symmetric basis. The universal constant-factor assertion above is the remaining target.

## Application

Random partitions control how a metric space can be clustered at all scales. The proposed estimate would turn the dual ball's volume ratio into a sharp general bound for this clustering invariant, with consequences for Lipschitz extension bounds.

## References

1. A. Naor, [*Extension, Separation and Isomorphic Reverse Isoperimetry*](https://ems.press/content/book-files/47359), *Memoirs of the European Mathematical Society* **11** (2024), DOI 10.4171/MEMS/11, Introduction p.6, Conjecture 6 and equation (1.8); Section 1.6.2, Remark 41. The source gives the definitions, partial results and exact conjecture.
2. M. A. Gunes and A. Naor, [*The separation modulus of unitarily invariant matrix norms*](https://arxiv.org/html/2508.03853), arXiv:2508.03853 (2025), Introduction. A later constant-factor result for a particular family of spaces.

## Status review

The later matrix-norm result and [restricted 2026 convex-polytope result](https://doi.org/10.1112/mtk.70070) do not cover every normed space with enough symmetries. This is distinct from the [Euclidean Lipschitz-extension modulus question](lead-05291453c5ef11de.md) already listed here. The [bounded status, announcement and duplicate review](../_tracking/naor-separation-modulus-symmetry-status-2026-10-21.json) found no matching complete result; it cannot rule out unindexed work.
