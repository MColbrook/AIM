# Irrational ratios of hyperbolic three-manifold volumes

**Area:** Hyperbolic geometry and low-dimensional topology

**Status:** Open in the cited 2026 problem book; no matching resolution found in a bounded current search

**Last checked:** 2026-10-21

## Problem statement

Let $M$ and $N$ be complete orientable hyperbolic three-manifolds of finite volume, with sectional curvature normalized to $-1$. Their volumes are positive real numbers.

**Question (Thurston).** Can $M$ and $N$ be chosen so that $\operatorname{Vol}(M)/\operatorname{Vol}(N)\notin\mathbb{Q}$?

The ratio question is one precise interpretation of Thurston's phrase “not all rationally related.” A stronger interpretation asks whether the set of all such volumes spans an infinite-dimensional vector space over $\mathbb{Q}$; that stronger question is separate and is not asserted here.

## Application

An irrational ratio would show that the hyperbolic volume spectrum contains at least two distinct rational directions. This would advance our understanding of the arithmetic information encoded by three-manifold geometry and would rule out the possibility that every manifold volume is a rational multiple of one fixed volume.

## References

1. W. P. Thurston, [*Three-dimensional manifolds, Kleinian groups and hyperbolic geometry*](https://doi.org/10.1090/S0273-0979-1982-15003-0), *Bulletin of the American Mathematical Society* **6** (1982), 357–381, Problem 23, p. 380.
2. R. İnanç Baykur, R. C. Kirby and D. Ruberman (eds.), [*K3: A New Problem List in Low-Dimensional Topology*](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), American Mathematical Society, Mathematical Surveys and Monographs 295 (2026), Problem 3.2, printed p. 133 (author-approved preliminary version; read and link only).
3. F. Calegari, V. Dimitrov and Y. Tang, [*The linear independence of 1, $\zeta(2)$, and $L(2,\chi_{-3})$*](https://www.math.uchicago.edu/~fcale/papers/L2chi.pdf), introduction, p. 3. The authors distinguish irrationality of a particular hyperbolic volume from the open volume-ratio problem.

## Status review

The 2026 K3 problem book still poses this question. Calegari, Dimitrov and Tang prove an irrationality result for a related volume constant and explicitly say it does not settle rational relations between manifold volumes. A September 2026 manuscript in the OpenAI math repository claims irrationality of Catalan's constant and the volume $4G$; that single-volume claim, whether or not it holds, does not by itself prove an irrational ratio of two manifold volumes. Targeted proof, counterexample and announcement searches through 2026-10-21 found no matching pairwise result. This is a bounded search, not a guarantee about inaccessible work.

The [status and duplicate receipt](../_tracking/thurston-hyperbolic-volume-ratio-status-2026-10-21.json) records the precise scope and search limits.
