# The \(4\pi\) boundary-curvature threshold for oriented minimal surfaces

## Problem statement

Let \(\Gamma\subset\mathbb R^3\) be a smooth, simple closed curve with total *boundary-curve* curvature
\[
\operatorname{tc}(\Gamma)=\int_\Gamma |\kappa|\,ds\leq4\pi.
\]
Must every smooth, compact, oriented minimal surface spanning \(\Gamma\) be a disk? Equivalently, if such a curve bounds an oriented minimal surface that is not a disk, must \(\operatorname{tc}(\Gamma)>4\pi\)? The orientability condition matters: curves of total curvature below \(4\pi\) can bound minimal Möbius strips.

Brian White proves the disk conclusion for \(\operatorname{tc}(\Gamma)\leq 2\pi\sqrt{2\pi/e}\), approximately \(1.014\cdot3\pi\), and conjectures the sharp \(4\pi\) threshold for oriented surfaces. Curves of curvature less than \(4\pi+\varepsilon\) can bound oriented embedded minimal surfaces of arbitrarily high genus, so the proposed constant cannot be raised.

## Application

The conjecture asks how much bending of a single boundary curve is needed before an oriented spanning minimal surface can acquire positive genus. A sharp answer would connect curve geometry with topology in the Plateau problem.

## References

1. Brian White, [*Boundary singularities in mean curvature flow and total curvature of minimal surface boundaries*](https://doi.org/10.4171/CMH/542), *Commentarii Mathematici Helvetici* **97** (2022), 669–689, Theorem 19 and following conjecture on p. 683; [published PDF](https://ems.press/content/serial-article-files/43576).
2. Otis Chodosh, [*Introduction to minimal surfaces*](https://web.stanford.edu/~ochodosh/Math286-min-surf.pdf), Stanford Math 286 lecture notes (updated 15 September 2025), §11, Theorem 11.5 and Open Question 2 on p. 34. This later source explicitly keeps the oriented \(4\pi\) question open.

## Status review

White's result is a strict improvement over \(3\pi\), but it does not reach \(4\pi\). The Ekholm–White–Wienholtz embeddedness theorem for a spanning minimal immersion at curvature at most \(4\pi\) does not force its topology to be a disk. The Möbius-strip examples are nonorientable and therefore do not refute the stated question. Targeted AIM/FURTHER duplicate and current-resolution searches on 21 October 2026 found no matching complete announcement. This is a bounded live-status assessment, not a proof of unsolvedness.
