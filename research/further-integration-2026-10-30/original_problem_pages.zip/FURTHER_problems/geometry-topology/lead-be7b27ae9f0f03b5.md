# Are all flat SU(2) Chern–Simons values on closed three-manifolds rational?

**Area:** Gauge theory and three-manifold topology

**Status:** Open in the 2026 K3 problem list; no later exact resolution found in a bounded search

**Last checked:** 2026-10-21

## Problem statement

Let $A$ be a flat connection on the trivial $SU(2)$ bundle over a closed oriented three-manifold $M$. Is its Chern–Simons invariant $CS(M,A)$ always rational (with the usual normalization modulo integers)? Equivalently, can an exact irrational critical value occur?

## Application

Known rationality results cover Seifert-fibered spaces and graph manifolds. An irrational value would distinguish some more general three-manifold topology from those classes. A specific hyperbolic surgery is a numerical candidate, but its irrationality remains conjectural.

## References

1. [*K3: A New Problem List in Low-Dimensional Topology*](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), author-approved preliminary version (2026), Chapter 3, Problem 3.64, pp. 177–178.
2. Y. Nozaki, K. Sato and M. Taniguchi, [*Filtered instanton Floer homology and the homology cobordism group*](https://ems.press/content/serial-article-files/48226?nt=1), Journal of the European Mathematical Society 26 (2024), 4699–4761, §1.4, Theorem 1.18 and Conjecture 1.19; [preprint record](https://arxiv.org/abs/1905.04001).

## Status review

K3 asks universal rationality and notes known positive cases for Seifert and graph manifolds. Nozaki–Sato–Taniguchi explicitly state that no irrational $SU(2)$ critical value is known. Their roughly 50-decimal-place approximation for an invariant $r_s$ of $1/2$ surgery on the mirror of knot $5_2$ motivates an irrationality conjecture, but a decimal approximation cannot settle exact rationality. Later bounded searches found no exact proof, counterexample, or announcement. The [status and duplicate receipt](../_tracking/su2-chern-simons-rationality-status-2026-10-21.json) records the scope and limits.
