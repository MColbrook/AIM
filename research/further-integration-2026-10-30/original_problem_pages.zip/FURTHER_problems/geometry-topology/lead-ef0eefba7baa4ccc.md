# The Debarre–de Jong dimension conjecture for lines on smooth Fano hypersurfaces

## Problem statement

Let $k$ be an algebraically closed field of characteristic zero, let $n\ge3$ and $1\le d\le n$ be integers, and let $X\subset\mathbb P^n_k$ be any smooth hypersurface of degree $d$. Write

$$F_1(X)=\{L\in\operatorname{Gr}(2,n+1):\mathbb P(L)\subset X\}$$

for its closed Fano scheme of projective lines. Must

$$\dim F_1(X)=2n-d-3?$$

Here dimension means the scheme's Krull dimension. The Grassmannian has dimension $2n-2$, and restricting the defining degree-$d$ equation of $X$ to a line gives $d+1$ coefficient equations, yielding the displayed expected dimension. The assertion concerns every smooth $X$.

## Application

The question asks whether smoothness controls the dimension of families of degree-one rational curves uniformly throughout the class of Fano hypersurfaces. Such line families are basic objects in the geometry of rational curves on projective varieties.

## References

1. J. M. Landsberg and O. Tommasi, *On the Debarre-de Jong and Beheshti-Starr conjectures on hypersurfaces with too many lines*, Michigan Math. J. **59**(3) (2010), 573–588. [arXiv:0810.4158v1](https://arxiv.org/pdf/0810.4158v1), Introduction, Conjecture 1.2, p. 1. The standing convention explicitly specifies an algebraically closed field of characteristic zero.
2. R. Beheshti, *Hypersurfaces with too many rational curves*, Math. Ann. **360** (2014), 753–768. [Author version](https://www.math.wustl.edu/~beheshti/hl.pdf), Corollary 3.3, pp. 13–14: the conjecture holds for $d\le8$.
3. R. Beheshti and E. Riedl, *Linear subspaces of hypersurfaces*, Duke Math. J. **170**(10) (2021), 2263–2288, [DOI 10.1215/00127094-2021-0035](https://doi.org/10.1215/00127094-2021-0035). [arXiv:1903.02481v2](https://arxiv.org/pdf/1903.02481v2), Corollary 2.5, p. 6: the conjecture holds for $n\ge2d-4$.
4. R. Beheshti and S. Mukhopadhyay, [*Higher-order tangent lines to smooth hypersurfaces*, arXiv:2610.28558v1](https://arxiv.org/pdf/2610.28558v1), October 20, 2026, Introduction and Theorem 1.2, pp. 1–2.

## Status review

Open in the cited literature; checked October 26, 2026. The known ranges $d\le8$ and $n\ge2d-4$ leave the general assertion unresolved. In particular, these two results leave a parameter region $d\ge9$ and $d\le n\le2d-5$; this description does not assert that every individual case in that region is equally unexplored.

The October 2026 paper still states the full Debarre–de Jong conjecture and proves an expected-dimension theorem for pointed lines with contact of order six. General containment in a degree-$d$ hypersurface corresponds to contact of order $d+1$, so this theorem supplies related progress without resolving the full conjecture.

The bounded current-literature and complete-announcement comparison located no matching full solution. All-status AIM and FURTHER records and the current OpenAI collection were compared. Selected primary theorem and hypothesis passages were checked; no complete-proof certification is claimed.
