# Real-energy nullspace on nontrapping Lorentzian scattering spaces

**Area:** Mathematical relativity and spectral theory

**Status:** Open in the cited literature; no matching complete resolution or announcement located.

**Last checked:** 2026-10-28

## Problem statement

Let $M$ be a connected compact smooth manifold with boundary, $\dim M\ge2$, and $g$ a smooth Lorentzian scattering metric. Locally its tangent frame is $x^2\partial_x,x\partial_{y_j}$, where $x$ defines the boundary. Let $G$ denote the dual metric quadratic form.

Impose the full source/sink hypotheses of Vasy, Section 2: the rescaled Hamilton flow has normally radial sources $L_-$ and sinks $L_+$ at base infinity, transverse to fiber infinity. Every characteristic orbit outside these sets tends to $L_+$ forward and $L_-$ backward, both on $G=0$ at fiber infinity and on $G=\lambda$ at base infinity.

For each real $\lambda\ne0$ satisfying these assumptions, must
$$
u\in\dot C^\infty(M),\qquad (\square_g-\lambda)u=0
\quad\Longrightarrow\quad u=0?
$$
Here $\dot C^\infty(M)$ means smooth functions vanishing to every order at the boundary. Proposition 7 identifies this with the scalar Feynman/anti-Feynman nullspace question in Remark 6. The zero-energy threshold is excluded.

## Application

Injectivity removes the finite-dimensional obstruction to global limiting Feynman propagators for curved-spacetime wave equations.

## References

1. A. Vasy, [*Essential self-adjointness of the wave operator and the limiting absorption principle on Lorentzian scattering spaces*](https://arxiv.org/html/1712.09650v1), Sections 2 and 4, Theorem 5, Remark 6, Proposition 7; *Journal of Spectral Theory* **10** (2020), 439–461. [DOI](https://doi.org/10.4171/JST/301).
2. K. Taira, [*Limiting absorption principle and equivalence of Feynman propagators on asymptotically Minkowski spacetimes*](https://arxiv.org/html/2012.07946v2), Theorems 1.1 and 1.4; *Communications in Mathematical Physics* **388** (2021), 625–655. [DOI](https://doi.org/10.1007/s00220-021-04196-7).
3. Q. Jia, M. Molodyk and E. Sussman, [*The essential self-adjointness of the wave operator on radiative spacetimes*](https://doi.org/10.1007/s00220-025-05532-x), *Communications in Mathematical Physics* **407** (2026), 36, Theorems A–B.
4. M. Molodyk and A. Vasy, [*The Feynman propagator for massive Klein-Gordon fields on radiative asymptotically flat spacetimes*](https://arxiv.org/html/2510.04308v2), Theorem 1.1 and Sections 2.5 and 5.

## Status review

Taira's general limiting-absorption theorem retains possible embedded eigenvalues; their exclusion requires additional hypotheses. The 2026 self-adjointness/nonreal-parameter theorem does not settle real-energy injectivity. Molodyk–Vasy establish invertibility for more structured asymptotically flat geometries with additional causal assumptions.

The [coordinating review](../_tracking/focused-scattering-wave-real-nullspace-J060-C182-C-20261028/ROOT-FINAL-SCIENTIFIC-REVIEW.json) records primary, latest-version, current-resolution/announcement and semantic duplicate checks, with an independent formulation review. The formulation uses the archived preprint's numbering; full published-body parity was not established. These bounded checks do not prove continued openness.
