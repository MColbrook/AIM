# 106. Isomorphic reverse Faber–Krahn inequality for symmetric convex bodies

**Area:** Spectral geometry and convex bodies
**Status:** 🟡 PARTIAL
**Last checked:** 2026-10-30

## Problem statement

For a convex body $`K\subset\mathbb R^n`$, let $`\lambda_1(K)`$ be the first Dirichlet eigenvalue of $`-\Delta`$ on its interior and let $`|K|`$ denote its volume. **Is there a universal constant $`C`$** such that every origin-symmetric convex body $`K`$ admits a volume-preserving linear map $`S\in\mathrm{SL}_n(\mathbb R)`$ with

```math
\lambda_1(SK)\,|K|^{2/n}\le Cn.
```


The ordinary Faber–Krahn inequality supplies the matching lower bound up to a universal constant. Thus the question asks for the correct dimension order after the best volume-preserving linear change of coordinates. Naor's Conjecture 35 states this in $`\asymp n`$ form and proves that it is equivalent, up to universal constants, to his weak isomorphic reverse-isoperimetry Conjecture 10.

## Application

An affirmative answer would give an optimal-order spectral normalization for every symmetric convex body. Through Naor's equivalence, it would also give a large subbody with near-ball-order isoperimetric quotient after a linear change of coordinates, a geometric ingredient in random clustering and Lipschitz-extension bounds.

## References

1. A. Naor, [*Extension, Separation and Isomorphic Reverse Isoperimetry*](https://ems.press/content/book-files/47359), *Memoirs of the European Mathematical Society* **11** (2024), DOI [10.4171/MEMS/11](https://doi.org/10.4171/MEMS/11), Introduction, printed p. 33, equation (1.62), Conjecture 35 and Remark 36. The book states the problem and its equivalence to Conjecture 10.
2. M. A. Gunes and A. Naor, [*Optimal Randomized Clustering of Matrices*](https://drops.dagstuhl.de/storage/00lipics/lipics-vol367-socg2026/LIPIcs.SoCG.2026.56/LIPIcs.SoCG.2026.56.pdf), *SoCG 2026*, article 56, DOI [10.4230/LIPIcs.SoCG.2026.56](https://doi.org/10.4230/LIPIcs.SoCG.2026.56), Introduction, Conjecture 6 and Theorem 5. It still calls the general problem open and proves the bound for unit balls of unitarily invariant matrix norms.
3. D. Faifman and I. Polterovich, [*The Faber–Krahn position of convex bodies and Gaussian measure inequalities*](https://arxiv.org/html/2607.21539), arXiv:2607.21539 (2026), §5.1, Conjecture 5.1 and Theorem 5.2. They prove an $`O(n\log n)`$ bound for all convex bodies, leaving the $`O(n)`$ order open.

## Status review


**Known cases:** The 2026 general Faber–Krahn-position estimate retains log n. Unitarily invariant matrix balls and polytopes with O(n) facets are special cases, not the universal symmetric-body O(n) bound.

**Remaining target:** Resolve the complete question stated under Problem statement, with all its quantifiers and hypotheses. The restricted results described here do not cover that full target.

The 2026 Gunes–Naor theorem settles unit balls of unitarily invariant matrix norms, and the 2026 Faifman–Polterovich theorem leaves a logarithmic factor for general convex bodies. A 2026 result of Ball, Böröczky and Naor handles the equivalent weak isomorphic reverse-isoperimetry problem for polytopes with $`O(n)`$ facets. None settles the stated universal claim for every origin-symmetric convex body. Naor's separate question of whether the cube gives the *exact* sharp constant $`\pi^2 n`$ is stronger and is not required here. Bounded resolution, announcement and AIM/FURTHER semantic checks found no matching full result or duplicate through 21 October 2026.

The [primary-source review](../FURTHER_problems/_tracking/isomorphic-reverse-faber-krahn-primary-2026-10-21.json), [later-status review](../FURTHER_problems/_tracking/isomorphic-reverse-faber-krahn-status-2026-10-21.json), [duplicate check](../FURTHER_problems/_tracking/isomorphic-reverse-faber-krahn-duplicates-2026-10-21.json) and [admission decision](../FURTHER_problems/_tracking/isomorphic-reverse-faber-krahn-coordinator-2026-10-21.json) record the checked scope and limits. These AI checks are not human peer review or proof that no unindexed announcement exists.


### Online recheck, 2026-10-30

The 2026 general Faber–Krahn-position estimate retains log n. Unitarily invariant matrix balls and polytopes with O(n) facets are special cases, not the universal symmetric-body O(n) bound.

Comparators and current-status sources: [status source 1](https://arxiv.org/abs/2607.21539); [status source 2](https://arxiv.org/abs/2509.13898); [status source 3](https://doi.org/10.4230/LIPIcs.SoCG.2026.56). This bounded search found no matching complete proof, counterexample or complete-solution announcement; it is not a guarantee of continued openness or an independent audit of every cited proof.

## Collection provenance

Promoted from retained further problem **FURTHER-2c5f4a2043e77042** on 2026-10-30, with its editorial scores unchanged. The [replacement register](../research/catalogue-backfill-2026-10-30/README.md) preserves the former AIM identity for this reused number and the historical research path. Earlier dated AIM-number comparisons above describe the collection at that earlier date.
