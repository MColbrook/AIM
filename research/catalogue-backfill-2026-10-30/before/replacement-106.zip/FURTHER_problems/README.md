# Further-problem collection

**ID backfill, 30 October 2026:** Of the 731 historical admissions, 521 meet I >= 6: 111 are now AIM entries and **410 remain staged here**; 210 are archived. Before duplicate checks or interpreting an old path as missing work, apply the [cut manifest](../cut_problems/move_manifest.json) and [promotion overlay](../research/catalogue-backfill-2026-10-30/manifest.json), or use the [path resolver](../cut_problems/verify_cut.py). Historical ledgers, coverage records and paused research cursors are unchanged. No research jobs were resumed.

The keep rule is **I = max(M, A) >= 6**, applied to the frozen [score snapshot](../cut_problems/_audit/score_snapshot.json).

See [the replacement register](../research/catalogue-backfill-2026-10-30/README.md), [resume handoff](RESUME.md), [workflow](WORKFLOW.md) and [source log](SOURCE_LOG.md).
