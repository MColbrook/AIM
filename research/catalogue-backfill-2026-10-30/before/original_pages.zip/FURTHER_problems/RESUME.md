# Resume handoff

**Editorial selection applied, 30 October 2026:** 731 remains the historical admission count. Of those records, 521 meet the keep rule I >= 6 and 210 have moved to ../cut_problems/FURTHER_problems/. Before path checks, duplicate checks or re-admission, consult [the relocation manifest](../cut_problems/move_manifest.json) and [the path resolver](../cut_problems/verify_cut.py). Historical ledger paths and the coverage database are preserved. A missing former page is not unreviewed work. Current AIM scope includes [the cut registry](../catalogue.json). No research jobs were resumed.

**Paused safely (2026-10-30T13:16:50.649760+00:00).** All three research lanes are idle; no source, transfer, download or extraction job remains running. Canonical totals remain **731 admitted problems, 1,326 findings and 129,234 reading units** at the 13:03:48 UTC checkpoint. The arXiv first pass remains incomplete.

**Resume first:** read the [pause handoff](_tracking/PAUSE_HANDOFF.json). It pins ten sealed but unimported batches, the pending candidates, exact producer cursors and the two saved independent primary reviews. Import new batches once; do not repeat completed source work. Producer cursors: arXiv source187 unit2/index647; journals next DOI10.5802/aif.2313; books reuse the retained 49-page B148 excerpt after identity/accessibility checks. Its scientific screening credit is zero. B127's remaining cue windows are sealed in C426, pending import; this gives no full-book completion.

All writes remain in **FURTHER_problems**. No commit, push, pull or deletion. The goal is **paused**, not complete.

**Latest checked work (2026-10-30T13:03:48.318199+00:00):** **731 admitted problems**, 1,326 findings and 129,234 reading units. Positive scientific-discovery passages cover parts of **370/741 source families (49.9% breadth)**; **zero families are exhaustively complete**.

**ArXiv is not finished.** 2,013,356 distinct IDs have been attempted; 1,223,830 have usable full-text keyword screens (**60.8%**). The remaining 789,526 comprise 599,563 coverage gaps, 27,402 fetch/extraction failures and 162,561 earlier quality-unverified attempts. Usable positives: 593,186; usable negatives: 630,644. Positive hits still require scientific/current/duplicate checks. Bulk counts are unchanged.

[Current status](_tracking/RESEARCH_STATUS.json) | [Throughput](_tracking/THROUGHPUT.json) | [Incremental validation](_tracking/research-validation-731pages-incremental-20261030.json)

**Since the 11:36:31 UTC checkpoint:** 99 finite scientific-paper passage reviews registered, **84 fresh at 57.7/wall-hour**, 15 earlier-start. Five precise candidates checked: **four admitted, one excluded**. Four finite book passes, 148 new reading rows and 488 scientific contexts in 300 windows. These are passage reviews, not whole papers or books; the rate includes elapsed coordination and connection time.

**Four new problems:** [energy-constrained closed CP cone](operators/lead-c9fe61540d4c4717.md); [spin-uniform relativistic weak coupling](spectral3/lead-778cd0242ad3adee.md); [critical-charge magnetic no-pair stability](spectral3/lead-6e5bf5da93a1daa7.md); [polynomial fewnomial positive-root bounds](numerical-analysis/lead-ec58af82e6441b04.md). Exact hypotheses, primary sources, latest results and semantic duplicate comparisons are retained on each page and its review.

**One exclusion:** dropping the mass condition in Morawiec–Zürcher Theorem3.5 fails for an explicit integrable forcing: the positive Neumann-series norms diverge. Root independently checked all remaining hypotheses and the source's L1 definition of elementary solution. No broader claim about arbitrary signed solutions or bounded forcing.

**Retained arXiv:** source1874116 through C471, unit2/index276: 126 selected records, 115 scientific-passage papers, 367 scientific contexts/266 windows. Unit1 metadata-priority frontier reached1667 only. All earlier unselected/deferred records, 17 retention gaps/785 omissions and source177's earlier debt remain pending. Reuse manifests; no whole-source coverage.

**VT journals:** full groups through157, excluding partial114/116/131: 666 attempts, 663 recovered machine articles, 19,631 machine pages and 368 scientific-passage papers. Partial groups retain12 durable records,383 pages,eight scientific papers and15 unknown reservations. AIF2027/AIF220 byte/type gaps; six AIF2126 and three AIF2233 unretained cues remain open. 158 sealed but unimported;159 continuing under its existing claim. Source/SSH/SFTP waits0 for156/157; no replay.

**Bulk arXiv boundary:** VT access now works, but the frozen compatible phase has no already-supported unstarted route. Clean legacy856–865 contains10,000 records; current accepted batch profiles are15,000/25,000. Legacy866's1,000 records have unknown worker/provenance policy. Unsupported routes and other quality gaps remain explicit; do not pad batches with completed IDs or claim completion from keyword attempts.

**Books:** canonical C416/B070 four primary preview pages, C418/B176 two ending pages, C420/B021 first-edition1–486 keyword frontier, and C422/B127. B127's704-native gate contains647 scientific pages,one actual blank and56 front/back pages;19 positive pages plus7 support pages read,71 positive pages deferred. Zero full-book closure. C424 logarithmic SU(2) approximation and other precise owners await Root checks; C426 reads retained B127 contexts without another extraction/gate.

**Continuity:** B alone handles pipeline maintenance/cleanup. A and C continue discovery/current checks. Isolated malformed/access records stay gaps. Later ENDs after these canonical cursors have zero credit until their single import. All writes remain inside **FURTHER_problems**. No commit, push, pull or other Git operation. Goal paused. Historical records below are provenance; current register supersedes their counters/cursors.

**Next cursors and reservations:**
Inspect the complete current register and each exclusive claim before assigning work. The following updates supersede their predecessor cursors; other recorded source gaps remain pending.

```json
{
  "Allaire_conductivity_hold": {
    "bytes": 3775,
    "path": "_tracking/B159-conductivity-Remark3.2.26-focused-current-gate-C-20261027/EXACT-SOURCE-GATE-FINAL-HOLD-C-HANDOFF.json",
    "sha256": "a91bbf45153331b0734ecc35625a56a8fed41c2545344e92bb1959eacb75ae40"
  },
  "B003": {
    "finite_updates": [
      {
        "Root_binding": {
          "bytes": 3868,
          "path": "_tracking/B003-B004-B021-new-disjoint-native-science-C-20261028/ROOT-12UNITS-328NATIVE-ALL14-WINDOWS-7SUPPORT-LITERAL-BINDINGS-PASS-20261028.json",
          "sha256": "aa84f4e927da93377135d5b59771c0e9fe54c08943b5512074989d43c75b2587"
        },
        "Root_reconciliation": {
          "bytes": 846,
          "path": "_tracking/B003-B004-B021-new-disjoint-native-science-C-20261028/ROOT-THREE-FINITE-BUNDLES-ACTUAL-BREADTH-127179UNITS-RECONCILIATION-ONCE-20261028.json",
          "sha256": "dc71ead83e02108704f31cc1e991e100b64b83cc4c248ddc35303732bea584ea"
        },
        "new_context_characters": 20234,
        "new_native_pages": 328,
        "new_scientific_main_appendix_pages": 328,
        "new_substantive_scientific_notes_pages": 0,
        "new_windows": 14,
        "source_ids": [
          "B003",
          "B004",
          "B021"
        ],
        "whole_family_credit": 0
      }
    ],
    "next_cursor": "See pinned ownerfrontiers and Rootbindings; excludeallalreadyreadfiniteextents. Exactcandidategatesremainrequired.",
    "remaining_gaps_preserved": true,
    "whole_family_complete": false
  },
  "B004": {
    "finite_updates": [
      {
        "Root_binding": {
          "bytes": 3868,
          "path": "_tracking/B003-B004-B021-new-disjoint-native-science-C-20261028/ROOT-12UNITS-328NATIVE-ALL14-WINDOWS-7SUPPORT-LITERAL-BINDINGS-PASS-20261028.json",
          "sha256": "aa84f4e927da93377135d5b59771c0e9fe54c08943b5512074989d43c75b2587"
        },
        "Root_reconciliation": {
          "bytes": 846,
          "path": "_tracking/B003-B004-B021-new-disjoint-native-science-C-20261028/ROOT-THREE-FINITE-BUNDLES-ACTUAL-BREADTH-127179UNITS-RECONCILIATION-ONCE-20261028.json",
          "sha256": "dc71ead83e02108704f31cc1e991e100b64b83cc4c248ddc35303732bea584ea"
        },
        "new_context_characters": 20234,
        "new_native_pages": 328,
        "new_scientific_main_appendix_pages": 328,
        "new_substantive_scientific_notes_pages": 0,
        "new_windows": 14,
        "source_ids": [
          "B003",
          "B004",
          "B021"
        ],
        "whole_family_credit": 0
      }
    ],
    "next_cursor": "See pinned ownerfrontiers and Rootbindings; excludeallalreadyreadfiniteextents. Exactcandidategatesremainrequired.",
    "remaining_gaps_preserved": true,
    "whole_family_complete": false
  },
  "B005": {
    "receipt": {
      "bytes": 4613,
      "path": "_tracking/B005-B026-B063-six-front-back-native-C-20261027/SIX-FRONT-BACK-AND-ISAKOV-APPENDIX-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "7f0afbfef877f447915e0a32301f6dd0a8f8dd6f32afbcd39c200d8539d0a35e"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B008": {
    "new_scientific_pages": 152,
    "receipt": {
      "bytes": 1742,
      "path": "_tracking/B008-Berard-firstedition7scientific-positive-frontier-C-END-20261027.json",
      "sha256": "31fa452b6a2826e0c17a07c82564d613c5eaa5642aca93257d5033bf3ea455d8"
    },
    "wholebook_family_complete": false
  },
  "B009": {
    "new_finite_bundle": {
      "bytes": 848,
      "path": "_tracking/ROOT-753BOOK-NATIVE-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "fdaa9fe3993901807dcf8f082b4049a776a23d10841174427d019b28484a7ccd"
    },
    "remaining": "Exact prior exclusions and newly obtained chapter extents remain in the pinned frontier. Unobtained material, held targets and other editions are pending.",
    "whole_family_complete": false
  },
  "B010": {
    "receipt": {
      "bytes": 5012,
      "path": "_tracking/B010-B057-B062-six-front-back-native-C-20261027/SIX-FRONT-BACK-AND-THREE-APPENDIX-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "fbf4ba13da1b690b066fd42a0e9a7789297b7fb655984d8aaf9092f6be680a63"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B016": {
    "receipt": {
      "bytes": 7301,
      "path": "_tracking/B016-B141-B213-B240-eleven-front-back-part-native-C-20261027/ELEVEN-FRONT-BACK-PART-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "2c5bd0c2559d638464004684382c88e5cc129d6d82a60a100058cac4588dee3e"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B021": {
    "finite_updates": [
      {
        "Root_binding": {
          "bytes": 3868,
          "path": "_tracking/B003-B004-B021-new-disjoint-native-science-C-20261028/ROOT-12UNITS-328NATIVE-ALL14-WINDOWS-7SUPPORT-LITERAL-BINDINGS-PASS-20261028.json",
          "sha256": "aa84f4e927da93377135d5b59771c0e9fe54c08943b5512074989d43c75b2587"
        },
        "Root_reconciliation": {
          "bytes": 846,
          "path": "_tracking/B003-B004-B021-new-disjoint-native-science-C-20261028/ROOT-THREE-FINITE-BUNDLES-ACTUAL-BREADTH-127179UNITS-RECONCILIATION-ONCE-20261028.json",
          "sha256": "dc71ead83e02108704f31cc1e991e100b64b83cc4c248ddc35303732bea584ea"
        },
        "new_context_characters": 20234,
        "new_native_pages": 328,
        "new_scientific_main_appendix_pages": 328,
        "new_substantive_scientific_notes_pages": 0,
        "new_windows": 14,
        "source_ids": [
          "B003",
          "B004",
          "B021"
        ],
        "whole_family_credit": 0
      }
    ],
    "next_cursor": "See pinned ownerfrontiers and Rootbindings; excludeallalreadyreadfiniteextents. Exactcandidategatesremainrequired.",
    "remaining_gaps_preserved": true,
    "whole_family_complete": false
  },
  "B022": {
    "blank_leaf_correction": {
      "bytes": 4217,
      "path": "_tracking/C-TWO-PIXEL-CONFIRMED-BLANK-NATIVE-LEAVES-EXACT-ADDITIVE-COUNT-CORRECTION-END-20261028.json",
      "sha256": "fa37cb5836cb4560f3aa7645f04625f91b57dac6594e3e3156cdb73e620dabb8"
    },
    "latest_finite_bundles": [
      {
        "bytes": 1411,
        "path": "_tracking/ROOT-1208BOOK-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "e7e85b00035cf2bba19152361d376843626856920c7a7ca4e2071097e78b2f0b"
      },
      {
        "bytes": 844,
        "path": "_tracking/ROOT-1270BOOK-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "f44b0f5de1b7c9312baa780615f26a7e6dfcc92ce6f994e4f8c23f26351fe0c3"
      }
    ],
    "scope": "Exactdisjointscientificunitfrontiersandpositivewindowdispositionsretained; checkhandoffs/claimsforunreadunits/frontback/editions. No broadfamilyclosure.",
    "whole_family_complete": false
  },
  "B025": {
    "new_finite_bundle": {
      "bytes": 843,
      "path": "_tracking/ROOT-513BOOK-NATIVE-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "cc31704955df4c05674bb27ee318eee50c4d328484114f1bd695fda6c4989b14"
    },
    "remaining": "Exact prior exclusions and newly obtained chapter extents remain in the pinned frontier. Unobtained material, held targets and other editions are pending.",
    "whole_family_complete": false
  },
  "B026": {
    "receipt": {
      "bytes": 4613,
      "path": "_tracking/B005-B026-B063-six-front-back-native-C-20261027/SIX-FRONT-BACK-AND-ISAKOV-APPENDIX-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "7f0afbfef877f447915e0a32301f6dd0a8f8dd6f32afbcd39c200d8539d0a35e"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B057": {
    "receipt": {
      "bytes": 5012,
      "path": "_tracking/B010-B057-B062-six-front-back-native-C-20261027/SIX-FRONT-BACK-AND-THREE-APPENDIX-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "fbf4ba13da1b690b066fd42a0e9a7789297b7fb655984d8aaf9092f6be680a63"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B061": {
    "blank_leaf_correction": {
      "bytes": 4217,
      "path": "_tracking/C-TWO-PIXEL-CONFIRMED-BLANK-NATIVE-LEAVES-EXACT-ADDITIVE-COUNT-CORRECTION-END-20261028.json",
      "sha256": "fa37cb5836cb4560f3aa7645f04625f91b57dac6594e3e3156cdb73e620dabb8"
    },
    "latest_finite_bundles": [
      {
        "bytes": 1411,
        "path": "_tracking/ROOT-1208BOOK-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "e7e85b00035cf2bba19152361d376843626856920c7a7ca4e2071097e78b2f0b"
      },
      {
        "bytes": 844,
        "path": "_tracking/ROOT-1270BOOK-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "f44b0f5de1b7c9312baa780615f26a7e6dfcc92ce6f994e4f8c23f26351fe0c3"
      }
    ],
    "scope": "Exactdisjointscientificunitfrontiersandpositivewindowdispositionsretained; checkhandoffs/claimsforunreadunits/frontback/editions. No broadfamilyclosure.",
    "whole_family_complete": false
  },
  "B061_precise_followups": {
    "Taylor_resolved_exclusion": {
      "bytes": 22154,
      "path": "_tracking/B061-Taylor-planar-projection-increase-precise-gate-C-20261028/TAYLOR-EXACT-LOCAL-ALL-DIRECTIONS-WEAK-INEQUALITIES-THEOREM0-7-PUBLISHED-RESOLUTION-EXCLUSION-C-END.json",
      "sha256": "cf85275971b9a55f31949d153c5c120f6eae75603445f5c52f724485639d3945"
    },
    "canonical_admissions": 0,
    "infinite_exit_rate_Q_chain_HOLD": {
      "bytes": 2423,
      "path": "_tracking/B061-Q-CHAIN-INFINITE-RATE-EXTENDED-BALANCE-EXACT-PIXEL-SCOPE-HOLD-C-END-20261028.json",
      "sha256": "05a8f3545539bd7a1f83c92499083e3acc8d1a19b92e0081e030f6f8c4c1792a"
    }
  },
  "B062": {
    "receipt": {
      "bytes": 5012,
      "path": "_tracking/B010-B057-B062-six-front-back-native-C-20261027/SIX-FRONT-BACK-AND-THREE-APPENDIX-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "fbf4ba13da1b690b066fd42a0e9a7789297b7fb655984d8aaf9092f6be680a63"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B063": {
    "receipt": {
      "bytes": 4613,
      "path": "_tracking/B005-B026-B063-six-front-back-native-C-20261027/SIX-FRONT-BACK-AND-ISAKOV-APPENDIX-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "7f0afbfef877f447915e0a32301f6dd0a8f8dd6f32afbcd39c200d8539d0a35e"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B066": {
    "blank_leaf_correction": {
      "bytes": 4217,
      "path": "_tracking/C-TWO-PIXEL-CONFIRMED-BLANK-NATIVE-LEAVES-EXACT-ADDITIVE-COUNT-CORRECTION-END-20261028.json",
      "sha256": "fa37cb5836cb4560f3aa7645f04625f91b57dac6594e3e3156cdb73e620dabb8"
    },
    "latest_finite_bundles": [
      {
        "bytes": 1411,
        "path": "_tracking/ROOT-1208BOOK-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "e7e85b00035cf2bba19152361d376843626856920c7a7ca4e2071097e78b2f0b"
      },
      {
        "bytes": 844,
        "path": "_tracking/ROOT-1270BOOK-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "f44b0f5de1b7c9312baa780615f26a7e6dfcc92ce6f994e4f8c23f26351fe0c3"
      }
    ],
    "scope": "Exactdisjointscientificunitfrontiersandpositivewindowdispositionsretained; checkhandoffs/claimsforunreadunits/frontback/editions. No broadfamilyclosure.",
    "whole_family_complete": false
  },
  "B067": {
    "blank_leaf_correction": {
      "bytes": 4217,
      "path": "_tracking/C-TWO-PIXEL-CONFIRMED-BLANK-NATIVE-LEAVES-EXACT-ADDITIVE-COUNT-CORRECTION-END-20261028.json",
      "sha256": "fa37cb5836cb4560f3aa7645f04625f91b57dac6594e3e3156cdb73e620dabb8"
    },
    "latest_finite_bundles": [
      {
        "bytes": 1411,
        "path": "_tracking/ROOT-1208BOOK-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "e7e85b00035cf2bba19152361d376843626856920c7a7ca4e2071097e78b2f0b"
      },
      {
        "bytes": 844,
        "path": "_tracking/ROOT-1270BOOK-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "f44b0f5de1b7c9312baa780615f26a7e6dfcc92ce6f994e4f8c23f26351fe0c3"
      }
    ],
    "scope": "Exactdisjointscientificunitfrontiersandpositivewindowdispositionsretained; checkhandoffs/claimsforunreadunits/frontback/editions. No broadfamilyclosure.",
    "whole_family_complete": false
  },
  "B073": {
    "blank_leaf_correction": {
      "bytes": 4217,
      "path": "_tracking/C-TWO-PIXEL-CONFIRMED-BLANK-NATIVE-LEAVES-EXACT-ADDITIVE-COUNT-CORRECTION-END-20261028.json",
      "sha256": "fa37cb5836cb4560f3aa7645f04625f91b57dac6594e3e3156cdb73e620dabb8"
    },
    "latest_finite_bundles": [
      {
        "bytes": 1411,
        "path": "_tracking/ROOT-1208BOOK-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "e7e85b00035cf2bba19152361d376843626856920c7a7ca4e2071097e78b2f0b"
      },
      {
        "bytes": 844,
        "path": "_tracking/ROOT-1270BOOK-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "f44b0f5de1b7c9312baa780615f26a7e6dfcc92ce6f994e4f8c23f26351fe0c3"
      }
    ],
    "scope": "Exactdisjointscientificunitfrontiersandpositivewindowdispositionsretained; checkhandoffs/claimsforunreadunits/frontback/editions. No broadfamilyclosure.",
    "whole_family_complete": false
  },
  "B077": {
    "blank_leaf_correction": {
      "bytes": 4217,
      "path": "_tracking/C-TWO-PIXEL-CONFIRMED-BLANK-NATIVE-LEAVES-EXACT-ADDITIVE-COUNT-CORRECTION-END-20261028.json",
      "sha256": "fa37cb5836cb4560f3aa7645f04625f91b57dac6594e3e3156cdb73e620dabb8"
    },
    "latest_finite_bundles": [
      {
        "bytes": 1411,
        "path": "_tracking/ROOT-1208BOOK-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "e7e85b00035cf2bba19152361d376843626856920c7a7ca4e2071097e78b2f0b"
      },
      {
        "bytes": 844,
        "path": "_tracking/ROOT-1270BOOK-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
        "sha256": "f44b0f5de1b7c9312baa780615f26a7e6dfcc92ce6f994e4f8c23f26351fe0c3"
      }
    ],
    "scope": "Exactdisjointscientificunitfrontiersandpositivewindowdispositionsretained; checkhandoffs/claimsforunreadunits/frontback/editions. No broadfamilyclosure.",
    "whole_family_complete": false
  },
  "B090": {
    "receipt": {
      "bytes": 8736,
      "path": "_tracking/B090-Ern-Guermond-nine-new-science-and-native-matter-C-20261027/NINE-NEW-SCIENCE-AND-NATIVE-MATTER-ALL-CONTEXTS-C-HANDOFF.json",
      "sha256": "815cc52ed40915ca7093d5f833ba5cd39c52dd83add494e4425c31acc255b46e"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B093": {
    "receipt": {
      "bytes": 3085,
      "path": "_tracking/B093-B156-B175-six-front-back-native-C-20261027/SIX-REMAINING-MATTER-THREE-EDITION-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "ca7cf492df3e41e261bc25d8b1053c8a7f5ff409cf2a6e4d13c8ae7816cd92a1"
    },
    "scope": "Finiteobtainednativeunitsonly;oldscience/frontoverlapexcluded,leaf/OCR/editiongapsremain.",
    "wholebook_family_complete": false
  },
  "B094": {
    "receipt": {
      "bytes": 4587,
      "path": "_tracking/B094-Hairer-Wanner-six-front-part-back-native-C-20261027/SIX-FRONT-PART-BACK-AND-FORTRAN-APPENDIX-C-HANDOFF.json",
      "sha256": "55c388df551778a5655d0b8f79f2781164581a195c451e67c0f06361245c19b6"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B096": {
    "new_finite_bundle": {
      "bytes": 1140,
      "path": "_tracking/ROOT-1989BOOK-NATIVE-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "8e0f8729a34376d10ea6ea0a45f35aaeb657f8a72d63e0fea411d0411f53a9da"
    },
    "remaining": "Unobtained front/back/part-divider material, other editions and source-specific held formulations remain pending. Exact chapter extents and prior exclusions are in the pinned finite-frontier receipts.",
    "whole_family_complete": false
  },
  "B097": {
    "receipt": {
      "bytes": 4312,
      "path": "_tracking/B097-B098-six-front-part-back-native-C-20261027/SIX-MATTER-UNITS-TWO-EDITION-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "f0f93f0ea6b90c170692e3ca72a84b8e353ab7ab9e5d9a55d09a5e457cbcac94"
    },
    "scope": "Finiteobtainednativeunitsonly;oldscience/frontoverlapexcluded,leaf/OCR/editiongapsremain.",
    "wholebook_family_complete": false
  },
  "B098": {
    "receipt": {
      "bytes": 4312,
      "path": "_tracking/B097-B098-six-front-part-back-native-C-20261027/SIX-MATTER-UNITS-TWO-EDITION-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "f0f93f0ea6b90c170692e3ca72a84b8e353ab7ab9e5d9a55d09a5e457cbcac94"
    },
    "scope": "Finiteobtainednativeunitsonly;oldscience/frontoverlapexcluded,leaf/OCR/editiongapsremain.",
    "wholebook_family_complete": false
  },
  "B113": {
    "latest_finite_bundle": {
      "bytes": 840,
      "path": "_tracking/ROOT-1050BOOK-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "62ccb6515577e3cf2fff8088838a8cd594d22df3d7131304ef6edc10493329a0"
    },
    "scope": "Exact disjoint scientific chapter frontier and all positive windows recorded. Historical mathematical targets held until source/current/announcement/duplicate gates. Other editions/front/back gaps preserved.",
    "whole_family_complete": false
  },
  "B126": {
    "new_finite_bundle": {
      "bytes": 848,
      "path": "_tracking/ROOT-753BOOK-NATIVE-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "fdaa9fe3993901807dcf8f082b4049a776a23d10841174427d019b28484a7ccd"
    },
    "remaining": "Exact prior exclusions and newly obtained chapter extents remain in the pinned frontier. Unobtained material, held targets and other editions are pending.",
    "whole_family_complete": false
  },
  "B129": {
    "new_finite_bundle": {
      "bytes": 850,
      "path": "_tracking/ROOT-903BOOK-SCIENCE-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "61e7844df0c387812b71d923cd2cc051f5666b8c64db5810932e823ddf5ba0c7"
    },
    "remaining": "Exact prior exclusions and newly obtained chapter extents remain in the pinned frontier. Unobtained material, held targets and other editions are pending.",
    "whole_family_complete": false
  },
  "B136": {
    "latest_finite_bundle": {
      "bytes": 840,
      "path": "_tracking/ROOT-1050BOOK-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "62ccb6515577e3cf2fff8088838a8cd594d22df3d7131304ef6edc10493329a0"
    },
    "scope": "Exact disjoint scientific chapter frontier and all positive windows recorded. Historical mathematical targets held until source/current/announcement/duplicate gates. Other editions/front/back gaps preserved.",
    "whole_family_complete": false
  },
  "B137": {
    "new_finite_bundle": {
      "bytes": 1140,
      "path": "_tracking/ROOT-1989BOOK-NATIVE-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "8e0f8729a34376d10ea6ea0a45f35aaeb657f8a72d63e0fea411d0411f53a9da"
    },
    "remaining": "Unobtained front/back/part-divider material, other editions and source-specific held formulations remain pending. Exact chapter extents and prior exclusions are in the pinned finite-frontier receipts.",
    "whole_family_complete": false
  },
  "B141": {
    "receipt": {
      "bytes": 7301,
      "path": "_tracking/B016-B141-B213-B240-eleven-front-back-part-native-C-20261027/ELEVEN-FRONT-BACK-PART-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "2c5bd0c2559d638464004684382c88e5cc129d6d82a60a100058cac4588dee3e"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B144": {
    "new_finite_bundle": {
      "bytes": 1140,
      "path": "_tracking/ROOT-1989BOOK-NATIVE-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "8e0f8729a34376d10ea6ea0a45f35aaeb657f8a72d63e0fea411d0411f53a9da"
    },
    "remaining": "Unobtained front/back/part-divider material, other editions and source-specific held formulations remain pending. Exact chapter extents and prior exclusions are in the pinned finite-frontier receipts.",
    "whole_family_complete": false
  },
  "B150": {
    "next_action": "Preserve exact unobtaineddivider/blankpage andotheredition gaps; allobtainedfirsteditionpositivecontexts alreadyread, do not replay.",
    "receipt": {
      "bytes": 13352,
      "path": "_tracking/B150-Sulem-firstedition-scientific15chapters-plus-frontback-positive-frontier-C-END-20261027.json",
      "sha256": "8b283dbc736282adbbd1bbd631757c396d7ca8573affdd397412f16902988ec1"
    }
  },
  "B153": {
    "new_finite_bundle": {
      "bytes": 1140,
      "path": "_tracking/ROOT-1989BOOK-NATIVE-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "8e0f8729a34376d10ea6ea0a45f35aaeb657f8a72d63e0fea411d0411f53a9da"
    },
    "remaining": "Unobtained front/back/part-divider material, other editions and source-specific held formulations remain pending. Exact chapter extents and prior exclusions are in the pinned finite-frontier receipts.",
    "whole_family_complete": false
  },
  "B156": {
    "receipt": {
      "bytes": 3085,
      "path": "_tracking/B093-B156-B175-six-front-back-native-C-20261027/SIX-REMAINING-MATTER-THREE-EDITION-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "ca7cf492df3e41e261bc25d8b1053c8a7f5ff409cf2a6e4d13c8ae7816cd92a1"
    },
    "scope": "Finiteobtainednativeunitsonly;oldscience/frontoverlapexcluded,leaf/OCR/editiongapsremain.",
    "wholebook_family_complete": false
  },
  "B159": {
    "receipts": [
      {
        "bytes": 3177,
        "path": "_tracking/B159-B186-five-new-front-back-native-C-20261027/FIVE-MATTER-UNITS-THREE-VOLUME-EXTENTS-OVERLAP-AWARE-C-HANDOFF.json",
        "sha256": "2801ae7ec9aa184082d14a7dac05b01af70e5efffdd6ff5ac83280e94ae65d85"
      }
    ],
    "scope": "Only actual finite native units and positive passages; old routes excluded, explicit leaf/access/OCR/edition gaps preserved.",
    "whole_book_or_family_complete": false
  },
  "B161": {
    "Root_frontier": {
      "bytes": 603,
      "path": "_tracking/B161-eleven-new-scientific-independent3-C-20261028/ROOT-B161-ONE-FINITE-486SCIENCE-BUNDLE-127171UNITS-RECONCILIATION-ONCE-20261028.json",
      "sha256": "6738e8b628fb688d93281f4aea966b6f488e7056ece3facefb5e7e1a0fe29014"
    },
    "extent": "All12sciencechapterfinitefrontierprinted1â€“536,oldchapter12excludedfromnew486;14appendices/front/references/indexpending.",
    "historical_candidate_holds": true,
    "source_year": "July2022,nopreJan2022arxivcoverage",
    "whole_family_complete": false
  },
  "B164": {
    "recovered_finite_disjoint_science": {
      "bytes": 870,
      "path": "_tracking/ROOT-1806RECOVERED-BOOK-NATIVE-PAGES-THREE-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "dc0a7422ffe52f8ecf9e58c8a256abfd5c304a0ecbb68e474906d4ad092bcf78"
    },
    "remaining": "Prior complete chapter/intro/prologue exclusions, front/back/solutions and other editions remain pending; shared whole-PDF size is not credited as selected science extent.",
    "whole_family_complete": false
  },
  "B166": {
    "receipts": [
      {
        "bytes": 3130,
        "path": "_tracking/B166-matter-B134-B138-B143-new-science-route-batch-C-20261027/FOUR-FEINBERG-MATTER-UNITS-THREE-NEW-SCIENCE-ROUTE-GAPS-C-HANDOFF.json",
        "sha256": "3d76491229a6ebf8594f6562f2c5c1eee0bcc18033b67a973a37fd9339beffdb"
      }
    ],
    "scope": "Only actual finite native units and positive passages; old routes excluded, explicit leaf/access/OCR/edition gaps preserved.",
    "whole_book_or_family_complete": false
  },
  "B167": {
    "new_finite_bundle": {
      "bytes": 1140,
      "path": "_tracking/ROOT-1989BOOK-NATIVE-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "8e0f8729a34376d10ea6ea0a45f35aaeb657f8a72d63e0fea411d0411f53a9da"
    },
    "remaining": "Unobtained front/back/part-divider material, other editions and source-specific held formulations remain pending. Exact chapter extents and prior exclusions are in the pinned finite-frontier receipts.",
    "whole_family_complete": false
  },
  "B175": {
    "receipt": {
      "bytes": 3085,
      "path": "_tracking/B093-B156-B175-six-front-back-native-C-20261027/SIX-REMAINING-MATTER-THREE-EDITION-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "ca7cf492df3e41e261bc25d8b1053c8a7f5ff409cf2a6e4d13c8ae7816cd92a1"
    },
    "scope": "Finiteobtainednativeunitsonly;oldscience/frontoverlapexcluded,leaf/OCR/editiongapsremain.",
    "wholebook_family_complete": false
  },
  "B183": {
    "finite_native_science_frontier": "All4 actualnative chapters keyword-dispositioned,230 cumulative sciencepages. Front/back,OCR/formula/pixel/edition gaps remain. Constrained complexity target held for current oracle/regime matching.",
    "receipt": {
      "bytes": 2082,
      "path": "_tracking/B183-Nesterov-three-new-scientific-pdfium-C-20261027/THREE-NEW-SCIENCE-170PAGES-ONE-FINITE-BOOK-FRONTIER-C-HANDOFF.json",
      "sha256": "5106ede98833c9b87c2f51239454abe2fecbbf47d40b49db892c31fecf6863f3"
    },
    "whole_book_or_family_complete": false
  },
  "B186": {
    "receipts": [
      {
        "bytes": 3177,
        "path": "_tracking/B159-B186-five-new-front-back-native-C-20261027/FIVE-MATTER-UNITS-THREE-VOLUME-EXTENTS-OVERLAP-AWARE-C-HANDOFF.json",
        "sha256": "2801ae7ec9aa184082d14a7dac05b01af70e5efffdd6ff5ac83280e94ae65d85"
      }
    ],
    "scope": "Only actual finite native units and positive passages; old routes excluded, explicit leaf/access/OCR/edition gaps preserved.",
    "whole_book_or_family_complete": false
  },
  "B186_volumeI": {
    "new_only": {
      "new_context_characters_actually_read": 68160,
      "new_contexts_actually_read": 45,
      "new_cue_positions": 80,
      "new_obtained_native_pages": 623
    },
    "receipt": {
      "bytes": 1343,
      "path": "_tracking/B186-Facchinei-Pang-firstedition-volumeI6scientific-positive-frontier-C-END-20261027.json",
      "sha256": "eba82cc9cd5023f7d90dd0c42d9f51ac60c950bbec31393c395a9c791a0e3408"
    },
    "wholebook_family_complete": false
  },
  "B186_volumeII": {
    "new_only": {
      "new_context_characters_actually_read": 28043,
      "new_contexts_actually_read": 19,
      "new_cue_positions": 24,
      "new_obtained_native_pages": 481
    },
    "receipt": {
      "bytes": 2853,
      "path": "_tracking/B186-Facchinei-Pang-firstedition-volumeII6scientific-positive-frontier-C-END-20261027.json",
      "sha256": "3302d1bbfa9cbf8120ca0b1f80656f9a38b7902afa96e7f9e4b1913c30511ed6"
    },
    "wholebook_family_complete": false
  },
  "B192": {
    "receipt": {
      "bytes": 4524,
      "path": "_tracking/B192-B193-B283-five-front-back-native-C-20261027/FIVE-FRONT-BACK-FINITE-FRONTIERS-AND-CURTAIN101PAGE-GAP-C-HANDOFF.json",
      "sha256": "3a10c283fb81cf4a30347832121368977538bb0287f5134e3841a1a5cee3326d"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B193": {
    "receipt": {
      "bytes": 4524,
      "path": "_tracking/B192-B193-B283-five-front-back-native-C-20261027/FIVE-FRONT-BACK-FINITE-FRONTIERS-AND-CURTAIN101PAGE-GAP-C-HANDOFF.json",
      "sha256": "3a10c283fb81cf4a30347832121368977538bb0287f5134e3841a1a5cee3326d"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B199": {
    "new_finite_bundle": {
      "bytes": 1140,
      "path": "_tracking/ROOT-1989BOOK-NATIVE-PAGES-SIX-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "8e0f8729a34376d10ea6ea0a45f35aaeb657f8a72d63e0fea411d0411f53a9da"
    },
    "remaining": "Unobtained front/back/part-divider material, other editions and source-specific held formulations remain pending. Exact chapter extents and prior exclusions are in the pinned finite-frontier receipts.",
    "whole_family_complete": false
  },
  "B200": {
    "Root_frontier": {
      "bytes": 637,
      "path": "_tracking/B200-fourteen-new-scientific-independent3-C-20261028/ROOT-B200-ONE-FINITE-308SCIENCE-BUNDLE-127172UNITS-RECONCILIATION-ONCE-20261028.json",
      "sha256": "69148cce0ecc1231a5152769bc76d040c90b69bda024c0e93fe5e21b81a09fa4"
    },
    "ensemble_size_formulation_hold": true,
    "extent": "All15sciencechapterspans342leaves,known341body;oldchapter15excluded,new14span309includesonefooter-onlyblank. Frontpartopeners/references/index/editionspending.",
    "whole_family_complete": false
  },
  "B206": {
    "receipts": [
      {
        "bytes": 1904,
        "path": "_tracking/B206-Robert-Casella-eleven-new-scientific-C-20261027/ELEVEN-NEW-SCIENTIFIC-FINITE-FRONTIERS-455PAGES-C-HANDOFF.json",
        "sha256": "559722633293dc3be6fe54373becee7b40e18cc4561f6a642a367cfdc039b8df"
      },
      {
        "bytes": 2753,
        "path": "_tracking/B206-last2-B207-first12-native-scientific-pdfium-C-20261027/FOURTEEN-NEW-SCIENCE-331PAGES-TWO-FINITE-BOOK-FRONTIERS-C-HANDOFF.json",
        "sha256": "128c43ed4639840f1232848d31fba50cd0b56bc66d3d438c9c36584443a67e30"
      }
    ],
    "scope": "Only actual finite native units and positive passages; old routes excluded, explicit leaf/access/OCR/edition gaps preserved.",
    "whole_book_or_family_complete": false
  },
  "B207": {
    "receipts": [
      {
        "bytes": 2753,
        "path": "_tracking/B206-last2-B207-first12-native-scientific-pdfium-C-20261027/FOURTEEN-NEW-SCIENCE-331PAGES-TWO-FINITE-BOOK-FRONTIERS-C-HANDOFF.json",
        "sha256": "128c43ed4639840f1232848d31fba50cd0b56bc66d3d438c9c36584443a67e30"
      }
    ],
    "scope": "Only actual finite native units and positive passages; old routes excluded, explicit leaf/access/OCR/edition gaps preserved.",
    "whole_book_or_family_complete": false
  },
  "B213": {
    "receipt": {
      "bytes": 7301,
      "path": "_tracking/B016-B141-B213-B240-eleven-front-back-part-native-C-20261027/ELEVEN-FRONT-BACK-PART-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "2c5bd0c2559d638464004684382c88e5cc129d6d82a60a100058cac4588dee3e"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B216": {
    "Root_finite_frontier": {
      "bytes": 734,
      "path": "_tracking/B216-remaining10science5appendices3matter-independent3-C-20261028/ROOT-B216-ONE-431SCIENCE-FINITE-BUNDLE-243BREADTH-127173UNITS-RECONCILIATION-ONCE-20261028.json",
      "sha256": "d3a7e8744252f6dcf567597f5a9ff09c11de029f0f12505d170049fc52315f25"
    },
    "Root_literal_join_pending": false,
    "extent": "All13sciencechapters1â€“423plus5scientificappendices424â€“431,new12frontseparate. Reference/index/OCR/printinggapsremain;Warsawimage-only462pages0credit.",
    "owner_completed_finite_frontier": {
      "bytes": 2433,
      "path": "_tracking/B216-remaining10science5appendices3matter-independent3-C-20261028/B216-431NEWSCIENCE-12FRONT-NEWLOGGEDFAMILY-FINITE-FRONTIER-C-HANDOFF.json",
      "sha256": "dcb8a13cd546239010aae1368d22309a8c73d2cd37767d4bda696f1a036bd562"
    },
    "owner_extent": "431science+12frontfrompublishernativePDFs,23retainedwindowsread;Warsaw462pageimageonly0scancredit",
    "whole_family_complete": false
  },
  "B229": {
    "Root_finite_bundle": {
      "bytes": 797,
      "path": "_tracking/B229-B231-two-new-institutional-scientific-C-20261028/ROOT-TWO-NEW-FINITE-SOURCE-BUNDLES-238BREADTH-127167UNITS-RECONCILIATION-ONCE-20261028.json",
      "sha256": "2fa0b8cde01a09420e5ec3b7c44da0dd333e2b3055a6fa3dbf97344a3ed4c11e"
    },
    "remaining": "Printed27onward and editions pending",
    "scientific_keyword_frontier": "Printed1â€“26,third2004 fromNTNUcourse copy;22frontpages separate, no scientific positive cue.",
    "whole_family_complete": false
  },
  "B231": {
    "Root_continuation": {
      "bytes": 678,
      "path": "_tracking/B231-remaining-original-secondedition-threeprocess-C-20261028/ROOT-B231-ONE-FINITE-651SCIENCE-BUNDLE-127168UNITS-RECONCILIATION-ONCE-20261028.json",
      "sha256": "5881d02a4b3872c940eccd02fedd0e526cd1d549a7d5ba45ba88413f89a9f42d"
    },
    "Root_finite_bundle": {
      "bytes": 797,
      "path": "_tracking/B229-B231-two-new-institutional-scientific-C-20261028/ROOT-TWO-NEW-FINITE-SOURCE-BUNDLES-238BREADTH-127167UNITS-RECONCILIATION-ONCE-20261028.json",
      "sha256": "2fa0b8cde01a09420e5ec3b7c44da0dd333e2b3055a6fa3dbf97344a3ed4c11e"
    },
    "owner_finished_continuation": "Printed157â€“807 scientific plus6tables19index; exact reading receipt retained, Root literal join not yet credited.",
    "pending_continuation": {
      "bytes": 2666,
      "path": "_tracking/B231-remaining-original-secondedition-threeprocess-C-20261028/B231-651NEWSCIENCE-6TABLE-19INDEX-ALL18CHAPTERS-PLUS2SCIENTIFICAPPENDICES-C-HANDOFF.json",
      "sha256": "5185b0cc7fbba28927e300a99980cb2cd1d9c21b33c69ccbab19464e5cd6ce1d"
    },
    "root_literal_join_pending": false,
    "scientific_keyword_frontier": "Printed1â€“807science incl39appendixpages nowRootjoined;6reference-tablepages808â€“813and19indexleaves separate. Gapprinted814/815explicit.",
    "whole_family_complete": false
  },
  "B235": {
    "Root_finite_frontier": {
      "bytes": 768,
      "path": "_tracking/B235-B236-three-new-battery-scientific-independent3-C-20261028/ROOT-TWO-NEW-BATTERY-FINITE-BUNDLES-240BREADTH-127170UNITS-RECONCILIATION-ONCE-20261028.json",
      "sha256": "8ac27cac52644ed553c10c1f1656b2032504843e88df2caeb98a3c0aae0b679a"
    },
    "extent": "VolumesI2015andII2016partialchapter1printed1â€“22each44science24front",
    "remainder": "Alllaterprinted23onward/chapters/editionspending",
    "whole_family_complete": false
  },
  "B236": {
    "Root_finite_frontier": {
      "bytes": 768,
      "path": "_tracking/B235-B236-three-new-battery-scientific-independent3-C-20261028/ROOT-TWO-NEW-BATTERY-FINITE-BUNDLES-240BREADTH-127170UNITS-RECONCILIATION-ONCE-20261028.json",
      "sha256": "8ac27cac52644ed553c10c1f1656b2032504843e88df2caeb98a3c0aae0b679a"
    },
    "extent": "Part5observedchapters37â€“41,152science6other",
    "gap": "Fullprintingtitleverso/ISBNparityunverified,allotherpartspending",
    "whole_family_complete": false
  },
  "B240": {
    "receipt": {
      "bytes": 7301,
      "path": "_tracking/B016-B141-B213-B240-eleven-front-back-part-native-C-20261027/ELEVEN-FRONT-BACK-PART-FINITE-FRONTIERS-C-HANDOFF.json",
      "sha256": "2c5bd0c2559d638464004684382c88e5cc129d6d82a60a100058cac4588dee3e"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B245": {
    "new_finite_bundle": {
      "bytes": 850,
      "path": "_tracking/ROOT-903BOOK-SCIENCE-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "61e7844df0c387812b71d923cd2cc051f5666b8c64db5810932e823ddf5ba0c7"
    },
    "remaining": "Exact prior exclusions and newly obtained chapter extents remain in the pinned frontier. Unobtained material, held targets and other editions are pending.",
    "whole_family_complete": false
  },
  "B253": {
    "finite_updates": [
      {
        "Root_binding": {
          "bytes": 13264,
          "path": "_tracking/B253-B273-27new-native-scientific-units-independent3-C-20261028/ROOT-B253-B273-539NATIVE-ALL35-WINDOWS-12SUPPORT-LITERAL-BINDINGS-PASS-20261028.json",
          "sha256": "8c6f6f1d3fe5487f902997563159a40e127282890a61bdbba590848447be1862"
        },
        "Root_reconciliation": {
          "bytes": 1046,
          "path": "_tracking/B253-B273-27new-native-scientific-units-independent3-C-20261028/ROOT-B253-B273-TWO-FINITE-BUNDLES-245BREADTH-127175UNITS-RECONCILIATION-ONCE-20261028.json",
          "sha256": "8bcb925ad5df7a653387e2751585838627726b35ee5cd7c5da88b5ed45325098"
        },
        "new_context_characters": 52695,
        "new_native_pages": 539,
        "new_scientific_main_appendix_pages": 531,
        "new_substantive_scientific_notes_pages": 8,
        "new_windows": 35,
        "source_ids": [
          "B253",
          "B273"
        ],
        "whole_family_credit": 0
      }
    ],
    "next_cursor": "See pinned ownerfrontiers and Rootbindings; excludeallalreadyreadfiniteextents. Exactcandidategatesremainrequired.",
    "remaining_gaps_preserved": true,
    "whole_family_complete": false
  },
  "B268": {
    "recovered_finite_disjoint_science": {
      "bytes": 870,
      "path": "_tracking/ROOT-1806RECOVERED-BOOK-NATIVE-PAGES-THREE-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "dc0a7422ffe52f8ecf9e58c8a256abfd5c304a0ecbb68e474906d4ad092bcf78"
    },
    "remaining": "Prior complete chapter/intro/prologue exclusions, front/back/solutions and other editions remain pending; shared whole-PDF size is not credited as selected science extent.",
    "whole_family_complete": false
  },
  "B270": {
    "recovered_finite_disjoint_science": {
      "bytes": 870,
      "path": "_tracking/ROOT-1806RECOVERED-BOOK-NATIVE-PAGES-THREE-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "dc0a7422ffe52f8ecf9e58c8a256abfd5c304a0ecbb68e474906d4ad092bcf78"
    },
    "remaining": "Prior complete chapter/intro/prologue exclusions, front/back/solutions and other editions remain pending; shared whole-PDF size is not credited as selected science extent.",
    "whole_family_complete": false
  },
  "B273": {
    "finite_updates": [
      {
        "Root_binding": {
          "bytes": 13264,
          "path": "_tracking/B253-B273-27new-native-scientific-units-independent3-C-20261028/ROOT-B253-B273-539NATIVE-ALL35-WINDOWS-12SUPPORT-LITERAL-BINDINGS-PASS-20261028.json",
          "sha256": "8c6f6f1d3fe5487f902997563159a40e127282890a61bdbba590848447be1862"
        },
        "Root_reconciliation": {
          "bytes": 1046,
          "path": "_tracking/B253-B273-27new-native-scientific-units-independent3-C-20261028/ROOT-B253-B273-TWO-FINITE-BUNDLES-245BREADTH-127175UNITS-RECONCILIATION-ONCE-20261028.json",
          "sha256": "8bcb925ad5df7a653387e2751585838627726b35ee5cd7c5da88b5ed45325098"
        },
        "new_context_characters": 52695,
        "new_native_pages": 539,
        "new_scientific_main_appendix_pages": 531,
        "new_substantive_scientific_notes_pages": 8,
        "new_windows": 35,
        "source_ids": [
          "B253",
          "B273"
        ],
        "whole_family_credit": 0
      },
      {
        "Root_binding": {
          "bytes": 1313,
          "path": "_tracking/B273-fifteen-later-scientific-independent3-C-20261028/ROOT-B273-LATER15-240NATIVE-ALL12-WINDOWS-4SUPPORT-LITERAL-BINDINGS-PASS-20261028.json",
          "sha256": "38f56c25be29034f3a731e9466616874e18567fe410f5ed129ddadedb022225e"
        },
        "Root_reconciliation": {
          "bytes": 809,
          "path": "_tracking/B273-fifteen-later-scientific-independent3-C-20261028/ROOT-B273-LATER15-ONE-FINITE-BUNDLE-245BREADTH-127176UNITS-RECONCILIATION-ONCE-20261028.json",
          "sha256": "3aa25712ba2858faa0880080862cf0adbc62e5c00475483e8190a6cf6d20ee07"
        },
        "new_context_characters": 16077,
        "new_native_pages": 240,
        "new_scientific_main_appendix_pages": 240,
        "new_substantive_scientific_notes_pages": 0,
        "new_windows": 12,
        "source_ids": [
          "B273"
        ],
        "whole_family_credit": 0
      }
    ],
    "next_cursor": "See pinned ownerfrontiers and Rootbindings; excludeallalreadyreadfiniteextents. Exactcandidategatesremainrequired.",
    "remaining_gaps_preserved": true,
    "whole_family_complete": false
  },
  "B283": {
    "receipt": {
      "bytes": 4524,
      "path": "_tracking/B192-B193-B283-five-front-back-native-C-20261027/FIVE-FRONT-BACK-FINITE-FRONTIERS-AND-CURTAIN101PAGE-GAP-C-HANDOFF.json",
      "sha256": "3a10c283fb81cf4a30347832121368977538bb0287f5134e3841a1a5cee3326d"
    },
    "scope": "Finite obtainednativeunitkeywordfrontier. Priorchapterreuse/frontoverlap getszeroadditionalcredit; exactleaf/OCR/edition/accessgaps remaininreceipt.",
    "wholebook_family_complete": false
  },
  "B285": {
    "new_finite_bundle": {
      "bytes": 843,
      "path": "_tracking/ROOT-513BOOK-NATIVE-PAGES-TWO-FINITE-BUNDLES-EXACT-RECONCILIATION-ONCE-20261028.json",
      "sha256": "cc31704955df4c05674bb27ee318eee50c4d328484114f1bd695fda6c4989b14"
    },
    "remaining": "Exact prior exclusions and newly obtained chapter extents remain in the pinned frontier. Unobtained material, held targets and other editions are pending.",
    "whole_family_complete": false
  },
  "C160_means": {
    "state": "HOLD_CURRENT_PRIMARY_GATES_PENDING",
    "target": "PX>IL and sharp power-mean orders; not admitted"
  },
  "C163": {
    "Root_reconciliation": {
      "bytes": 703,
      "path": "_tracking/C163-source1446650-A30-priority-retained-20261028/ROOT-C163-30-PAPER-53-CONTEXT-ONCE-RECONCILIATION-PASS.json",
      "sha256": "07b46df24752cf4e77cdfce9d2c80dbe1a57b72262759fadca0cc896dd0312c3"
    },
    "state": "COMPLETE_FINITE_30_PAPER_REVIEW_JOINED_ONCE",
    "unselected_source1446650_positive_rows_pending": 11204,
    "whole_paper_credit": 0
  },
  "C164": {
    "Root_reconciliation": {
      "bytes": 703,
      "path": "_tracking/C164-source1511484-A30-priority-retained-20261028/ROOT-C164-30-PAPER-65-CONTEXT-ONCE-RECONCILIATION-PASS.json",
      "sha256": "d48058f39af1e35dacee582117eddfb372cc5d6096a712533534ab05afb7e057"
    },
    "state": "COMPLETE_FINITE_30_PAPER_REVIEW_JOINED_ONCE",
    "unselected_source1511484_positive_rows_pending": 10981,
    "whole_paper_credit": 0
  },
  "C165_retained_reading": {
    "END": {
      "bytes": 6803,
      "path": "_tracking/C165-source1575868-A12-priority-retained-20261028/END.json",
      "sha256": "4798626c79ccd1b79ee6747a2ea4bbe441fc6f7e7426bb804d17615c09f76ceb"
    },
    "Root_reconciliation": {
      "bytes": 702,
      "path": "_tracking/C165-source1575868-A12-priority-retained-20261028/ROOT-C165-12-PAPER-28-CONTEXT-ONCE-RECONCILIATION-PASS.json",
      "sha256": "a3010a431dee2615d6f3f4c7add853442e098e8ebf80d79a81dc64845e891864"
    },
    "contexts": 28,
    "papers": 12,
    "scope": "All retained windows actually read; nativeTOC witnesses001/010 and abstractwitness005 remain explicitly qualified. No fullpaper/sourcequalitycredit or completed worklistprefix.",
    "unselected_positive_rows_pending": 11191,
    "windows": 25
  },
  "CRN_deficiency_Sflux_C165": {
    "owner_gate": {
      "bytes": 4774,
      "path": "_tracking/focused-deficiency-Sflux-noise-sum-C165-A-20261028/PRIMARY2018-EQ30-MOMENT-CLOSURE-DEPENDENT-FLUX-AND-MODEL-SCOPE-FORMULATION-HOLD.json",
      "sha256": "4ea94c352a641e67bfc396e747b3edd3a7d406090a40e85370e5b4bba5cbdb76"
    },
    "reason": "ExactEq30 is per-species withpositivegamma; nonlinearSection3 usesmomentclosure and dependentfluxpositivity isnotensured. Full admissible network/independentflux and exactvsclosure interpretation remain missing. Do notassert an exact universal CME theorem.",
    "state": "FORMULATION_HOLD_NO_ADMISSION"
  },
  "DSII_lump_blowup": {
    "admission_credit": 0,
    "owner": {
      "bytes": 10734,
      "path": "_tracking/focused-DSII-lump-blowup-J148-C-20261028/DSII-CONJECTURE11-EXACT-SOURCE-PIXELS-CURRENT-983-616-1704-MODEL-HOLD-OWNER-C-END.json",
      "sha256": "22b81d95fe0f2c0dea532a2da639f05fc23cdeedf0cc8fd097795b59b792fba1"
    },
    "reason": "The printed real-profile remainder statement does not specify the phase/centering and asymptotic remainder control needed for a symmetry-invariant target. The exact source pixels, phase warning and current comparisons are retained; do not invent a corrected conjecture.",
    "state": "FORMULATION_HOLD"
  },
  "Dunkl_translation": {
    "Root_reconciliation": {
      "bytes": 560,
      "path": "_tracking/focused-Dunkl-Lp-translation-C163-Root-20261028/ROOT-DUNKL-ONE-ADMISSION-RECONCILIATION-ONCE.json",
      "sha256": "e6e92c7f4954e2b155b3f17d5ad8c21f51503099c2106f83a15531735b3400eb"
    },
    "state": "ADMITTED"
  },
  "J008_J164_finite_context_reading": {
    "Root_reconciliation": {
      "bytes": 885,
      "path": "_tracking/ROOT-J008-J164-TWO-FINITE-JOURNAL-UNITS-NATIVE-WITNESS-GAP-20261028-RECONCILIATION-ONCE.json",
      "sha256": "f63a2f3f58cc51771be9ba5a171223bafbca73db5e33da481ae60715509e03c8"
    },
    "owner_summary": {
      "bytes": 3669,
      "path": "_tracking/J008-J164-TWO-FINITE-DISCOVERY-UNITS-THREE-DISJOINT-WINDOWS-NATIVE-WITNESS-GAP-HANDOFF-C-END-20261028.json",
      "sha256": "cf0599b7dfacbac15c180fe3e8c1955487b3f38abb52a2e93d865c6d365f9c74"
    },
    "scope": "Three actually read native retained windows and one900-character model excerpt; J164 scientific context610characters read, native structural witness absent. No extraction/wholepaper credit and no completed journal prefix. Only sparse positions553 and2805 consumed."
  },
  "J168_J222_finite_context_reading": {
    "Root_reconciliation": {
      "bytes": 848,
      "path": "_tracking/ROOT-J168-J222-TWO-FINITE-JOURNAL-UNITS-20261028-RECONCILIATION-ONCE.json",
      "sha256": "e78dff717dbaac875373d142f1849fa7dadff044bd07faa43e2d8a59e62404c4"
    },
    "owner_summary": {
      "bytes": 3664,
      "path": "_tracking/J168-J222-TWO-FINITE-DISCOVERY-UNITS-FOUR-DISJOINT-WINDOWS-ZERO-DOWNLOAD-HANDOFF-C-END-20261028.json",
      "sha256": "538870baffb5c0118d68c9054440d47ecf5f8824c6e28b7795e3a4a913bab3aa"
    },
    "scope": "Four disjoint retainedbodywindows plus two900-character excerpts. Quantum extension interleaving/modelgapheld; correlation-matrix prompts source-addressed. Only sparse claimedpositions consumed."
  },
  "J321": {
    "END": {
      "bytes": 59243,
      "path": "_tracking/J321-journal-breadth-B-gauss2043-20261026/FINAL-J321-CUE-ROUTE-DISPOSITIONS-END-PROPOSAL.json",
      "sha256": "2af01b54de025aa6057a9ee7d17e8bf3352fca7196cec50be7be0f3f46fbb353"
    },
    "root_literal_scope_check": {
      "bytes": 2793,
      "path": "_tracking/J321-journal-breadth-B-gauss2043-20261026/ROOT-INDEPENDENT-LITERAL-DIAGNOSTICS-LIMITED-DISPOSITIONS-20261027.json",
      "sha256": "2c848e5a5f264019a594803701e3a90968c1a88e4a179cf9c583f96ce64b3feb"
    },
    "state": "24_CURRENT_ROUTES_FULL_TEXT_THREE_WORD_SCAN_AND_205_CUE_DISPOSITIONS_COMPLETE_WITH_HISTORY_AND_ACCESS_GAPS",
    "whole_journal_family_complete": false
  },
  "J322": {
    "all720_new_fragments_root_checked": {
      "bytes": 1180,
      "path": "_tracking/J322-prior423-all22-batches-root-partition-and-pins-PASS-20261027.json",
      "sha256": "b0a7c6f961e455fb13d82da1aa43f90b0414045a0e6acab1f44ab1da17e1ff89"
    },
    "current_Numdam_pages": 13778,
    "current_Numdam_works_body_scanned": 687,
    "current_open_certification_from_this_scan": false,
    "different_old_vs_current_PDF_hashes": 325,
    "fresh273_END": {
      "bytes": 129189,
      "path": "_tracking/J322-journal-breadth-B-gauss2043-20261027/J322-FINITE-NUMDAM687-FRESH273-326CUES-END-PROPOSAL.json",
      "sha256": "32e852eace42275aba5c9d4fa28d393142817283fa489024bbc072b28ad7d2a3"
    },
    "known_union_including_outside_2025_works": 696,
    "outside_2025_access_gaps": 9,
    "prior414_repair_END": {
      "bytes": 98154,
      "path": "_tracking/J322-prior423-predicate-repair-B-gauss2043-20261027/PRIOR423-COMPLETE-PREDICATE-REPAIR-SCAN-END.json",
      "sha256": "99655461a2b07372da21aa9f894b6a45da0cddbafde0bca6d9e4a7df2e87b735"
    },
    "same_old_vs_current_PDF_hashes": 89,
    "sparse_OCR_pages": 87,
    "whole_journal_family_complete": false
  },
  "Read_renorming": {
    "new_admission_credit_this_delta": 1,
    "page": {
      "bytes": 2437,
      "path": "operators/lead-59d2ca6a5f45c305.md",
      "sha256": "aadd3c5c61dcdd86c05f7130cd0b8aec9d04cd605af2f7cbb764a3a161c1907f"
    },
    "reconciliation": {
      "bytes": 910,
      "path": "_tracking/focused-Read-renorming-C163-A-20261028/ROOT-READ-RENORMING-ONE-ADMISSION-RECONCILIATION-ONCE-20261028.json",
      "sha256": "b3d12f5796ae48c533233fcd1fff59fd765fe15afa7c5f0ffa39dd4c266b1594"
    },
    "state": "ADMITTED_ONCE"
  },
  "W002": {
    "current_access_gap": {
      "bytes": 683,
      "path": "_tracking/ROOT-W002-CURRENT-HOMEPAGE-ACCESS-GAP-20261028.json",
      "sha256": "ad96d1cba0b27cde5132d104e4c8200f3ff90ed90e18a30486c4f5075fb21773"
    },
    "new_reading_credit": 0,
    "next": "Reuse retained mission listings; individual theorem/proof dependency checks remain pending. Homepage timeout is not negative coverage.",
    "whole_family_complete": false
  },
  "Wasserstein_splines_C165": {
    "owner_gate": {
      "bytes": 4078,
      "path": "_tracking/focused-measure-valued-Wasserstein-splines-C165-A-20261028/PRIMARY2018-PATH-UNIQUE-NOT-GENERAL-2021-PUBLISHED-COUNTEREXAMPLES-AND-FORMAL-EQUIVALENCE-HOLD.json",
      "sha256": "4ebd33716ec97cfe43c0adf7d288694da0a42254858320d7748ef9b7e635054d"
    },
    "reason": "Universal uniqueness has publishedcounterexamples; exact Monge/path/relaxedvelocity targets and attainedoptima mustnotbeconflated. Eq24 drop-gradient/H2 class remains underqualified. Do not invent a restricted benchmark.",
    "state": "FORMULATION_AND_PUBLISHED_STATUS_HOLD_NO_ADMISSION"
  },
  "arxiv_legacy_quality": {
    "Root_GO": {
      "bytes": 29926,
      "path": "_tracking/fresh-original731-755-25000-CURRENT699165-RESERVED706730-METADATA-20261028/SOURCE-PROPOSAL/ROOT-GENERIC731755-EXACT25000-DURABLE-SUPERVISOR-SOURCE-GO-ONCE-20261028.json",
      "sha256": "aab808191c07e7be86026de0cc52d0a584b836d68adcdeee0815b9c906104005"
    },
    "display": "The next25,000-record batch (731â€“755) is running once on VT_ampere under source1770615, parent1770613 and durable supervisor1770612. The latest normal-boundary snapshot confirms15 STARTs,0terminals,105,804,972 retained compressed result bytes, no recorded errors/PARKED state and3,116,937,216 free Scratch bytes above the2.5GiB producer floor. No quality credit is assigned. Capture true owned waits/all75 native outputs and independently audit them before acceptance; never replay because an observation times out. Accepted totals remain1,575,795 outcomes,1,028,890 usable body scans and724,165 completed repair exclusions;437,561 earlier attempts remain quality-unverified. Source-free756â€“780 metadata preparation is delegated using actual724165 plus the exact running731 reservation; its private749165 union is unaccepted and gives no source authority.",
    "first_actual_snapshot": {
      "bytes": 12237,
      "path": "_tracking/fresh-original731-755-25000-CURRENT699165-RESERVED706730-METADATA-20261028/SOURCE-PROPOSAL/ACTUAL-GENERIC731755-FIRST-SOURCE-STATUS-RESPONSE.json",
      "sha256": "02a266aeb47ded942cd8065675a496e7e765540f8bce24d47ceac2fe817a0996"
    },
    "latest_normal_boundary_snapshot": {
      "bytes": 12212,
      "path": "_tracking/fresh-original731-755-25000-CURRENT699165-RESERVED706730-METADATA-20261028/SOURCE-PROPOSAL/ACTUAL-GENERIC731755-NORMAL-BOUNDARY-LIVE-PROGRESS.json",
      "sha256": "9305e89032a780eafadcdf5fd6ab9e3c8aa9e0b49bcdbbadece0e4bbe05d55e4"
    },
    "new_distinct_ID_credit": 0,
    "original_indices": [
      731,
      755
    ],
    "parent_PID": 1770613,
    "quality_credit": 0,
    "source_PID": 1770615,
    "source_invocations": 1,
    "source_records": 25000,
    "state": "SOURCE1770615_ACTIVE_ONCE_ALL15_STARTED_NORMAL_BOUNDARY_NO_QA_CREDIT",
    "supervisor_PID": 1770612
  },
  "arxiv_retained_context": {
    "C138_root_binding": {
      "bytes": 24555,
      "path": "_tracking/arxiv4148-C138-all120-root-native-retained-bindings-END-20261027.json",
      "sha256": "dda07bb4d4038827472b27acd3afce4ed3cab2f0fa2df965b0bc6ebd3ccab301"
    },
    "C139_root_binding": {
      "bytes": 24573,
      "path": "_tracking/arxiv4148-C139-all120-root-native-retained-bindings-END-20261027.json",
      "sha256": "21044fe76407eec8328924045de2f85dd4c987f8b0e7c189c7a8ef3a046a1b3d"
    },
    "C140_root_binding": {
      "bytes": 24592,
      "path": "_tracking/arxiv4148-C140-all120-root-native-retained-bindings-END-20261027.json",
      "sha256": "e0c8ca2ad08fefa0ef466d7131e4a14a474a5dff7adf8820dd3cecf4d2d31638"
    },
    "C141_root_binding": {
      "bytes": 24858,
      "path": "_tracking/arxiv4148-C141-all120-root-native-retained-bindings-END-20261027.json",
      "sha256": "f7d89685e69800ba36befb86552a2f54c432b7d4da07670b7cecf9a0110fd455"
    },
    "C142_all_retained_read": true,
    "C142_root_binding": {
      "bytes": 24393,
      "path": "_tracking/arxiv4148-C142-all120-root-native-retained-bindings-END-20261027.json",
      "sha256": "873a612cc4d5061a9f519d25c9a221c0c8ea98724625485ab6c7024c7889c3c4"
    },
    "C142_unretained47_preserved": true,
    "C143_missing": 0,
    "C143_original_start": 4432,
    "C143_root_binding": {
      "bytes": 24234,
      "path": "_tracking/arxiv4148-C143-all120-root-native-retained-bindings-END-20261027.json",
      "sha256": "aee3f3af05e1e8c6eff0a103876c2f0a69e02544df3c8312d056fa601b688639"
    },
    "C144_root_binding": {
      "bytes": 25749,
      "path": "_tracking/arxiv4148-C144-all120-root-native-retained-bindings-END-20261027.json",
      "sha256": "ea7c7c2fffa77664e7e01a2dc59aaf1ee605623bddf082c1aef9231db27a9560"
    },
    "C145_root_binding": {
      "bytes": 3360,
      "path": "_tracking/arxiv4148-C145-all13-root-native-retained-bindings-END-20261027.json",
      "sha256": "c5bdabb4a128a06a5808285e07c57089825512cbf7ff2afcc455f42a660b459a"
    },
    "C160": {
      "Root_SQL_reconciliation": {
        "bytes": 704,
        "path": "_tracking/C160-source1256420-Root20-priority-retained-20261028/ROOT-C160-20-PAPER-62-CONTEXT-ONCE-RECONCILIATION-PASS.json",
        "sha256": "46b92d298da7c7196f44aa258bd3694f671d9c32b8fa201c76e4203c1983f654"
      },
      "contexts": 62,
      "missing_contexts": 0,
      "owner_END": {
        "bytes": 15295,
        "path": "_tracking/C160-source1256420-Root20-priority-retained-20261028/END.json",
        "sha256": "e01a17dca1efae0ea4607887b0418b380e84c41dc2d916c5d563f2bb6245a758"
      },
      "papers": 20,
      "selection_is_nonconsecutive": true,
      "unselected_worklist_rows_preserved": 6645,
      "whole_source_credit": 0,
      "windows": 52
    },
    "C161": {
      "Root_SQL_reconciliation": {
        "bytes": 703,
        "path": "_tracking/C161-source1305809-A30-priority-retained-20261028/ROOT-C161-30-PAPER-76-CONTEXT-ONCE-RECONCILIATION-PASS.json",
        "sha256": "e606cebfd4efcddc300e5bb28be864da63e44da4ff043a358a9d2245ef3b1810"
      },
      "contexts": 76,
      "missing_contexts": 0,
      "owner_END": {
        "bytes": 10385,
        "path": "_tracking/C161-source1305809-A30-priority-retained-20261028/END.json",
        "sha256": "93672b98e986f33548b09a6aed84830c5a668091eda94d2776ed879e6ee2c3e8"
      },
      "papers": 30,
      "selection_is_nonconsecutive": true,
      "unselected_worklist_rows_preserved": 6643,
      "whole_source_credit": 0,
      "windows": 64
    },
    "C162": {
      "Root_SQL_reconciliation": {
        "bytes": 703,
        "path": "_tracking/C162-source1368090-A30-priority-retained-20261028/ROOT-C162-30-PAPER-72-CONTEXT-ONCE-RECONCILIATION-PASS.json",
        "sha256": "d3d6d78943142169982a036bd3454e7f586ee1d9c8c5817df96ff7825a390df3"
      },
      "contexts": 72,
      "missing_contexts": 0,
      "owner_END": {
        "bytes": 11182,
        "path": "_tracking/C162-source1368090-A30-priority-retained-20261028/END.json",
        "sha256": "c00df02a8e073a5c2d0ba5b215e42ab76f9d9b39d4c2563d071e6834c7ed3c95"
      },
      "papers": 30,
      "selection_is_nonconsecutive": true,
      "unselected_worklist_rows_preserved": 11230,
      "whole_source_credit": 0,
      "windows": 62
    },
    "active_claim": null,
    "active_missing_unread": 0,
    "advisory_frontier_is_not_contiguous_or_whole_queue_completion": true,
    "body_reviewer_temporarily_assigned_to_independent_b06_audit": false,
    "completed_C138": {
      "bytes": 1202429,
      "path": "_tracking/arxiv4148-native-retained-body-pass-C138-A-NAT3775-3913-END-20261027.json",
      "sha256": "f1f567b719d16ed89bcc2b4db03a0f30f2ba7e06d1c5ae1337f44c29a4dc97ab"
    },
    "completed_C139": {
      "bytes": 1397104,
      "path": "_tracking/arxiv4148-native-retained-body-pass-C139-A-NAT3914-4039-END-20261027.json",
      "sha256": "53f6ea834abd4a5f83d1f9703e3763c9baf1c51484cde9266eaff4263dec4dec"
    },
    "completed_C140": {
      "bytes": 1253118,
      "path": "_tracking/arxiv4148-native-retained-body-pass-C140-A-NAT4040-4171-END-20261027.json",
      "sha256": "3d87e004144ff2fd6d1bf91712dffc4f55b925cac88177437a4163aaf0547b74"
    },
    "completed_C141": {
      "bytes": 1178657,
      "path": "_tracking/arxiv4148-native-retained-body-pass-C141-A-NAT4172-4305-END-20261027.json",
      "sha256": "62134f4d40426bc69f250a35df841345894e88e18a848ddba51425e56f6f2977"
    },
    "completed_C142": {
      "bytes": 1391944,
      "path": "_tracking/arxiv4148-native-retained-body-pass-C142-A-NAT4306-4431-END-20261027.json",
      "sha256": "20369ac538e03ad32a2c7d86da50fee3da371ce326c116717b96d96a16c4c1b3"
    },
    "completed_C143": {
      "bytes": 1199287,
      "path": "_tracking/arxiv4148-native-retained-body-pass-C143-A-NAT4432-4562-END-20261027.json",
      "sha256": "8a86a596d04a4988bc0a3e624ac8306a499719b694c202a0c2c84aabc37bf67c"
    },
    "completed_C144": {
      "bytes": 1390366,
      "path": "_tracking/arxiv4148-native-retained-body-pass-C144-A-NAT4563-4698-END-20261027.json",
      "sha256": "277693eb0655aa4b19b098b8fecd70dbf2c9310609a14cbf598520171ebd4c64"
    },
    "completed_C145": {
      "bytes": 159554,
      "path": "_tracking/arxiv4148-native-retained-body-pass-C145-A-NAT4699-4713-END-20261027.json",
      "sha256": "b588316ab436dce2582453fcacbd08b6e259a7613cc5013acfce204465478df9"
    },
    "completed_frontier_advisory": 4713,
    "continuation": "C144Ã¢â‚¬â€œC145 are finished at retained-passage scope. No unselected current natural tail remains, while earlier reserved/deferred/retention gaps stay pending; true contiguous cursor remains2441.",
    "last_completed_claim": {
      "bytes": 14935,
      "path": "_tracking/arxiv4148-natural13-review-C145-A-NAT4699-4713-exclusive-claim-20261027.json",
      "sha256": "6a9a21994283f04f24c3c69b769d65a6afd3da4e25c24d632944a1bdfe032271"
    },
    "next_completed_frontier_version_key": "0911.4148@v1",
    "predecessor_key": "next_cursors.arxiv_retained_context",
    "previous_full_cursor_in_immutable_predecessor": {
      "bytes": 65260,
      "path": "_tracking/research-delta-583-negative-Gaussian-C136-C137-source-metadata-correction-20261027.json",
      "sha256": "843e552cd63806acb2eab8774481024b6b8cf2339136928e40378fe8dd812fda"
    },
    "true_contiguous": 2441,
    "unclaimed_next_advisory": null,
    "unclaimed_next_is_after_current_exclusive_C142_reservation": true,
    "unretained_gaps_preserved": true
  },
  "compact_current_journal_family_exclusions": {
    "map": {
      "bytes": 21795,
      "path": "_tracking/ROOT-CURRENT340-COVERED-JOURNAL-SERIES-IDENTITIES-FOR-DISJOINT-CLAIMS-20261028.json",
      "sha256": "7b18507c2e222fd23b1e14a8aeabab25c8c5448378321bae96dc996ab4021f3d"
    },
    "scope": "193journal/series/proceedings identities withsomefiniteindexedreading,notentirefamilies. CombinewithfreshbaseID/fullclaim exclusions before new work."
  },
  "current_C163_retained_reading": {
    "contexts": 53,
    "exclusive_claim": {
      "bytes": 43667,
      "path": "_tracking/source1446650-C163-A30-exclusive-retained-reading-claim-20261028.json",
      "sha256": "91f62c3886d4387b55697ef461768a22937883db04433f60ebbc1c175b93d1c6"
    },
    "selected_papers": 30,
    "source_PID": 1446650,
    "state": "A reading; notes incomplete so no canonical joined-reading credit yet.",
    "whole_paper_credit": 0
  },
  "current_keeper_protection": {
    "distinct_existing_paths": 830,
    "local_deletion_authority": false,
    "postcheck": {
      "bytes": 1394,
      "path": "_tracking/ROOT-EXACT76-SOURCE1702490-RETIREMENT-830KEEPERS-ALL79-POSTCHECK-PASS-20261028.json",
      "sha256": "28ffd5e34d26ef3761f7801759686b973cbcf6e3f1846e2d87fa548c1ad68f62"
    },
    "protection": {
      "bytes": 495999,
      "path": "_tracking/ROOT-CURRENT830-LOCAL-KEEPER-PROTECTION-BEFORE-EXACT76-SOURCE1702490-20261028.json",
      "sha256": "a76b503dad77a4ebd1d0255ea6ed142b31044c0dad6c7d99de5a65d189aafb6b"
    }
  },
  "fixed_ambient_Morse_Betti": {
    "new_admission_credit_this_delta": 1,
    "page": {
      "bytes": 3864,
      "path": "geometry-topology/lead-b2322ac3ab3a8eb6.md",
      "sha256": "da7850df1cafa90b1045cefc9a66786e652f52b1dfaceb16ef3cc29a4b3cd869"
    },
    "reconciliation": {
      "bytes": 962,
      "path": "_tracking/focused-fixed-ambient-Morse-index-Betti-C164-A-20261028/ROOT-FIXED-AMBIENT-INDEX-ONE-ADMISSION-RECONCILIATION-ONCE-20261028.json",
      "sha256": "3642d84bede7987c83a933679c61887266c57c1adaea52e5a1affec046db6bc9"
    },
    "state": "ADMITTED_ONCE"
  },
  "future_Flat5": {
    "Root_review": {
      "bytes": 2345,
      "path": "_tracking/fresh-original566-580-15000-CURRENT544165-RESERVED551565-METADATA-20261028/SOURCE-PROPOSAL/FUTURE-GENERIC-FLAT-DATA-CONTROLLERS/ROOT-FUTURE-ONLY-FLAT5-16MiB-BOUNDED-REPAIR-ID-REVIEW-PASS-20261028.json",
      "sha256": "364c557497500309026808f258cac67ebfe4a5b8337d303e4b3d091d03a10d82"
    },
    "current_source681_not_changed": true,
    "separate_Source_GO_required": true,
    "state": "REVIEWED_FOR_FUTURE_CONTEXT_ONLY"
  },
  "historical_book_frontiers": {
    "active_index": {
      "bytes": 2934,
      "path": "_tracking/historical-book-frontier-index-C-20261028/HISTORICAL-BOOK-FRONTIER-INDEX-ZERO-NEW-V2-C-HANDOFF.json",
      "sha256": "e967feb8269d977fba611745297e417e0b4af23292422c56ee58e3bac364c663"
    },
    "all_pointer_and_text_QA": {
      "bytes": 2791,
      "path": "_tracking/historical-book-frontier-index-C-20261028/HISTORICAL-BOOK-INDEX-V2-ALL16435-POINTERS-AND-RETAINED-TEXT-QA-C-END.json",
      "sha256": "f4974619b3c37ada1bfac93b7beafc481c813759852c3ec4d2492378b34bff23"
    },
    "automatic_migration_authority": false,
    "new_reading_credit": 0,
    "remaining": "Bibliographic role QA is required before any63 suggested source migrations. Exact byte hashes warn against duplicate acquisition across aliases; they do not validate source-family attribution. B284 has Sontag evidence routed to a logged Zabczyk title and must remain a hold; mixed foreign/correct rows and shared dfea/7412 hashes require actual-work identification. Do not bulk-adopt suggestions.",
    "source_family_closures": 0
  },
  "historical_book_repeat_index": {
    "B284": "Foreign Sontag body cannot credit logged Zabczyk",
    "B307": "One native289 K3 window only, Root verification pending",
    "Root_once_reconciliation": {
      "bytes": 702,
      "path": "_tracking/ROOT-SIXTY-MATCHING-HISTORICAL-BOOK-FAMILIES-MIGRATION-ONCE-20261028-RECONCILIATION.json",
      "sha256": "d9f9229ee0aff845e29616157f59813afbcd541186f143a1b544ad248eee1d61"
    },
    "fresh_reading_credit": 0,
    "historical_matching_families_migrated": 60,
    "historical_supported_families_pending_migration": 0,
    "index_version": "V4",
    "new_fresh_reading_credit": 0,
    "related_author_chapter_B091": "Root scope HOLD",
    "role_scope_QA": {
      "bytes": 347080,
      "path": "_tracking/historical-book-frontier-index-C-20261028/HISTORICAL-63-BOOK-SOURCE-ROLE-SCOPE-QA-TABLE-V4-FINAL-C-END.json",
      "sha256": "b01f19db184ae2b3436fd4cb1d9a85f58c65f1e5fdf9fb78ee7287f188d1e4e4"
    },
    "whole_source_closure": 0
  },
  "intersection_additive_spectrum": {
    "reconciliation": {
      "bytes": 579,
      "path": "_tracking/focused-intersection-index-additive-spectrum-C162-A-20261028/ROOT-INTERSECTION-ONE-ADMISSION-RECONCILIATION-ONCE.json",
      "sha256": "b07ddb501fb6ab2b8623856ef1e24958b0a1b02587d7261ee3ba07dc06bc8e11"
    },
    "state": "ADMITTED"
  },
  "invelope_contact_local_finiteness": {
    "admitted": "probability-statistics/lead-30d0a01d1fdb7d6b.md",
    "no_repeat": true
  },
  "journal_finite_pairs": {
    "Root_reconciliations": [
      {
        "bytes": 740,
        "path": "_tracking/ROOT-J005-J014-TWO-FINITE-JOURNAL-UNITS-ONCE-RECONCILIATION-20261028.json",
        "sha256": "891591e330081a0f5dbdc890248db0d8ac23e978f04f5c5d381ed86f70a935e4"
      },
      {
        "bytes": 850,
        "path": "_tracking/ROOT-J144-J148-TWO-FINITE-JOURNAL-UNITS-20261028-RECONCILIATION-ONCE.json",
        "sha256": "0c69a6c89f64233f67fcd4942e8cb9fb72f85343213c965281455388e4cb69c8"
      }
    ],
    "state": "FOUR_FINITE_JOURNAL_UNITS_JOINED_ONCE",
    "whole_family_closures": 0
  },
  "latest_accepted_source1511484": {
    "newdistinctIDs": 0,
    "quality": {
      "bytes": 19048,
      "path": "_tracking/source1511484-generic631655-independent-retained-audit-B-20261028/ROOT-EXACT25000-SOURCE1511484-ACCEPTANCE-AND-QUALITY-OVERLAY-ONCE-20261028.json",
      "sha256": "84a3f3cd65797da2ded51030b2c5c186906293034cc124d3b0bf3a9a492e1a07"
    },
    "registration": {
      "bytes": 1868,
      "path": "_tracking/source1511484-generic631655-independent-retained-audit-B-20261028/ROOT-EXACT25000-REPEAT-REGISTRATION-ONCE-20261028.json",
      "sha256": "81d63630248e7b1d37d2010000fe1aabbca8325f0f41dc8c0b8fcc1fe5fb3fee"
    },
    "repeat_exclusion_cache": {
      "bytes": 1445602,
      "path": "_tracking/source1511484-generic631655-independent-retained-audit-B-20261028/ROOT-REGISTERED649165-COMPLETED-REPAIR-IDS.txt.gz",
      "sha256": "f4dd0353a5ed6524de35d558ae579935f90c945b6843fcb339797f73a89eab5d",
      "storage_root": "home"
    },
    "wholepaperreadingcredit": 0
  },
  "latest_accepted_source1637552": {
    "ID_cache": {
      "bytes": 1556267,
      "path": "_tracking/source1637552-generic681705-independent-retained-audit-B-20261028/ROOT-REGISTERED699165-COMPLETED-REPAIR-IDS.txt.gz",
      "sha256": "d722f0efa84f6e81ce26e0f06e3240d3d3eebdfde860b3e48896087313b3d4da",
      "storage_root": "home"
    },
    "new_distinct_IDs": 0,
    "quality": {
      "bytes": 19968,
      "path": "_tracking/source1637552-generic681705-independent-retained-audit-B-20261028/ROOT-EXACT25000-SOURCE1637552-ACCEPTANCE-AND-QUALITY-OVERLAY-ONCE-20261028.json",
      "sha256": "776b744022cece99685120ab39dd20f5cc63c49891b92411ae96b47bd5a01906"
    },
    "registration": {
      "bytes": 1868,
      "path": "_tracking/source1637552-generic681705-independent-retained-audit-B-20261028/ROOT-EXACT25000-REPEAT-REGISTRATION-ONCE-20261028.json",
      "sha256": "d564663fa89013c547c0cc062849f4ac90050ceef0b3580af4572258be90015f"
    }
  },
  "metadata681_recovery": {
    "actual_current_registered": 674165,
    "independent_peer": {
      "bytes": 70563,
      "path": "_tracking/fresh-original681-705-25000-CURRENT649165-RESERVED656680-METADATA-20261028/A-INDEPENDENT-SAVED681705-EXACT25000-ACTUAL674165-METADATA-RECOVERY-CHILD0-PARENT1-PASS-NO-SOURCE.json",
      "sha256": "5abe83024182b227179902b09efb86b4eb03f56e413991f55d1f73fb42768902"
    },
    "no_rerun": true,
    "original_child_exit": 0,
    "original_parent_exit": 1
  },
  "new_finite_books_20261027": {
    "B079": "All10obtainedscientific469pages+19obtainedback;front10zerooverlap;TOC/printedparity/OCR/pixel/othereditiongaps remain",
    "B080": "All4obtainedscientific315pages+18obtainedback;front12zerooverlap;138/330/OCR/pixel/othereditiongaps remain",
    "B081": "All13obtainedscience396pages+4scientificappendixpages=400science;46otherback;front12zerooverlap;434/OCR/pixel/othereditiongaps remain",
    "matter_handoff": {
      "bytes": 2329,
      "path": "_tracking/B079-B080-B081-six-native-front-back-pdfium-C-20261027/SIX-NATIVE-MATTER-87NEWBACKPAGES-FOUR-SCIENTIFIC-APPENDIXPAGES-C-HANDOFF.json",
      "sha256": "70f7107479d9e4f6de29ebe8bf79af8c8185e311f9252648e8e668e44ddd6905"
    },
    "matter_root_binding": {
      "bytes": 798,
      "path": "_tracking/B079-B080-B081-six-native-front-back-pdfium-C-20261027/ROOT-SIX-MATTER-PIN-SLICE-NOTE-COVERAGE-AND-OVERLAP-PASS-20261028.json",
      "sha256": "a79c5c37cd76bfd7af2dddd08cca33ee41ba856b8d65cf8de4705d4046007cbd"
    }
  },
  "next_source_interface_contract": {
    "cached_home_role": "9007-byte future Flat5 definitions contain prepare",
    "metadata_preflight_role": "7670-byte definitions contain preflight_once",
    "qualification": "The earlier role mix-up failed before actual prefix execution, ownership/namespace mutation or source launch. Its receipts remain preserved; correctedV2 passed actual prefix and independent review. Future data assembly checks both callable roles before staging.",
    "state": "CORRECTED_BEFORE_SOURCE_LAUNCH"
  },
  "precise_book_resolution_exclusions_20261028": {
    "admissions": 0,
    "receipts": [
      {
        "bytes": 22154,
        "path": "_tracking/B061-Taylor-planar-projection-increase-precise-gate-C-20261028/TAYLOR-EXACT-LOCAL-ALL-DIRECTIONS-WEAK-INEQUALITIES-THEOREM0-7-PUBLISHED-RESOLUTION-EXCLUSION-C-END.json",
        "sha256": "cf85275971b9a55f31949d153c5c120f6eae75603445f5c52f724485639d3945"
      },
      {
        "bytes": 19432,
        "path": "_tracking/B113-zonoid-polar-distance-precise-gate-C-20261028/ZONOID-POLAR-EXACT-SCHNEIDER-ASYMPTOTIC-THEOREM1-1-2026-ANNOUNCEMENT-EXCLUSION-C-END.json",
        "sha256": "a01e586819b11e576467c0fbb626290d2def8803d45109864eff5a9844899753"
      },
      {
        "bytes": 91651,
        "path": "_tracking/B113-three-valuation-current-primary-gates-C-20261028/SIX-EXACT-HISTORICAL-VALUATION-TARGETS-PUBLISHED-2014-2017-AND-2026-ANNOUNCEMENT-EXCLUSIONS-C-END.json",
        "sha256": "5e07eaadb60eee09201d74bd9abecf088487ced11c61b0fecdaba372d247e58b"
      }
    ],
    "whole_proof_certification": false
  },
  "random_spectrahedra_edge_collision": {
    "new_admission_credit_this_delta": 1,
    "page": {
      "bytes": 3719,
      "path": "spectral/lead-2411c837cab015a2.md",
      "sha256": "98de396f1d525520dededf15c7d7e4fbab0268132517811238dadac4eaeda85b"
    },
    "reconciliation": {
      "bytes": 965,
      "path": "_tracking/focused-random-spectrahedra-edge-singularities-C164-A-20261028/ROOT-SPECTRAHEDRA-RATIO-ONE-ADMISSION-RECONCILIATION-ONCE-20261028.json",
      "sha256": "3c1296b22068cca87a5ee420107cee42226154c45f9a4eaed1c3ed55a719c306"
    },
    "state": "ADMITTED_ONCE"
  },
  "scalar_fractional_BV_singular_limit": {
    "admitted": "pdes-materials/lead-b0bafeea5be477c5.md",
    "no_repeat": true
  },
  "source672893_positive_passages": {
    "C158_END": {
      "bytes": 3244,
      "path": "_tracking/C158-source672893-first75000-A60-priority-20261028/END.json",
      "sha256": "e424aac08898aba231d67cbbafbae9060931371979e3c8baac947587060f7fa9"
    },
    "C158_credit": {
      "contexts": 655,
      "papers": 60,
      "windows": 376
    },
    "C158_other_positive_pending": 1235,
    "C159_END": {
      "bytes": 2643,
      "path": "_tracking/C159-source672893-first75000-block1-tail-A-priority-20261028/END.json",
      "sha256": "cb36f419e64c492ca591f169c4352f01326b5de3888900b004ea224f5f22f39c"
    },
    "C159_credit": {
      "contexts": 57,
      "papers": 12,
      "windows": 36
    },
    "C159_nonselected_positive_pending": 349,
    "all_other_pending_and_gaps_preserved": true,
    "block1_positive_queue_EOF6778_is_priority_selection_only": true,
    "current_candidate_review": "DPPmedianvariance gate; Airy and planarheat-isotherm andchi-squaremeaningfulrange resolvedexclusions retained.",
    "next_block_requires_fresh_claim_audit": true,
    "predecessor_key": "next_cursors.source672893_positive_passages",
    "previous_complete_cursor": {
      "bytes": 95895,
      "path": "_tracking/research-delta-605-tail10k-accepted-534165-registered-243breadth-andB216-20261028.json",
      "sha256": "6dee2a7e9e94600498d0e9856e79e831f4d895ffdc350f1fe8261141df6e6872"
    },
    "whole_paper_or_archive_credit": 0
  },
  "source_breadth_index": {
    "complete_source_family_credit": 0,
    "indexed_sources_with_recorded_reading": 272,
    "interpretation": "272 of741source families have some indexed discovery reading(36.7%breadth), usually partial. Some earlier reading was migrated into the index; this is not whole-log completion or proof of correct attribution of all legacy routes.",
    "new_finite_bundle_rows": 31,
    "reading_units": 127287,
    "source_family_reading_is_usually_partial": true,
    "source_kind_breakdown": [
      {
        "families_with_some_indexed_reading": 1,
        "kind": "Archive",
        "source_families": 1
      },
      {
        "families_with_some_indexed_reading": 85,
        "kind": "Book",
        "source_families": 306
      },
      {
        "families_with_some_indexed_reading": 0,
        "kind": "Catalogue",
        "source_families": 25
      },
      {
        "families_with_some_indexed_reading": 181,
        "kind": "Journal",
        "source_families": 353
      },
      {
        "families_with_some_indexed_reading": 1,
        "kind": "Proceedings series",
        "source_families": 1
      },
      {
        "families_with_some_indexed_reading": 1,
        "kind": "Reference book",
        "source_families": 1
      },
      {
        "families_with_some_indexed_reading": 3,
        "kind": "Series",
        "source_families": 53
      },
      {
        "families_with_some_indexed_reading": 0,
        "kind": "Website",
        "source_families": 1
      }
    ],
    "total_source_families": 741
  },
  "upper_gamma_hold": {
    "bytes": 3281,
    "path": "_tracking/C144-Haglund-gamma-Root-20261027/ROOT-BOUNDED-PRIMARY-REVIEW-AND-PENDING-GATES-HANDOFF.json",
    "sha256": "37460e11392ffe64a21a87ac5c136459bf1cf3e3e74201e2cafe50930e90107b"
  },
  "water_wave_band_order": {
    "admission": false,
    "owner": "_tracking/focused-water-wave-Bloch-band-order-C162-A-20261028/WATER-WAVE-BAND-ORDER-EXACT-PRIMARY-CURRENT-981MODELS614P-1704ROWS-PEER-PASS-NO-ADMISSION.json",
    "state": "PRECISE_OWNER_PROPOSAL_PENDING_INDEPENDENT_ROOT_REVIEW"
  },
  "water_wave_candidate": {
    "reconciliation": {
      "bytes": 815,
      "path": "_tracking/focused-water-wave-Bloch-band-order-C162-A-20261028/ROOT-WATER-WAVE-ONE-ADMISSION-RECONCILIATION-ONCE.json",
      "sha256": "df96be73d6e884156ef992227946614ffb1d03a819dc7892a21ed1daab6cbcec"
    },
    "state": "ADMITTED616_CATALOGUE_TOTAL_AFTER_TWO_NEW_PAGES"
  },
  "J208": {
    "finite_review": {
      "sources": [
        "J208",
        "J166"
      ],
      "owner_summary": {
        "path": "_tracking/J208-J166-TWO-FINITE-DISCOVERY-UNITS-SIX-DISJOINT-WINDOWS-ZERO-DOWNLOAD-HANDOFF-C-END-20261028.json",
        "bytes": 3649,
        "sha256": "07db0f3f38055c2462827820effa4ca8942cbcad494720e807aa267c800aef43"
      },
      "Root_reconciliation": {
        "path": "_tracking/ROOT-J208-J166-TWO-FINITE-JOURNAL-UNITS-WITNESS-QUALIFIED-20261028-RECONCILIATION-ONCE.json",
        "bytes": 885,
        "sha256": "7cde28de34c3791066108d9f3c46fd8693b07d01a46986b40d1d55e9de5e9988"
      },
      "contexts": 8,
      "disjoint_windows": 6,
      "unique_context_characters": 4118,
      "native_diagnostic_excerpt_characters": 1800,
      "whole_page_or_paper_credit": 0,
      "whole_family_closures": 0
    },
    "consumed_sparse_worklist_position1_based": 3,
    "version_key": "1801.01580@v1",
    "scope": "Exact retained contexts and available native diagnostic excerpt only; its role is qualified in the pinned binding. Unselected worklist positions and latest-version/formulation/access gaps remain pending.",
    "whole_family_complete": false
  },
  "J166": {
    "finite_review": {
      "sources": [
        "J208",
        "J166"
      ],
      "owner_summary": {
        "path": "_tracking/J208-J166-TWO-FINITE-DISCOVERY-UNITS-SIX-DISJOINT-WINDOWS-ZERO-DOWNLOAD-HANDOFF-C-END-20261028.json",
        "bytes": 3649,
        "sha256": "07db0f3f38055c2462827820effa4ca8942cbcad494720e807aa267c800aef43"
      },
      "Root_reconciliation": {
        "path": "_tracking/ROOT-J208-J166-TWO-FINITE-JOURNAL-UNITS-WITNESS-QUALIFIED-20261028-RECONCILIATION-ONCE.json",
        "bytes": 885,
        "sha256": "7cde28de34c3791066108d9f3c46fd8693b07d01a46986b40d1d55e9de5e9988"
      },
      "contexts": 8,
      "disjoint_windows": 6,
      "unique_context_characters": 4118,
      "native_diagnostic_excerpt_characters": 1800,
      "whole_page_or_paper_credit": 0,
      "whole_family_closures": 0
    },
    "consumed_sparse_worklist_position1_based": 30,
    "version_key": "1801.02630@v1",
    "scope": "Exact retained contexts and available native diagnostic excerpt only; its role is qualified in the pinned binding. Unselected worklist positions and latest-version/formulation/access gaps remain pending.",
    "whole_family_complete": false
  },
  "J023": {
    "finite_review": {
      "sources": [
        "J023",
        "J066"
      ],
      "owner_summary": {
        "path": "_tracking/J023-J066-TWO-FINITE-MATHEMATICAL-JOURNAL-DISCOVERY-UNITS-ALL13-CONTEXTS-HANDOFF-C-END-20261028.json",
        "bytes": 3663,
        "sha256": "9869d90d0866bea1e1d0e159ea126f7b67e1de2e8382f1f7871c062a1b64ef85"
      },
      "Root_reconciliation": {
        "path": "_tracking/ROOT-J023-J066-TWO-FINITE-JOURNAL-UNITS-20261028-RECONCILIATION-ONCE.json",
        "bytes": 850,
        "sha256": "f469c963543327f6d09ca7faaff635aee4d26cddcc6fb542cb39a677f074d860"
      },
      "contexts": 13,
      "disjoint_windows": 6,
      "unique_context_characters": 4884,
      "native_diagnostic_excerpt_characters": 1800,
      "whole_page_or_paper_credit": 0,
      "whole_family_closures": 0
    },
    "consumed_sparse_worklist_position1_based": 901,
    "version_key": "1801.07435@v1",
    "scope": "Exact retained contexts and available native diagnostic excerpt only; its role is qualified in the pinned binding. Unselected worklist positions and latest-version/formulation/access gaps remain pending.",
    "whole_family_complete": false
  },
  "J066": {
    "finite_review": {
      "sources": [
        "J023",
        "J066"
      ],
      "owner_summary": {
        "path": "_tracking/J023-J066-TWO-FINITE-MATHEMATICAL-JOURNAL-DISCOVERY-UNITS-ALL13-CONTEXTS-HANDOFF-C-END-20261028.json",
        "bytes": 3663,
        "sha256": "9869d90d0866bea1e1d0e159ea126f7b67e1de2e8382f1f7871c062a1b64ef85"
      },
      "Root_reconciliation": {
        "path": "_tracking/ROOT-J023-J066-TWO-FINITE-JOURNAL-UNITS-20261028-RECONCILIATION-ONCE.json",
        "bytes": 850,
        "sha256": "f469c963543327f6d09ca7faaff635aee4d26cddcc6fb542cb39a677f074d860"
      },
      "contexts": 13,
      "disjoint_windows": 6,
      "unique_context_characters": 4884,
      "native_diagnostic_excerpt_characters": 1800,
      "whole_page_or_paper_credit": 0,
      "whole_family_closures": 0
    },
    "consumed_sparse_worklist_position1_based": 261,
    "version_key": "1801.10421@v1",
    "scope": "Exact retained contexts and available native diagnostic excerpt only; its role is qualified in the pinned binding. Unselected worklist positions and latest-version/formulation/access gaps remain pending.",
    "whole_family_complete": false
  },
  "J263": {
    "finite_review": {
      "sources": [
        "J263",
        "J165"
      ],
      "owner_summary": {
        "path": "_tracking/J263-J165-TWO-FINITE-JOURNAL-UNITS-THREE-BODY-WINDOWS-NATIVE-WITNESS-GAP-HANDOFF-C-END-20261028.json",
        "bytes": 3649,
        "sha256": "fc9bb481ffca056a31a6355f62a015ebb36edd4584a61d705bca05f35e5d1347"
      },
      "Root_reconciliation": {
        "path": "_tracking/ROOT-J263-J165-TWO-FINITE-JOURNAL-UNITS-NATIVE-WITNESS-GAP-PRESERVED-20261028-RECONCILIATION-ONCE.json",
        "bytes": 906,
        "sha256": "8dc34b9bb22f779b3c9d058dad731c429a88a0d255897a8b893c044570e773e9"
      },
      "contexts": 3,
      "disjoint_windows": 3,
      "unique_context_characters": 1827,
      "native_diagnostic_excerpt_characters": 900,
      "whole_page_or_paper_credit": 0,
      "whole_family_closures": 0
    },
    "consumed_sparse_worklist_position1_based": 49,
    "version_key": "1801.03321@v1",
    "scope": "Exact retained contexts and available native diagnostic excerpt only; its role is qualified in the pinned binding. Unselected worklist positions and latest-version/formulation/access gaps remain pending.",
    "whole_family_complete": false
  },
  "J165": {
    "finite_review": {
      "sources": [
        "J263",
        "J165"
      ],
      "owner_summary": {
        "path": "_tracking/J263-J165-TWO-FINITE-JOURNAL-UNITS-THREE-BODY-WINDOWS-NATIVE-WITNESS-GAP-HANDOFF-C-END-20261028.json",
        "bytes": 3649,
        "sha256": "fc9bb481ffca056a31a6355f62a015ebb36edd4584a61d705bca05f35e5d1347"
      },
      "Root_reconciliation": {
        "path": "_tracking/ROOT-J263-J165-TWO-FINITE-JOURNAL-UNITS-NATIVE-WITNESS-GAP-PRESERVED-20261028-RECONCILIATION-ONCE.json",
        "bytes": 906,
        "sha256": "8dc34b9bb22f779b3c9d058dad731c429a88a0d255897a8b893c044570e773e9"
      },
      "contexts": 3,
      "disjoint_windows": 3,
      "unique_context_characters": 1827,
      "native_diagnostic_excerpt_characters": 900,
      "whole_page_or_paper_credit": 0,
      "whole_family_closures": 0
    },
    "consumed_sparse_worklist_position1_based": 54,
    "version_key": "1801.03441@v1",
    "scope": "Exact retained contexts and available native diagnostic excerpt only; its role is qualified in the pinned binding. Unselected worklist positions and latest-version/formulation/access gaps remain pending.",
    "whole_family_complete": false
  },
  "arxiv_current_scientific_hold": {
    "superseded_by_explicit_gap_acceptance": {
      "path": "_tracking/source1770615-independent-local-A25000-science-LF-20261028/CURRENT731-REPAIR-AWARE-AUDIT-PROPOSAL/ROOT-EXPLICIT-GAP-ACCEPTANCE-ONCE/ROOT-EXACT25000-SOURCE1770615-EXPLICIT-GAP-ACCEPTANCE-ONCE.json",
      "bytes": 31347,
      "sha256": "d660b0d3e53082e2fdc024a4cc34f5de31cc8f79ad4100ee7ef642ca17777659"
    },
    "original_failure_preserved": true,
    "current_batch": {
      "state": "SOURCE1770615_ACCEPTED_REPAIR_AWARE_ONE_ORIGINAL_FAILURE_HELD_NEXT756_NOT_STARTED",
      "original_indices": [
        731,
        755
      ],
      "source_PID": 1770615,
      "parent_PID": 1770613,
      "source_invocations": 1,
      "source_records": 25000,
      "accepted_quality_receipt": {
        "path": "_tracking/source1770615-independent-local-A25000-science-LF-20261028/CURRENT731-REPAIR-AWARE-AUDIT-PROPOSAL/ROOT-EXPLICIT-GAP-ACCEPTANCE-ONCE/ROOT-EXACT25000-SOURCE1770615-EXPLICIT-GAP-ACCEPTANCE-ONCE.json",
        "bytes": 31347,
        "sha256": "d660b0d3e53082e2fdc024a4cc34f5de31cc8f79ad4100ee7ef642ca17777659"
      },
      "registration": {
        "path": "_tracking/source1770615-independent-local-A25000-science-LF-20261028/CURRENT731-REPAIR-AWARE-AUDIT-PROPOSAL/ROOT-EXPLICIT-GAP-ACCEPTANCE-ONCE/ROOT-EXACT25000-REPEAT-REGISTRATION-ONCE.json",
        "bytes": 2081,
        "sha256": "5175a6b3da15e80b7f790a99458de9fad33558716e88a422605093d87f7a2245"
      },
      "original_failed_native_predicates": 1,
      "all_original_predicates_passed": false,
      "positive_retention_gap_rows": 28,
      "omitted_contexts_held": 1261,
      "quality_credit": 25000,
      "next_original_indices": [
        756,
        780
      ],
      "next_source_invocations": 0,
      "display": "Batch 731â€“755 is accepted once through the distinct repair-aware route: 17,884 usable scans, 7,065 coverage gaps and 51 failures. All 11,007 positive rows remain queued; 28 positive rows retain explicit omissions totaling 1,261 contexts. The original unit09 row362 count predicate still fails in its immutable native record; the separately verified same-PDF/text sidecar holds it as a positive coverage gap, never a usable scan. Source and parent owned waits returned zero. Accepted totals are now 1,600,795 diagnostic outcomes and 1,046,774 usable scans, with 412,561 earlier attempts quality-unverified and 749,165 completed repair IDs excluded from replay. The next 756â€“780 metadata is saved; its same 749,165 exclusion union must be rebound to the actual accepted cache. No next source has started. Reviewed jobV2/verifierV3 integration is independently peered but needs prospective data, actual prefix/resource checks and a separate exact source GO."
    }
  },
  "additive_cached_journal_identity_index": {
    "receipt": {
      "path": "_tracking/fresh-original566-580-15000-CURRENT544165-RESERVED551565-METADATA-20261028/SOURCE-PROPOSAL/FUTURE-GENERIC-FLAT-DATA-CONTROLLERS/ADDITIVE-JOURNAL-JOIN-UNIT01-ACCEPTED157-170-20261028/JOURNAL-FIELD-INDEX-ONCE.json",
      "bytes": 67981,
      "sha256": "0a0b789f4494daee05d4f6b41ea314d1422cd462c6586b6f22602924cb167a6d"
    },
    "records": 38,
    "cached_pages": 8,
    "DOI_or_journal_ref_leads": 2,
    "source_calls": 0,
    "quality_or_reading_credit": 0,
    "absence_is_not_unpublished": true
  },
  "arxiv_current_repair_aware_acceptance": {
    "state": "SOURCE1770615_ACCEPTED_REPAIR_AWARE_ONE_ORIGINAL_FAILURE_HELD_NEXT756_NOT_STARTED",
    "original_indices": [
      731,
      755
    ],
    "source_PID": 1770615,
    "parent_PID": 1770613,
    "source_invocations": 1,
    "source_records": 25000,
    "accepted_quality_receipt": {
      "path": "_tracking/source1770615-independent-local-A25000-science-LF-20261028/CURRENT731-REPAIR-AWARE-AUDIT-PROPOSAL/ROOT-EXPLICIT-GAP-ACCEPTANCE-ONCE/ROOT-EXACT25000-SOURCE1770615-EXPLICIT-GAP-ACCEPTANCE-ONCE.json",
      "bytes": 31347,
      "sha256": "d660b0d3e53082e2fdc024a4cc34f5de31cc8f79ad4100ee7ef642ca17777659"
    },
    "registration": {
      "path": "_tracking/source1770615-independent-local-A25000-science-LF-20261028/CURRENT731-REPAIR-AWARE-AUDIT-PROPOSAL/ROOT-EXPLICIT-GAP-ACCEPTANCE-ONCE/ROOT-EXACT25000-REPEAT-REGISTRATION-ONCE.json",
      "bytes": 2081,
      "sha256": "5175a6b3da15e80b7f790a99458de9fad33558716e88a422605093d87f7a2245"
    },
    "original_failed_native_predicates": 1,
    "all_original_predicates_passed": false,
    "positive_retention_gap_rows": 28,
    "omitted_contexts_held": 1261,
    "quality_credit": 25000,
    "next_original_indices": [
      756,
      780
    ],
    "next_source_invocations": 0,
    "display": "Batch 731â€“755 is accepted once through the distinct repair-aware route: 17,884 usable scans, 7,065 coverage gaps and 51 failures. All 11,007 positive rows remain queued; 28 positive rows retain explicit omissions totaling 1,261 contexts. The original unit09 row362 count predicate still fails in its immutable native record; the separately verified same-PDF/text sidecar holds it as a positive coverage gap, never a usable scan. Source and parent owned waits returned zero. Accepted totals are now 1,600,795 diagnostic outcomes and 1,046,774 usable scans, with 412,561 earlier attempts quality-unverified and 749,165 completed repair IDs excluded from replay. The next 756â€“780 metadata is saved; its same 749,165 exclusion union must be rebound to the actual accepted cache. No next source has started. Reviewed jobV2/verifierV3 integration is independently peered but needs prospective data, actual prefix/resource checks and a separate exact source GO."
  },
  "Root_two_cached_journal_leads": {
    "reading": {
      "path": "_tracking/ROOT-two-cached-journal-leads-retained-body-20261028/ROOT-TWO-RETAINED-SCIENTIFIC-CONTEXT-DISPOSITIONS-AND-DIAGNOSTIC-ROLE-QUALIFICATIONS-20261028.json",
      "bytes": 9175,
      "sha256": "2b6d11022ba43fb4f64f69d295021ea0ffa575457f54dac22b1b540ad17f4c4b"
    },
    "reconciliation": {
      "path": "_tracking/ROOT-two-cached-journal-leads-retained-body-20261028/ROOT-TWO-FINITE-EXISTING-JOURNAL-READINGS-LEDGER-RECONCILIATION-ONCE.json",
      "bytes": 882,
      "sha256": "97f5fe7d550a40220836beab53860566b8b1f340f21e39e7dd43b099b994fae2"
    },
    "versions": [
      "1802.09885@v1",
      "1806.02018@v1"
    ],
    "do_not_repeat_read_contexts": true,
    "Euler_primary_later_resolution_and_narrow_formulation_hold": {
      "path": "_tracking/focused-Euler-Gauss-DG-correction-existence-180602018-A-20261028/PRIMARY-LATEST-EXPLICIT-GAUSS-EULER-SURFACE-CORRECTIONS-BROAD-EXISTENCE-EXCLUDED-RESTRICTED-ANSATZ-HOLD.json",
      "bytes": 9133,
      "sha256": "60e5c1120f9babb9a2743ede3d95b5f498f25558c61e4a112019b49a2f5a5730"
    },
    "new_admissions": 0
  }
}
```

**Active parallel work at this checkpoint:**

```json
{
  "A": "Full current repair-aware audit and specialized writer/publisher code peers completed. Two cached journal leads checked; broad Euler correction existence has later explicit construction, narrow undefined ansatz held.",
  "B": "Current731completed; future5program integration and exact76completed-duplicate cleanup candidate prepared, no activation/unlink. SESSION20 closed cleanly; one new bounded connection needed for fresh remote checks and any approved next steps.",
  "C": "Full current25000native/LF/queue/ID result-binding peer and futureintegration code/model peer passed. Independently checking saved756metadata rebind to actual749165 cache; no refetch/source.",
  "Root": "Accepted current731diagnostics once with exactone failed native predicate preserved as explicitgap;749165registration complete. Publishing1600795/1046774,127435readingunits,346partialfamilies,620pages. Prepare next finite metadata/prefix and verified cleanup; no Git operations."
}
```

**Storage and replay:** preserve retained result hashes, original input/import/completion identities, all recovery archives/markers and unselected metadata. Never restart a cohort because an observation timed out. G used the unchanged producer floor and four separately bounded private prior105/E15/F15/metadata verification stages. Any later batch needs fresh resource/STOP/namespace checks and current accepted exclusions.

[Exact predecessor of this document](_tracking/delta-predecessor-20261028T182335562079Z-RESUME.md.gz); historical details remain recoverable there. Use the current register for present counts and cursors.
