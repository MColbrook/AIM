# Can a Heisenberg surface be more than one-half Hölder?

## Problem statement

Let $U\subset\mathbb R^2$ be a nonempty open set and let $\mathbb H^1$ be the first Heisenberg group with its Carnot–Carathéodory distance $d_{cc}$. Does there exist an injective map $f:U\to\mathbb H^1$ which is locally $\alpha$-Hölder for some $\alpha>1/2$; that is, on every compact $K\subset U$ there is a constant $C_K$ with
$$d_{cc}(f(x),f(y))\le C_K|x-y|^\alpha\qquad(x,y\in K)?$$

The conjectured answer is **no**. Since $d_{cc}$ induces the usual topology on $\mathbb H^1\cong\mathbb R^3$, an injective continuous map on a planar open set is an embedding locally. The nontrivial range is $1/2<\alpha\le 2/3$: smooth Euclidean surface embeddings give $1/2$-Hölder examples, while Gromov's theorem rules out $\alpha>2/3$.

## Application

The Heisenberg group is a local model of a contact manifold. This question asks how regular a two-dimensional surface can be when distance is measured along the allowed horizontal directions. It separates geometric regularity of embedded surfaces from the existence of Hölder maps that may fold or identify points.

## References

1. E. Le Donne and R. Züst, [*Some properties of Hölder surfaces in the Heisenberg group*](https://arxiv.org/abs/1205.0228), *Illinois J. Math.* **57** (2013), 229–249, Introduction and Theorems 1.1–1.3. States the folk conjecture and proves restrictions under additional conditions.
2. P. Hajłasz and A. Schikorra, [*On the Gromov non-embedding theorem*](https://arxiv.org/html/2303.12960v2) (2023), Introduction and Theorem 1.2. Restates the one-half conjecture and proves a non-embedding theorem requiring additional Euclidean regularity.
3. P. Hajłasz, J. Mirra and A. Schikorra, [*Hölder continuous mappings, differential forms and the Heisenberg groups*](https://arxiv.org/html/2503.11506v3) (2025), §8, Theorem 8.2 and Corollaries 8.4, 8.6. Gives refined bounds with an additional Euclidean regularity hypothesis.
4. S. Wenger and R. Young, [*Constructing Hölder maps to Carnot groups*](https://arxiv.org/abs/1810.02700) (2018), Introduction and main theorems. Constructs maps below exponent $2/3$ without giving embeddings.

## Status review

The later non-embedding results still require extra regularity when $1/2<\alpha\le 2/3$, and the known Hölder extension constructions are not embeddings. A 2016 preprint titled as a solution was [withdrawn because of a crucial proof error](https://arxiv.org/abs/1601.00956); its initial claim cannot settle this question. Bounded searches through 22 October 2026 found no later unrestricted resolution or exact AIM/FURTHER duplicate. The [dated status](../_tracking/heisenberg-holder-surface-2026-10-22-status.json) and [duplicate](../_tracking/heisenberg-holder-surface-2026-10-22-duplicates.json) audits record the distinctions and search limits.
