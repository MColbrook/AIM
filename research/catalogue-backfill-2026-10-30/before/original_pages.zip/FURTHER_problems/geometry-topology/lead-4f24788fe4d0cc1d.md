# Uniqueness of the closed genus-one self-shrinker in three dimensions

**Area:** Geometric analysis and mean curvature flow

**Status:** Open question in the cited literature; no resolution located

**Last checked:** 2026-10-19

## Problem statement

Let \(\Sigma\subset\mathbb R^3\) be a smooth, compact, connected, embedded surface without boundary, diffeomorphic to \(S^1\times S^1\). For its position map \(X\), suppose
\[
\Delta_\Sigma X=-\tfrac12X^\perp,
\]
where \(\Delta_\Sigma=\operatorname{div}_\Sigma\nabla_\Sigma\) and \(X^\perp\) is the normal projection of the position vector. Must \(\Sigma\) be an orthogonal image of the classical Angenent torus, normalized to satisfy this equation?

No rotational symmetry is assumed for \(\Sigma\). The extinction center and scale are fixed by the displayed equation. The question excludes immersed or noncompact competitors.

## Application

Self-shrinkers describe self-similar singularity models for mean curvature flow. A positive answer would classify the compact embedded toroidal models in three dimensions. It would also identify the rotational doughnuts obtained through different existence constructions, whose equality should not be assumed in advance.

## References

1. G. Drugan, H. Lee and X. H. Nguyen, *A survey of closed self-shrinkers with symmetry*, Results in Mathematics **73** (2018), article 32. [Published article](https://doi.org/10.1007/s00025-018-0763-3); [author version 1708.09113v1](https://arxiv.org/abs/1708.09113v1). Section 7, Open Problem 1, printed p. 19 in the author version; §2.6 fixes the normalization.
2. S. B. Angenent, *Shrinking doughnuts*, in *Nonlinear Diffusion Equations and Their Equilibrium States, 3*, Progress in Nonlinear Differential Equations and Their Applications **7** (1992), 21–38. The existence construction is cited as reference 9 in the first source.
3. P. Peng, *Comparison Theorems for the Profile Curve Equation of Rotationally Symmetric Self-Shrinkers*, [arXiv:2606.20276v2](https://arxiv.org/abs/2606.20276v2), revised 3 September 2026. The introduction retains the uniqueness problem; its existence and conditional comparison results do not classify all competitors.
4. A. C.-P. Chu and A. Sun, *Genus-one singularities in mean curvature flow*, Geometry & Topology **29** (2025), 4299–4340. [Published article](https://doi.org/10.2140/gt.2025.29.4299); [author version 2308.05923v3](https://arxiv.org/abs/2308.05923v3). Additional genus-one examples do not establish a compact counterexample to this question.

## Status review

The September 2026 reference explicitly leaves uniqueness open. Its profile-curve results concern rotationally symmetric surfaces and impose additional conditions; they do not imply the unrestricted classification above. The later genus-one constructions reviewed here must not be treated as closed examples without establishing compactness. Bounded searches found no matching complete-resolution announcement or equivalent AIM/FURTHER entry.

The [primary review](../_tracking/angenent-torus-primary-review-2026-10-19.json), [current checks](../_tracking/angenent-torus-current-review-2026-10-19.json), [independent audit](../_tracking/parallel/continuum/angenent-genus-one-independent-selected-scope-audit-2026-10-19.json), [semantic comparison](../_tracking/angenent-torus-duplicates-review-2026-10-19.json), [website comparison](../_tracking/angenent-torus-catalogue-review-2026-10-19.json) and [coordinator review](../_tracking/angenent-torus-coordinator-review-2026-10-19.json) record checked extents and access/normalization limits. They do not certify exhaustive absence of a solution or verify the complete cited proofs.
