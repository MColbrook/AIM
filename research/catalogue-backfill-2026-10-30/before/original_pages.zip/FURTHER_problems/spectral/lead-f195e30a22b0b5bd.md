# Uniform Weyl asymptotics for self-generated spinless magnetic fields

**Area:** Semiclassical spectral theory and magnetic Schrödinger operators

**Status:** Open in the cited source; the weak-field regime is known.

**Last checked:** 2026-10-24

**Source:** Erdős–Fournais–Solovej [1], Remark 3, printed page 2098.

## Problem statement

Fix a real potential \(V\in L^{5/2}(\mathbb R^3)\), and write \(V_+=\max\{V,0\}\). For \(h>0\) and \(\beta\ge0\), define
\[
E^{\rm S}(\beta,h,V)
=\inf_{A\in H^1(\mathbb R^3;\mathbb R^3)}
\left\{
\operatorname{Tr}\bigl(( -ih\nabla+A)^2-V\bigr)_-
+\beta\int_{\mathbb R^3}|\operatorname{curl}A|^2\,dx
\right\}.
\]
Here \(t_-=\min\{t,0\}\): the trace is the signed sum of the negative eigenvalues, using the variational/Friedrichs formulation of Appendix A in [1]. The operator acts on scalar \(L^2(\mathbb R^3)\).

Prove or disprove
\[
\lim_{h\downarrow0}\ \sup_{\beta\ge0}
\left|
h^3E^{\rm S}(\beta,h,V)
+\frac{1}{15\pi^2}\int_{\mathbb R^3}V_+(x)^{5/2}\,dx
\right|=0.
\]
The potential is fixed before taking the limit. Uniformity is required over the field-energy penalty, including \(\beta=0\); no quantitative remainder or uniformity over potentials is requested.

## Application

This would show that optimizing a self-generated magnetic field leaves the leading semiclassical energy of spinless noninteracting fermions unchanged, even when the field-energy penalty becomes arbitrarily small.

## References

1. László Erdős, Søren Fournais and Jan Philip Solovej, *Stability and semiclassics in self-generated fields*, Journal of the European Mathematical Society **15** (2013), no. 6, 2093–2113. [DOI](https://doi.org/10.4171/JEMS/416), [publisher PDF](https://ems.press/content/serial-article-files/31927?nt=1), [author preprint](https://arxiv.org/abs/1105.0506v3). Equation (1), equation (6), Theorem 2.2 and Remark 3, printed pages 2094–2098; Appendix A, printed pages 2107–2108.

## Status review

Theorem 2.2 of [1] proves the stated leading term when \(\beta h\to\infty\). Remark 3 explicitly conjectures uniformity for \(\beta\in[0,\infty)\) in the spinless case. Equation (6) gives a universal lower bound with a nonsharp constant, and choosing \(A=0\) gives the nonmagnetic upper comparison.

Monotonicity gives
\[
E^{\rm S}(0,h,V)\le E^{\rm S}(\beta,h,V)
\le \operatorname{Tr}(-h^2\Delta-V)_-.
\]
Consequently, the all-\(\beta\) assertion is equivalent to the corresponding leading limit at \(\beta=0\), using the usual nonmagnetic Weyl asymptotics. This equivalence is an elementary inference from the definition. The Pauli analogue has different behaviour and is outside this problem.

No matching complete published or announced resolution was located in the bounded searches on 24 October 2026. Comparisons included later self-generated-field asymptotics, Scott-correction results, Lieb–Thirring bounds and planar constant-field estimates. A full later monograph chapter was inaccessible; the audit retains this search gap. These checks do not certify that no unindexed result exists.

The [planar variable-field Dirichlet eigenvalue problem](lead-aba1561af4e8b2e3.md) is related but has a different dimension, domain, spectral target and quantification. AIM 018 asks for the sharp nonmagnetic three-dimensional Lieb–Thirring inequality; the OpenAI announcement on sharp one-dimensional matrix inequalities also has a different target. All-status catalogue and FURTHER comparisons found no equivalent existing statement.
