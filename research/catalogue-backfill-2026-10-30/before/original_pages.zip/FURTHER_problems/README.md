# Further-problem collection

The research ledger records **731 historical admissions**. The selection of 30 October 2026 retains **521** here and preserves **210** in [cut_problems](../cut_problems/README.md). The keep rule is **I = max(M, A) >= 6**, applied to the frozen [score snapshot](../cut_problems/_audit/score_snapshot.json).

Research history, duplicate exclusions and the coverage database remain in place. Before interpreting an old admitted path as missing work, resolve it through [the relocation manifest](../cut_problems/move_manifest.json). Cuts are editorial decisions and do not change mathematical statuses or source-review credit.

See [the resume handoff](RESUME.md), [workflow](WORKFLOW.md), [source log](SOURCE_LOG.md) and [scoring and cut report](../cut_problems/SCORING_AND_CUT.pdf).
